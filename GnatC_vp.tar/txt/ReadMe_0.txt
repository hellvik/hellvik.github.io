alfa@raspberrypi:~/u/project/GnatC_vp/TEST $ export LD_LIBRARY_PATH=lib;bin/exomega

exmy - no input & Qinit
exny - no input
exxsi - no input
exomikron - no input
expi - input file: UCDlink/Blocks.txt & Qinit
exro - input file: UCDlink/UnicodeData.txt & Qinit
exsigma - no input
extau - no input
exypsilon - no input
exfi - input (ExFi.prop)
exkhi - input (ExKhi.prop)
expsi - no input
exomega - no input

chesslist - input
classlist - input
cmakegs_urv - input
coderewrite - input
creategc - input
createultcase - input
createunicodeblock - input
createurv - input
