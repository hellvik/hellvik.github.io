-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190709115147.
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Command_Line;
with Ada.Strings; use Ada.Strings;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
with Y2018.Text.Regex.PatternPack; 
with Y2018.Text.Regex.MatchPack; use Y2018.Text.Regex.MatchPack;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Ada.Containers.Vectors;
with Ada.Containers.Ordered_Maps;
-- with DSECT;
procedure Y2018XMLflt is
	type TRINITY is (GOOD,BAD,UGLY);
	type ST_ty is (ST_ZERO, ST_ONE, ST_TWO, ST_ERROR, ST_SUCCESS, 
		ST_XML, --392
		ST_DOC, --393
		ST_MS, --394
		ST_COM, --395
		ST_ENDN, --396 named END
		ST_ENDB, --397 * unnamed END
		ST_BEGB, --399 * unnamed BEG
		ST_BEG_SHORT, --400
		ST_BEGN, --401 * named BEG with no attr
		ST_SHORTN --402 * named SHORT with no attr
		); --403
	type P_ty is (P_NONE, 
		P_DA0,	-- head 
		P_DA1,	-- clip empty stack 
		P_DA2,	-- clip  
		P_DA3,	-- full  
		P_DA4,	-- script full  
		P_DA5,	-- script continue  
		P_DA6,	-- tail  
		P_XML,	--
		P_DOC,	--
		P_COM0,	-- end  
		P_COM1,	-- continue  
		P_COM2,	-- full  
		P_MS0,	-- end  
		P_MS1,	-- continue  
		P_MS2,	-- full  
		P_MS3,	-- type found  
		P_END0,	-- script  
		P_END1,	-- named  
		P_END2,	-- unnamed  
		P_SHORT0,	-- attributes  
		P_SHORT1,	-- no attributes  
		P_BEG0,	-- shorted attributes  
		P_BEG1,	-- attributes  
		P_BEG2,	-- no name no attributes  
		P_BEG3,	-- shorted no attributes 
		P_BEG4,	-- no attributes  
		P_ATTR	--
		); --
	type TWO_ty is (TWO_NONE,TWO_SCRIPT,TWO_COM,TWO_MS);
	type StackE_ty is record
		n:Unbounded_Wide_Wide_String;
		stackLength:Integer;
	end record;

	-- Global variable --
	state:ST_ty:=ST_ZERO;
	getMoreData:TRINITY:=GOOD;
	r:Tool.M_AAAC;
	--thisPattern:Y2018.Text.Regex.PatternPack.Pattern_AC;
	thisCursor: Y2018.Text.Regex.PatternPack.G_Cursor;
	thisElement: Y2018.Text.Regex.MatchPack.Match_AC;
	inputLine:Unbounded_String;
	buffer:Unbounded_Wide_Wide_String:=NUW;
	lncnt:Integer:=0;
	i:Integer:=1;
	len:Integer;
	dellu:Boolean;
	w:Unbounded_Wide_Wide_String;
	list_beg_attr:Boolean:=FALSE;
	print_width:Integer:=0;
	print_linecount:Integer:=0;
	zero:constant Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AC:=new Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
	clip:Integer:=1000;
	script:Integer:=0;
	replCnt:Integer:=0;

	-- Stack Vector --
   package Stack_ty is new Ada.Containers.Vectors(Natural,StackE_ty);
	stack: Stack_ty.Vector;
	stackC: Stack_ty.Cursor;
	stackE: StackE_ty;

	-- OM Ordered Map --
	function less (Left,Right:Unbounded_Wide_Wide_String) return Boolean is
	begin
		if Left < Right then return true;
		else return false;
		end if;
	end less;
	function equal (Left,Right:Unbounded_Wide_Wide_String) return Boolean is
	begin
		if Left = Right then return true;
		else return false;
		end if;
	end equal;
	package OM_ty is new Ada.Containers.Ordered_Maps(Key_Type=> Unbounded_Wide_Wide_String,Element_Type=> Unbounded_Wide_Wide_String,"<"S => less, "="S => equal);
	om : OM_ty.Map;
	omC : OM_ty.Cursor;

	-- Pattern constant --
	stripPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?"W);
	notBlankPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?[\S]"W);
	argPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^-([\w]+)(?::(.*))?$"W);
	propPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*([\w\\.]+)[\s]*[:=](.*)$"W);
	propReplQPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*(&[\w]+;)[\s]*""([^""]*)"""W);
	propReplAPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*(&[\w]+;)[\s]*'([^']*)'"W);
	shortPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)/$"W);
	propertyPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^.*?\\.(?:prop|properties)$"W);
	attrPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?([-\w\\.:]+)[\s]*=[\s]*""([^""]*)"""W);
	replixPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)(&[\w]+;)"W);
	digitPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?([0-9]+)[\s]*$"W);

	st_onePattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^("W +
		"<\\?|"W + -- ST_XML
		"<!D|"W + -- ST_DOC
		"<!\\[|"W + -- ST_MS
		"<!--|"W + -- ST_COM
		"</[\w]|"W + -- ST_ENDN
		"</[\s]*>|"W + -- ST_ENDB
		"<[\s]*>|"W + -- ST_BEGB
		"<[\w](?:[\w]|-|\\.|:)*[\s]+[\w](?:[\w]|-|\\.|:)*[\s]*=|"W + -- ST_BEG_SHORT
		"<[\w](?:[\w]|-|\\.|:)*[\s]*>|"W + -- ST_BEGN
		"<[\w](?:[\w]|-|\\.|:)*[\s]*/>"W + -- ST_SHORTN
		")"W,
		Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_xmlPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<\\?XML(.*?)\\?>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_docPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<!DOCTYPE(.*?)>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_comPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<!--(.*?)-->)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_msPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<!\\[[\s]*(IGNORE|INCLUDE|CDATA|RCDATA|TEMP)[\s]*\\[(.*?)\\]\\]>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_ms2Pattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<!\\[[\s]*(IGNORE|INCLUDE|CDATA|RCDATA|TEMP)[\s]*\\[)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_endnPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(</((?:[\w]|-|\\.|:)+)(.*?)>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_beg_shortPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile(
		"^(<([\w](?:[\w]|-|\\.|:)*)([\s]+[\w](?:[\w]|-|\\.|:)*[\s]*=""[^""]*"")+[\s]*(/?)>)"W,
		Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_begnPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<([\w](?:[\w]|-|\\.|:)*)[\s]*>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_shortnPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(<([\w](?:[\w]|-|\\.|:)*)[\s]*/>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	st_zeroPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*([^<]*)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);

	two_scriptPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)(</SCRIPT[\s]*>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	two_comPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)(-->)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	two_msPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)(\\]\\]>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
	two_EC:Wide_Wide_Character;
	ch_two:TWO_ty:=TWO_NONE;
	
	-- Procedure/Function --
	function replix (s:Wide_Wide_String) return Wide_Wide_String;
	
	procedure Print(t:P_ty;v:Wide_Wide_String;s:Wide_Wide_String) is
		w:Unbounded_Wide_Wide_String;
		h:Unbounded_Wide_Wide_String;
		q:Unbounded_Wide_Wide_String;
	begin
		case t is
			when P_MS1 =>
				w:=NUW + s;
			when P_MS2 =>
				w:=NUW + s;
			when P_MS3 =>
				w:=NUW + s;
			when others =>
				w:=NUW + replix(s);
		end case;
		case t is
			when P_MS2 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_MS3 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_END1 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_SHORT0 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_SHORT1 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_BEG0 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_BEG1 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_BEG3 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_BEG4 =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when P_ATTR =>
				q:=NUW + P_ty'Image(t)+" "+v;
			when others =>
				q:=NUW + P_ty'Image(t);
		end case;
		loop
			if print_width = 0 then
				h:=w;
				w:=NUW;
			elsif length(w) <= print_width then
				h:=w;
				w:=NUW;
			else
				h:=Tool.substr(w,1,print_width);
				w:=Tool.substr(w,print_width + 1);
			end if;
			Ada.Text_IO.Put_Line("" + q+"|"+h);
			if length(w) = 0 then
				exit;
			end if;
			q:=NUW + "...";
		end loop;
	end Print;
	
	function isShorted(prefix:Wide_Wide_String;name:Wide_Wide_String) return Boolean is
		-- GLOBAL: om: OM_ty.Map;
		thisC : OM_ty.Cursor;
		key:Unbounded_Wide_Wide_String:=NUW + prefix + name;
		value:Unbounded_Wide_Wide_String;
	begin
		thisC:=OM_ty.Find(om,key);
		if OM_ty.Has_Element(thisC) then
			value:=OM_ty.Element(thisC);
			if Tool.to_LC(""W + value) = "short"W then
				return TRUE;
			end if;
		end if;
		return FALSE;
	end isShorted;
	
	procedure populateOM(filename:String) is
		-- GLOBAL: om: OM_ty.Map;
		-- GLOBAL: propPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: stripPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		propertyFile : File_Type;
		key : Unbounded_Wide_Wide_String;
		value : Unbounded_Wide_Wide_String;
		thisCursor : OM_ty.Cursor;
		r:Tool.M_AAAC;
	begin
		begin
			Open (File => propertyFile,
					Mode => In_file,
					Name => filename);
			exception
				when others =>
					Put_Line (Standard_Error,"Can not open the file '" + filename + "'. Does it exist?");
					Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
					return;
		end;
		while not End_Of_File(propertyFile) loop
			declare
				line : Wide_Wide_String := ""W + Get_Line(propertyFile);
			begin
				if Tool.matchTo(line,propPattern,r) then
					key:=r(1).all;
					value:=Tool.StripP(r(2).all,stripPattern);
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
					end if;
				elsif Tool.matchTo(line,propReplQPattern,r) then
					key:=r(1).all;
					value:=r(2).all;
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
						replCnt:=replCnt+1;
					end if;
				elsif Tool.matchTo(line,propReplAPattern,r) then
					key:=r(1).all;
					value:=r(2).all;
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
						replCnt:=replCnt+1;
					end if;
				end if;
			end;
		end loop;
		Close(propertyFile);
	end populateOM;
	
	procedure arg2om is
		-- GLOBAL: om: OM_ty.Map;
		-- GLOBAL: argPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: stripPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: propertyPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		i:Integer:=1;
		key : Unbounded_Wide_Wide_String;
		value : Unbounded_Wide_Wide_String;
		thisC : OM_ty.Cursor;
		r:Tool.M_AAAC;
	begin
		while i<= Ada.Command_Line.Argument_Count loop
			if Tool.matchTo(Ada.Command_Line.Argument(i),argPattern,r) then
				key:=Tool.StripP(r(1).all,stripPattern);
				value:=Tool.StripP(r(2).all,stripPattern);
				if Wide_Wide_Unbounded.Length(key)>0 then
					thisC:=OM_ty.Find(om,key);
					if OM_ty.Has_Element(thisC) then
						Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t"W+"Allready exists:"+key);
					else
						OM_ty.Insert(om,key,value);
					end if;
				end if;
			elsif matchTo(Ada.Command_Line.Argument(i),propertyPattern,Y2018.Text.Regex.PatternPack.G_UPPERCASE) then
				populateOM(Ada.Command_Line.Argument(i));
			else
				Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t"W+"Unknown argument:"+Ada.Command_Line.Argument(i));
			end if;
			i:=i+1;
		end loop;
		thisC:=OM_ty.Find(om,NUW + "l"W);
		if OM_ty.Has_Element(thisC) then
			thisC:=OM_ty.First(om);
			while OM_ty.Has_Element(thisC) loop
				key  := OM_ty.Key(thisC);
				value:= OM_ty.Element(thisC);
				Ada.Text_IO.Put_Line(Ada.Text_IO.Standard_Error,"" + "\t"W + key + "=" + value);
				OM_ty.Next(thisC);
			end loop;  
		end if;
	end arg2om;
	
	procedure listAttr(name:Wide_Wide_String;attr:Wide_Wide_String) is
		s : Unbounded_Wide_Wide_String:=NUW + attr;
		thisC: Y2018.Text.Regex.PatternPack.G_Cursor;
		thisE: Y2018.Text.Regex.MatchPack.Match_AC;
	begin
		loop
			thisC:=Y2018.Text.Regex.PatternPack.matches(attrPattern,""W + s);
			if Y2018.Text.Regex.PatternPack.has_Element(thisC) then
				thisE:=Y2018.Text.Regex.PatternPack.element(thisC);
				declare
					qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisE);
				begin
					Print(P_ATTR,name + "`"W + qr(1).all,""W + qr(2).all);
				end;
			else
				exit;
			end if;
			s:=NUW + Y2018.Text.Regex.PatternPack.source(thisC);
		end loop;
	end listAttr;

	function replix (s:Wide_Wide_String) return Wide_Wide_String is
		found:Boolean:=FALSE; 
	begin
		if replCnt>0 then
			for i in s'First .. s'Last loop
				if s(i) = '&'W then
					found:=TRUE;
					exit;
				end if;
			end loop;
		end if;
		if found then
			declare
				w : Unbounded_Wide_Wide_String:=NUW + s;
				thisC: Y2018.Text.Regex.PatternPack.G_Cursor;
				thisE: Y2018.Text.Regex.MatchPack.Match_AC;
				v : Unbounded_Wide_Wide_String;
				thatC : OM_ty.Cursor;
			begin
				loop
					thisC:=Y2018.Text.Regex.PatternPack.matches(replixPattern,""W + w);
					if Y2018.Text.Regex.PatternPack.has_Element(thisC) then
						thisE:=Y2018.Text.Regex.PatternPack.element(thisC);
						declare
							qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisE);
						begin
							v:=v + qr(1).all;
							thatC:=OM_ty.Find(om,qr(2).all);
							if OM_ty.Has_Element(thatC) then
								v:=v + OM_ty.Element(thatC);
							else
								v:=v + qr(2).all;
							end if;
						end;
					else
						exit;
					end if;
					w:=NUW + Y2018.Text.Regex.PatternPack.source(thisC);
				end loop;
				return ""W + v + w;
			end;
		else
			return s;
		end if;
	end replix;
begin
	arg2om;
	
	-- Set GLOBAL switches
	omC:=OM_ty.Find(om,NUW + "help"W);
	if OM_ty.Has_Element(omC) then
		Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tY2018XMLflt - retreive from a XML-file tags, comments, data"W);
		Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tSyntax: Y2018XMLflt {option}* {properties-file}*"W);
		Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tInput is standard input"W);
		Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tOutput is standard output"W);
		Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t-help (This is the list of the -help option)"W);
		return;
	end if;
	omC:=OM_ty.Find(om,NUW + "beg.attr"W);
	if OM_ty.Has_Element(omC) then
		list_beg_attr:=TRUE;
	end if;
	omC:=OM_ty.Find(om,NUW + "width");
	if OM_ty.Has_Element(omC) then
		if Tool.matchTo(OM_ty.Element(omC),digitPattern,r) then
			print_width:=Integer'Value("" + r(1).all);
		end if;
	end if;
	omC:=OM_ty.Find(om,NUW + "linecount");
	if OM_ty.Has_Element(omC) then
		if Tool.matchTo(OM_ty.Element(omC),digitPattern,r) then
			print_linecount:=Integer'Value("" + r(1).all);
		end if;
	end if;
	omC:=OM_ty.Find(om,NUW + "clip");
	if OM_ty.Has_Element(omC) then
		if Tool.matchTo(OM_ty.Element(omC),digitPattern,r) then
			clip:=Integer'Value("" + r(1).all);
		end if;
	end if;
	omC:=OM_ty.Find(om,NUW + "script");
	if OM_ty.Has_Element(omC) then
		if Tool.matchTo(OM_ty.Element(omC),digitPattern,r) then
			script:=Integer'Value("" + r(1).all);
		end if;
	end if;
	
	loop
		if getMoreData /=BAD then
			if End_Of_File then
				case getMoreData is
					when UGLY =>
						state:=ST_ERROR;
					when others =>
						state:=ST_SUCCESS;
				end case;
			else
				inputLine:=NUS + Get_Line;
				lncnt:=lncnt + 1;
				if print_linecount>0 then
					if lncnt mod print_linecount = 0 then
						Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t"W + Integer'Image(lncnt));
					end if;
				end if;
				buffer:=buffer + inputLine + " "W;
				getMoreData:=BAD;
			end if;
		end if;
		if state = ST_SUCCESS then
			exit;
		elsif state = ST_ERROR then
			exit;
		end if;
		case state is
			when ST_ZERO =>
				if Length(buffer) = 0 then
					if getMoreData = BAD then
						getMoreData:=GOOD;
					end if;
				elsif Wide_Wide_Unbounded.Element(buffer,1) = '<'W then
					state:=ST_ONE;
				else
					thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_zeroPattern,""W + buffer);
					if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
						thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
						declare
							qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
						begin
							declare
								tag:Wide_Wide_String:=""W + qr(1).all;
							begin
								if tag'Length(1) > 0 then
									Print(P_DA0,""W,tag);
								end if;
							end;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end if;
				end if;
			when ST_ONE =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_onePattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
						-- NOTE qr: Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA is 
						-- array (Integer range <>) of Unbounded_Wide_Wide_String_AC;
					begin
						declare
							tag:Wide_Wide_String:=""W + qr(1).all;
						begin
							if tag'Length(1) = 2 then
								if tag(2)='?'W then
									state:=ST_XML;
								elsif tag(2)='>'W then
									state:=ST_BEGB;
								end if;
							end if;
							if tag'Length(1) = 4 then
								if tag(2)='!'W and tag(3)='-'W and tag(4)='-'W then
									state:=ST_COM;
								end if;
							end if;
							if state=ST_ONE then
								if tag(2)='?'W then
									state:=ST_XML;
								elsif tag(2)='!'W and (tag(3)='D'W or tag(3)='d'W) then
									state:=ST_DOC;
								elsif tag(2)='!'W and tag(3)='['W then
									state:=ST_MS;
								--elsif tag(2)='!'W and tag(3)='-'W and tag(4)='-'W then
								--	state:=ST_COM;
								elsif tag(2)='/'W and Tool.is_W(tag(3)) then
									state:=ST_ENDN;
								elsif tag(2)='/'W and (tag(3)='>'W or Tool.is_S(tag(3))) then
									state:=ST_ENDB;
								elsif (Tool.is_S(tag(2)) or tag(2)='>'W) and tag(tag'Last)='>'W then
									state:=ST_BEGB;
								elsif Tool.is_W(tag(2)) and tag(tag'Last)='='W then
									state:=ST_BEG_SHORT;
								elsif Tool.is_W(tag(2)) and tag(tag'Last-1)='/'W and tag(tag'Last)='>'W then
									state:=ST_SHORTN;
								elsif Tool.is_W(tag(2)) and tag(tag'Last)='>'W then
									state:=ST_BEGN;
								end if;
							end if;
							if state=ST_ONE then
								if getMoreData=BAD then
									getMoreData:=GOOD;
								end if;
								state:=ST_ZERO;
							else
								buffer:=NUW + tag + Y2018.Text.Regex.PatternPack.source(thisCursor);
							end if;
						end;
					end;
				else  -- st_onePattern FAIL
					if Length(buffer) > clip then --*CLIP*
						if Stack_ty.Is_Empty(stack) then
							Print(P_DA1,""W,""W + buffer);
							buffer:=NUW;
							getMoreData:=GOOD;
						else
							stackC:=Stack_ty.Last(stack);
							if Stack_ty.Has_Element(stackC) then
								stackE:=Stack_ty.Element(stackC);
								len:=Length(buffer)-Length(stackE.n)-10;
								declare
									sc:Wide_Wide_String:=""W + Tool.substr(buffer,1,len);
									k:Integer:=2;
								begin
									while sc(k) /= '<'W loop
										if k=len then
											exit;
										else
											k:=k+1;
										end if;
									end loop;
									len:=k-1;
								end;
								Print(P_DA2,""W,""W + Tool.substr(buffer,1,len));
								buffer:=Tool.substr(buffer,len+1);
								getMoreData:=GOOD;
							else
								Print(P_DA3,""W,""W + buffer);
								buffer:=NUW;
								getMoreData:=GOOD;
							end if;
						end if;
						state:=ST_ZERO;
					end if;
					if getMoreData=BAD then
						getMoreData:=GOOD;
					end if;
				end if;
			when ST_TWO =>
				case ch_two is
					when TWO_COM =>
						two_EC:='-'W;
						thisCursor:=Y2018.Text.Regex.PatternPack.matches(two_comPattern,""W + buffer);
					when TWO_MS =>
						two_EC:=']'W;
						thisCursor:=Y2018.Text.Regex.PatternPack.matches(two_msPattern,""W + buffer);
					when TWO_SCRIPT =>
						two_EC:='<'W;
						thisCursor:=Y2018.Text.Regex.PatternPack.matches(two_scriptPattern,""W + buffer);
					when others =>
						raise Program_Error with "E001 Unknown ch_two";
				end case;
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						case ch_two is
							when TWO_COM =>
								declare
									tval:Wide_Wide_String:=""W + qr(1).all;
									ttag:Wide_Wide_String:=""W + qr(2).all;
								begin
									Print(P_COM0,""W,tval + ttag);
								end;
							when TWO_MS =>
								declare
									tval:Wide_Wide_String:=""W + qr(1).all;
									ttag:Wide_Wide_String:=""W + qr(2).all;
								begin
									Print(P_MS0,""W,tval + ttag);
								end;
							when TWO_SCRIPT =>
								declare
									tval:Wide_Wide_String:=""W + qr(1).all;
									ttag:Wide_Wide_String:=""W + qr(2).all;
								begin
									Print(P_DA4,""W,tval);
									Print(P_END0,""W,ttag);
									if Stack_ty.Is_Empty(stack) then
										null;
									else
										Stack_ty.Delete_Last(stack);
									end if;
								end;
							when others =>
								raise Program_Error with "E002 Unknown ch_two";
						end case;
						state:=ST_ZERO;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				else -- two_Pattern FAIL
					if Length(buffer) > clip then
						len:=Length(buffer)-50;
						declare
							sc:Wide_Wide_String:=""W + Tool.substr(buffer,1,len);
							k:Integer:=2;
						begin
							while sc(k) /= two_EC loop
								if k=len then
									exit;
								else
									k:=k+1;
								end if;
							end loop;
							len:=k-1;
						end;
						case ch_two is
							when TWO_COM =>
								Print(P_COM1,""W,""W + Tool.substr(buffer,1,len));
							when TWO_MS =>
								Print(P_MS1,""W,""W + Tool.substr(buffer,1,len));
							when others =>
								Print(P_DA5,""W,""W + Tool.substr(buffer,1,len));
						end case;
						buffer:=Tool.substr(buffer,len+1);
						getMoreData:=GOOD;
					elsif getMoreData=BAD then
						getMoreData:=GOOD;
					end if;
				end if;
			when ST_XML =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_xmlPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_XML,""W,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_DOC =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_docPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_DOC,""W,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_COM =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_comPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_COM2,""W,ttag); 
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				else
					state:=ST_TWO;
					ch_two:=TWO_COM;
				end if;
			when ST_MS =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_msPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							ttype:Wide_Wide_String:=Tool.To_UC(""W + qr(2).all);
							tval:Wide_Wide_String:=""W + qr(3).all;
						begin
							Print(P_MS2,ttype,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				else
					thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_ms2Pattern,""W + buffer);
					if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
						thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
						declare
							qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
						begin
							declare
								ttag:Wide_Wide_String:=""W + qr(1).all;
								ttype:Wide_Wide_String:=Tool.To_UC(""W + qr(2).all);
							begin
								Print(P_MS3,ttype,ttag);
								state:=ST_TWO;
								ch_two:=TWO_MS;
							end;
							buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
						end;
					else
						if getMoreData=BAD then
							getMoreData:=GOOD;
						end if;
						state:=ST_ZERO;
					end if;
				end if;
			when ST_ENDN =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_endnPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tname:Wide_Wide_String:=""W + qr(2).all;
							tattr:Wide_Wide_String:=""W + qr(3).all;
						begin
							w:=NUW;
							--Ada.Text_IO.Put_Line ("END: " + ttag);
							if Stack_ty.Is_Empty(stack) then
								null;
							elsif tname'Length = 0 then
								null;
							else
								i:=1;
								dellu:=FALSE;
								stackC:=Stack_ty.Last(stack);
								while Stack_ty.Has_Element(stackC) loop
									stackE:=Stack_ty.Element(stackC);
									if ""W + stackE.n = tname then
										w:=NUW + tname + Integer'Image(StackE.stackLength);
										--Ada.Text_IO.Put_Line("*END: " + tname + Integer'Image(StackE.stackLength));
										dellu:=TRUE;
										exit;
									end if;
									stackC:=Stack_ty.Previous(stackC);
									i:=i + 1;
								end loop;
								if dellu then
									while i>0 loop
										if Stack_ty.Is_Empty(stack) then
											Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tUnbalanced"W);
											exit;
										end if;
										Stack_ty.Delete_Last(stack);
										i:=i - 1;
									end loop;
								end if;
							end if;
							Print(P_END1,""W + w,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_BEG_SHORT =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_beg_shortPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						if qr(4) = null then
							qr(4):=zero;
						end if;
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tname:Wide_Wide_String:=Tool.to_LC(""W + qr(2).all);
							tattr:Wide_Wide_String:=""W + qr(3).all; -- attr list
							tstate:ST_ty:=(if qr(4).all = NUW + "/"W then ST_SHORTN else ST_BEGN);
						begin
							if tstate = ST_SHORTN then
								Print(P_SHORT0,tname,ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
								state:=ST_ZERO;
							elsif isShorted("tag."W,tname) then
								Print(P_BEG0,tname,ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
								state:=ST_ZERO;
							else
								Print(P_BEG1,tname + Integer'Image(Integer(Stack_ty.Length(stack))),ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
								Stack_ty.Append(Container => stack, New_Item => (n => NUW + tname, stackLength => Integer(Stack_ty.Length(stack))));
								if script = 1 then
									if tname = "script"W then
										state:=ST_TWO;
										ch_two:=TWO_SCRIPT;
									else
										state:=ST_ZERO;
									end if;
								else
									state:=ST_ZERO;
								end if;
							end if;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_ENDB =>
				Print(P_END2,""W,"</>"W);
				state:=ST_ZERO;
				buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
				if Stack_ty.Is_Empty(stack) then
					null;
				else
					Stack_ty.Delete_Last(stack);
				end if;
			when ST_BEGB =>
				Print(P_BEG2,""W,"<>"W);
				state:=ST_ZERO;
				buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
				Stack_ty.Append(Container => stack, New_Item => (n => NUW, stackLength => Integer(Stack_ty.Length(stack))));
			when ST_BEGN =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_begnPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tname:Wide_Wide_String:=""W + Tool.to_LC(""W + qr(2).all);
						begin
							if isShorted("tag."W,tname) then
								Print(P_BEG3,tname,ttag);
								state:=ST_ZERO;
							else
								Print(P_BEG4,tname,ttag);
								Stack_ty.Append(Container => stack, New_Item => (n => NUW + tname, stackLength => Integer(Stack_ty.Length(stack))));
								if script = 1 then
									if tname = "script"W then
										state:=ST_TWO;
										ch_two:=TWO_SCRIPT;
									else
										state:=ST_ZERO;
									end if;
								else
									state:=ST_ZERO;
								end if;
							end if;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				end if;
			when ST_SHORTN =>
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(st_shortnPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_SHORT1,tval,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				end if;
			when others =>
				null;
		end case;
	end loop;
	if Tool.matchTo(buffer,notBlankPattern) then
		Print(P_DA6,""W,Tool.StripP(""W + buffer,stripPattern));
	end if;
	Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tEnd of Y2018XMLflt"W);
end Y2018XMLflt;


