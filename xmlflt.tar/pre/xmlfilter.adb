-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile_proto.txt generated 20191106150412.
-- Note, You have to copy "Makefile_proto.txt" to a "makefile" and make
-- nesessary changes before you run the make utility.
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Command_Line;
with Ada.Strings; use Ada.Strings;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings.Fixed;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
with Y2018.Text.Regex.PatternPack; 
with Y2018.Text.Regex.MatchPack; use Y2018.Text.Regex.MatchPack;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Ada.Containers.Vectors;
with Ada.Containers.Ordered_Maps;
-- with DSECT;
procedure XMLfilter is
	type TRINITY is (GOOD,BAD,UGLY);
	type ST_ty is (ST_ZERO, ST_ERROR, ST_SUCCESS, ST_XML, ST_DOC, ST_MS, ST_COM, ST_END, ST_BEG_SHORT);
	type P_ty is (P_NONE, P_DA, P_XML, P_DOC, P_COM, P_MS, P_END, P_SHORT, P_BEG, P_ATTR);
	type StackE_ty is record
		n:Unbounded_Wide_Wide_String;
		stackLength:Integer;
	end record;

	-- Global variable --
	state:ST_ty:=ST_ZERO;
	getMoreData:TRINITY:=GOOD;
	r:Tool.M_AAAC;
	thisPattern:Y2018.Text.Regex.PatternPack.Pattern_AC;
	thisCursor: Y2018.Text.Regex.PatternPack.G_Cursor;
	thisElement: Y2018.Text.Regex.MatchPack.Match_AC;
	inputLine:Unbounded_String;
	buffer:Unbounded_Wide_Wide_String:=NUW;
	lncnt:Integer:=0;
	i:Integer:=1;
	dellu:Boolean;
	w:Unbounded_Wide_Wide_String;
	list_beg_attr:Boolean:=FALSE;
	print_width:Integer:=0;
	print_linecount:Integer:=0;
	zero:constant Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AC:=new Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String; 

	-- Stack Vector --
   package Stack_ty is new Ada.Containers.Vectors(Natural,StackE_ty);
	stack: Stack_ty.Vector;
	stackC: Stack_ty.Cursor;
	stackE: StackE_ty;

	-- OM Ordered Map --
	function less (Left,Right:Unbounded_Wide_Wide_String) return Boolean is
	begin
		if Left < Right then return true;
		else return false;
		end if;
	end less;
	function equal (Left,Right:Unbounded_Wide_Wide_String) return Boolean is
	begin
		if Left = Right then return true;
		else return false;
		end if;
	end equal;
	package OM_ty is new Ada.Containers.Ordered_Maps(Key_Type=> Unbounded_Wide_Wide_String,Element_Type=> Unbounded_Wide_Wide_String,"<"S => less, "="S => equal);
	om : OM_ty.Map;
	omC : OM_ty.Cursor;

	-- Pattern constant --
	stripPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?"W);
	notBlankPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?[\S]"W);
	argPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^-([\w]+)(?::(.*))?$"W);
	propPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*([\w\\.]+)[\s]*[:=](.*)$"W);
	propReplQPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*(&[\w]+;)[\s]*""([^""]*)"""W);
	propReplAPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*(&[\w]+;)[\s]*'([^']*)'"W);
	shortPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)/$"W);
	propertyPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^.*?\\.(?:prop|properties)$"W);
	attrPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?([-\w]+)[\s]*=[\s]*""([^""]*)"""W);
	replixPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^(.*?)(&[\w]+;)"W);
	digitPattern:constant Y2018.Text.Regex.PatternPack.Pattern_AC:=Y2018.Text.Regex.PatternPack.compile("^[\s]*?([0-9]+)[\s]*$"W);

	-- Procedure/Function --
	function replix (s:Wide_Wide_String) return Wide_Wide_String;
	
	procedure Print(t:P_ty;v:Wide_Wide_String;s:Wide_Wide_String) is
		w:Unbounded_Wide_Wide_String;
		h:Unbounded_Wide_Wide_String;
		q:Unbounded_Wide_Wide_String;
	begin
		--Qappend(Knase,"Print");
		case t is
			when P_DA =>
				q:=NUW + P_ty'Image(t);
				w:=NUW + replix(s);
			when P_MS =>
				q:=NUW + P_ty'Image(t)+" "+v;
				w:=NUW + s;
			when P_END =>
				q:=NUW + P_ty'Image(t)+" "+v;
				w:=NUW + s;
			when P_SHORT =>
				q:=NUW + P_ty'Image(t)+" "+v;
				w:=NUW + s;
			when P_BEG =>
				q:=NUW + P_ty'Image(t)+" "+v;
				w:=NUW + s;
			when P_ATTR =>
				q:=NUW + P_ty'Image(t)+" "+v;
				w:=NUW + s;
			--when P_XML =>
			--when P_DOC =>
			--when P_COM =>
			when others =>
				q:=NUW + P_ty'Image(t);
				w:=NUW + s;
		end case;
		loop
			if print_width = 0 then
				h:=w;
				w:=NUW;
			elsif length(w) <= print_width then
				h:=w;
				w:=NUW;
			else
				h:=Tool.substr(w,1,print_width);
				w:=Tool.substr(w,print_width + 1);
			end if;
			Ada.Text_IO.Put_Line("" + q+"|"+h);
			if length(w) = 0 then
				exit;
			end if;
			q:=NUW + "...";
		end loop;
	end Print;
	
	function isShorted(prefix:Wide_Wide_String;name:Wide_Wide_String) return Boolean is
		-- GLOBAL: om: OM_ty.Map;
		thisC : OM_ty.Cursor;
		key:Unbounded_Wide_Wide_String:=NUW + prefix + name;
		value:Unbounded_Wide_Wide_String;
	begin
		--Qappend(Knase,"isShorted");
		thisC:=OM_ty.Find(om,key);
		if OM_ty.Has_Element(thisC) then
			value:=OM_ty.Element(thisC);
			if Tool.to_LC(""W + value) = "short"W then
				return TRUE;
			end if;
		end if;
		return FALSE;
	end isShorted;
	
	procedure populateOM(filename:String) is
		-- GLOBAL: om: OM_ty.Map;
		-- GLOBAL: propPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: stripPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		propertyFile : File_Type;
		key : Unbounded_Wide_Wide_String;
		value : Unbounded_Wide_Wide_String;
		thisCursor : OM_ty.Cursor;
		r:Tool.M_AAAC;
	begin
		--Qappend(Knase,"populateOM");
		begin
			Open (File => propertyFile,
					Mode => In_file,
					Name => filename);
			exception
				when others =>
					Put_Line (Standard_Error,"Can not open the file '" + filename + "'. Does it exist?");
					Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
					return;
		end;
		while not End_Of_File(propertyFile) loop
			declare
				line : Wide_Wide_String := ""W + Get_Line(propertyFile);
			begin
				if Tool.matchTo(line,propPattern,r) then
					key:=r(1).all;
					value:=Tool.StripP(r(2).all,stripPattern);
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
						 null;--|Qappend(Fnatte,"OM |" + key + "=" + value);
					end if;
				elsif Tool.matchTo(line,propReplQPattern,r) then
					key:=r(1).all;
					value:=r(2).all;
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
						 null;--|Qappend(Fnatte,"OM |" + key + " [" + value + "]");
					end if;
				elsif Tool.matchTo(line,propReplAPattern,r) then
					key:=r(1).all;
					value:=r(2).all;
					thisCursor:=OM_ty.Find(om,key);
					if not OM_ty.Has_Element(thisCursor) then
						OM_ty.Insert(om,key,value);
						 null;--|Qappend(Fnatte,"OM |" + key + " [" + value + "]");
					end if;
				end if;
			end;
		end loop;
		Close(propertyFile);
	end populateOM;
	
	procedure arg2om is
		-- GLOBAL: om: OM_ty.Map;
		-- GLOBAL: argPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: stripPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		-- GLOBAL: propertyPattern constant Y2018.Text.Regex.PatternPack.Pattern_AC;
		i:Integer:=1;
		key : Unbounded_Wide_Wide_String;
		value : Unbounded_Wide_Wide_String;
		thisC : OM_ty.Cursor;
		r:Tool.M_AAAC;
	begin
		--Qappend(Knase,"arg2om");
		while i<= Ada.Command_Line.Argument_Count loop
			 null;--|Qappend(Fnatte,"ARG[" + Tool.LeftStrip(Integer'Image(i),' 'W) + "]=" + Ada.Command_Line.Argument(i));
			if Tool.matchTo(Ada.Command_Line.Argument(i),argPattern,r) then
				key:=Tool.StripP(r(1).all,stripPattern);
				value:=Tool.StripP(r(2).all,stripPattern);
				if Wide_Wide_Unbounded.Length(key)>0 then
					thisC:=OM_ty.Find(om,key);
					if OM_ty.Has_Element(thisC) then
						Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t"W+"Allready exists:"+key);
					else
						OM_ty.Insert(om,key,value);
						-- Qappend(Fnatte,"OM |" + key + "=" + value);
					end if;
				end if;
			elsif matchTo(Ada.Command_Line.Argument(i),propertyPattern,Y2018.Text.Regex.PatternPack.G_UPPERCASE) then
				populateOM(Ada.Command_Line.Argument(i));
			else
				Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\t"W+"Unknown argument:"+Ada.Command_Line.Argument(i));
			end if;
			i:=i+1;
		end loop;
		thisC:=OM_ty.Find(om,NUW + "l"W);
		if OM_ty.Has_Element(thisC) then
			thisC:=OM_ty.First(om);
			while OM_ty.Has_Element(thisC) loop
				key  := OM_ty.Key(thisC);
				value:= OM_ty.Element(thisC);
				Ada.Text_IO.Put_Line(Ada.Text_IO.Standard_Error,"" + "\t"W + key + "=" + value);
				OM_ty.Next(thisC);
			end loop;  
		end if;
	end arg2om;
	
	procedure listAttr(name:Wide_Wide_String;attr:Wide_Wide_String) is
		s : Unbounded_Wide_Wide_String:=NUW + attr;
		thisC: Y2018.Text.Regex.PatternPack.G_Cursor;
		thisE: Y2018.Text.Regex.MatchPack.Match_AC;
	begin
		--Qappend(kajsa,"S",""W + s);
		loop
			thisC:=Y2018.Text.Regex.PatternPack.matches(attrPattern,""W + s);
			if Y2018.Text.Regex.PatternPack.has_Element(thisC) then
				thisE:=Y2018.Text.Regex.PatternPack.element(thisC);
				declare
					qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisE);
				begin
					Print(P_ATTR,name + "."W + qr(1).all,replix(""W + qr(2).all));
				end;
			else
				exit;
			end if;
			s:=NUW + Y2018.Text.Regex.PatternPack.source(thisC);
		end loop;
		--Qappend(kajsa,"TAIL",""W + s);
	end listAttr;

	function replix (s:Wide_Wide_String) return Wide_Wide_String is
		found:Boolean:=FALSE; 
	begin
		for i in s'First .. s'Last loop
			if s(i) = '&'W then
				found:=TRUE;
				exit;
			end if;
		end loop;
		if found then
			declare
				w : Unbounded_Wide_Wide_String:=NUW + s;
				thisC: Y2018.Text.Regex.PatternPack.G_Cursor;
				thisE: Y2018.Text.Regex.MatchPack.Match_AC;
				v : Unbounded_Wide_Wide_String;
				thatC : OM_ty.Cursor;
			begin
				 null;--|Qappend(kajsa,"w",""W + w);
				loop
					thisC:=Y2018.Text.Regex.PatternPack.matches(replixPattern,""W + w);
					if Y2018.Text.Regex.PatternPack.has_Element(thisC) then
						thisE:=Y2018.Text.Regex.PatternPack.element(thisC);
						declare
							qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisE);
						begin
							v:=v + qr(1).all;
							thatC:=OM_ty.Find(om,qr(2).all);
							if OM_ty.Has_Element(thatC) then
								v:=v + OM_ty.Element(thatC);
							else
								v:=v + qr(2).all;
							end if;
						end;
					else
						exit;
					end if;
					w:=NUW + Y2018.Text.Regex.PatternPack.source(thisC);
				end loop;
				return ""W + v + w;
			end;
		else
			return s;
		end if;
	end replix;
	--.............................--
	--  PutLineCount               --
	--.............................--
	procedure PutLineCount(v:Integer) is
		BS:constant Character:=Character'Val(16#08#);
	begin
		Put (Ada.Text_IO.Standard_Error,
			Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(v),Ada.Strings.Left),6,' ') & ':' &
			Ada.Strings.Fixed."*"(7*1,BS));
	end PutLineCount;

begin
	 null;--|Qinit("--- Begin of XMLfilter ---");
	arg2om;
	
	-- Set GLOBAL switches
	omC:=OM_ty.Find(om,NUW + "beg.attr"W);
	if OM_ty.Has_Element(omC) then
		list_beg_attr:=TRUE;
	end if;
	omC:=OM_ty.Find(om,NUW + "width");
	if OM_ty.Has_Element(omC) then
		if Tool.matchTo(OM_ty.Element(omC),digitPattern,r) then
			print_width:=Integer'Value("" + r(1).all);
		end if;
	end if;
	loop
		 null;--|Qappend(Fnatte,ST_ty'Image(state));
		 null;--|Qappend(Fnatte,"buffer:" + buffer + "|");
		if getMoreData /=BAD then
			if End_Of_File then
				case getMoreData is
					when UGLY =>
						state:=ST_ERROR;
					when others =>
						state:=ST_SUCCESS;
				end case;
			else
				inputLine:=NUS + Get_Line;
				lncnt:=lncnt + 1;
				PutLineCount(lncnt);
				buffer:=buffer + inputLine + " "W;
				getMoreData:=BAD;
			end if;
		end if;
		if state = ST_SUCCESS then
			exit;
		elsif state = ST_ERROR then
			exit;
		end if;
		case state is
			when ST_ZERO =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(.*?)("W +
				"<\\?XML|"W +
				"<!DOCTYPE|"W +
				"<!\\[|"W +
				"<!--|"W +
				"</|"W +
				"<(?:[\s]*>|[\w])"W +
				")"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
						-- NOTE qr: Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA is 
						-- array (Integer range <>) of Unbounded_Wide_Wide_String_AC;
					begin
						if qr(1) = null then
							qr(1):=zero;
						end if;
						if qr(2) = null then
							qr(2):=zero;
						end if;
						
						declare
							prefix:Wide_Wide_String:=""W + qr(1).all;
							tag:Wide_Wide_String:=""W + qr(2).all;
						begin
							if Tool.matchTo(prefix,notBlankPattern) then
								Print(P_DA,""W,Tool.StripP(prefix,stripPattern));
							end if;
							if tag(2) = '?'W then -- <?XML
								state:=ST_XML;
							elsif tag(2) = '!'W then
								if tag(3) = 'D'W or tag(3) = 'd'W then -- <!DOCTYPE
									state:=ST_DOC;
								elsif tag(3) = '['W then
									state:=ST_MS;
								else -- <!--
									state:=ST_COM;
								end if;
							elsif tag(2) = '/'W then -- </
								state:=ST_END;
							else
								state:=ST_BEG_SHORT; 
							end if;
							buffer:=NUW + tag + Y2018.Text.Regex.PatternPack.source(thisCursor);
						end;
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_XML =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(<\\?XML(.*?)\\?>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_XML,""W,ttag);
							--Ada.Text_IO.Put_Line ("XML: " + ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_DOC =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(<!DOCTYPE(.*?)>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_DOC,""W,ttag);
							--Ada.Text_IO.Put_Line ("DOC: " + ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_COM =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(<!--(.*?)-->)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tval:Wide_Wide_String:=""W + qr(2).all;
						begin
							Print(P_COM,""W,ttag); 
							--Ada.Text_IO.Put_Line ("COM: " + ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_MS =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(<!\\[[\s]*(IGNORE|INCLUDE|CDATA|RCDATA|TEMP)[\s]*\\[(.*?)\\]\\]>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							ttype:Wide_Wide_String:=Tool.To_UC(""W + qr(2).all);
							tval:Wide_Wide_String:=""W + qr(3).all;
						begin
							Print(P_MS,ttype,ttag);
							--Ada.Text_IO.Put_Line ("MS_"+ttype+": " + ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_END =>
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(</([-\\.\w]*?)(.*?)>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tname:Wide_Wide_String:=""W + qr(2).all;
							tattr:Wide_Wide_String:=""W + qr(3).all;
						begin
							w:=NUW;
							--Ada.Text_IO.Put_Line ("END: " + ttag);
							if Stack_ty.Is_Empty(stack) then
								null;
							elsif tname'Length = 0 then
								null;
							else
								i:=1;
								dellu:=FALSE;
								stackC:=Stack_ty.Last(stack);
								while Stack_ty.Has_Element(stackC) loop
									stackE:=Stack_ty.Element(stackC);
									if ""W + stackE.n = tname then
										w:=NUW + tname + Integer'Image(StackE.stackLength);
										--Ada.Text_IO.Put_Line("*END: " + tname + Integer'Image(StackE.stackLength));
										dellu:=TRUE;
										exit;
									end if;
									stackC:=Stack_ty.Previous(stackC);
									i:=i + 1;
								end loop;
								if dellu then
									while i>0 loop
										if Stack_ty.Is_Empty(stack) then
											Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\tUnbalanced"W);
											exit;
										end if;
										Stack_ty.Delete_Last(stack);
										 null;--|Qappend(Tjatte,"DEL");
										i:=i - 1;
									end loop;
								end if;
							end if;
							Print(P_END,""W + w,ttag);
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when ST_BEG_SHORT =>
				--thisPattern:=Y2018.Text.Regex.PatternPack.compile("^(<([-\\.\w]*?)(.*?)>)"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisPattern:=Y2018.Text.Regex.PatternPack.compile("^((?:<[\s]*>|<([\w][-\\.\w]*?)(.*?)>))"W,Y2018.Text.Regex.PatternPack.G_UPPERCASE);
				thisCursor:=Y2018.Text.Regex.PatternPack.matches(thisPattern,""W + buffer);
				if Y2018.Text.Regex.PatternPack.has_Element(thisCursor) then
					thisElement:=Y2018.Text.Regex.PatternPack.element(thisCursor);
					declare
						qr:Y2018.Text.Regex.MatchPack.Unbounded_Wide_Wide_String_AA:=Y2018.Text.Regex.Matchpack.getMatch(thisElement);
					begin
						if qr(1) = null then
							qr(1):=zero;
						end if;
						if qr(2) = null then
							qr(2):=zero;
						end if;
						if qr(3) = null then
							qr(3):=zero;
						end if;
						declare
							ttag:Wide_Wide_String:=""W + qr(1).all;
							tname:Wide_Wide_String:=Tool.to_LC(""W + qr(2).all);
							tattr:Wide_Wide_String:=""W + qr(3).all;
						begin
							if Tool.matchTo(tattr,shortPattern,r) then
								Print(P_SHORT,tname,ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
							elsif isShorted("tag."W,tname) then
								Print(P_BEG,tname,ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
							else
								Print(P_BEG,tname + Integer'Image(Integer(Stack_ty.Length(stack))),ttag);
								if list_beg_attr then
									listAttr(tname,tattr);
								end if;
								Stack_ty.Append(Container => stack, New_Item => (n => NUW + tname, stackLength => Integer(Stack_ty.Length(stack))));
							end if;
							state:=ST_ZERO;
						end;
						buffer:=NUW + Y2018.Text.Regex.PatternPack.source(thisCursor);
					end;
				elsif getMoreData=BAD then
					getMoreData:=GOOD;
				else
					null;
				end if;
			when others =>
				null;
		end case;
	end loop;
	if Tool.matchTo(buffer,notBlankPattern) then
		Print(P_DA,""W,Tool.StripP(""W + buffer,stripPattern));
	end if;
	 null;--|Qappend(Kalle,"End of XMLfilter");
	Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error,""+"\n\tEnd of XMLfilter"W);
end XMLfilter;


