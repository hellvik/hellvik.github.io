-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190407173029.
-- ############################## RangeVectorPack.adb ##############################
with Y2018.Text.Core; use Y2018.Text.Core;
with Y2018.Text.Core.GC;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.Msg;
with Ada.Containers.Ordered_Maps;
with Ada.Containers.Ordered_Sets;
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
package body Y2018.Text.Jets.RangeVectorPack is
	
-- ############################## rvTool.adb ##############################
function less(f,l:Velem) return Boolean is
begin
	if f.f = l.f and f.l = l.l then
		return FALSE;
	elsif f.f < l.f then
		return TRUE;
	elsif f.f = l.f and f.l < l.l then
		return TRUE;
	else 
		return FALSE;
	end if;
end less;

function equal (f,l:Velem) return Boolean is
begin
	if f.f = l.f and f.l = l.l then
		return TRUE;
	end if;
	return FALSE; 
end equal;

	function exists(rvA:RangeVector;val:Wide_Wide_Character) return Boolean is
		c: Set_TY.Cursor;
		e: Velem;
		v: Integer:=Wide_Wide_Character'Pos(val);
	begin
		--Qappend(Kalle,"rvTool.exists v",v);
		for c in Set_TY.Iterate(rvA.v) loop
			e:=Set_TY.Element(c);
			--Qappend(Kalle,"rvTool.exists",e.f,e.l);
			if e.f <= v and e.l >= v then return true; end if;
		end loop;
		return false;
	end exists;
	procedure put(rvA:in out RangeVector;f:Wide_Wide_Character;l:Wide_Wide_Character) is
		q:Velem;
	begin
		if f<= l then
			q.f:=Wide_Wide_Character'Pos(f);
			q.l:=Wide_Wide_Character'Pos(l);
		else
			q.f:=Wide_Wide_Character'Pos(l);
			q.l:=Wide_Wide_Character'Pos(f);
		end if;
		Set_TY.Insert(Container => rvA.v, New_Item => q);
	end put;

	procedure put(rvA:in out RangeVector;val:Wide_Wide_Character) is
		q:Velem:=(f => Wide_Wide_Character'Pos(val), l => Wide_Wide_Character'Pos(val));
	begin
		Set_TY.Insert(Container => rvA.v, New_Item => q);
	end put;

	procedure putGC(rvA:in out RangeVector;val:Wide_Wide_String) is 
		high:Integer;
		low:Integer;
		mid:Integer;
		q:Velem;
		found:Boolean:=FALSE;
		d:Integer;
	begin
		--Qappend(Knase,"putGC-2",val);
		if val'Length /= 2 then return; end if;
		low:=GC.u'First(1);
		high:=GC.u'Last(1);
		while low <= high loop
			if GC.u(low).c = val then
				found:=TRUE;
				high:=low; 
				exit;
			end if;
			if GC.u(high).c = val then
				found:=TRUE;
				low:=high;
				exit; 
			end if;
			if low + 1 >= high then
				--raise Program_Error with "E2002 putGC. Cannot find [\p{" & UTF.to8(val) & "}]"; -- exptions
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(2002,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,UTF.to8(val));
			end if;
			d:=(high - low) / 2;
			mid:=low + d;
			if GC.u(mid).c = val then
				found:=TRUE;
				low:=mid;
				high:=mid;
				exit; 
			end if;
			if GC.u(mid).c > val then
				high := mid;
			else
				low := mid;
			end if;
		end loop;
		--Qappend(Knase,"putGC-2");
		if found then
			--Qappend(Kalle,"FOUND val=" & UTF.To8(val));
			while TRUE loop
				if low = GC.u'First(1)
				then
					exit;
				end if;
				if GC.u(low - 1).c = GC.u(low).c 
				then
					low:=low - 1;
				else
					exit;
				end if;  
			end loop;
			while TRUE loop
				if high = GC.u'Last(1)
				then
					exit;
				end if;
				if GC.u(high + 1).c = GC.u(high).c
				then
					high:=high + 1;
				else
					exit;
				end if;  
			end loop;
			while low <= high loop
				q.f:=GC.u(low).f;
				q.l:=GC.u(low).l;
				Set_TY.Insert(Container => rvA.v, New_Item => q);
				low:=low + 1;
			end loop;
		end if;
		return;
	end putGC;

	procedure putGC(rvA:in out RangeVector;val:Wide_Wide_Character) is 
		high:Integer;
		low:Integer;
		mid:Integer;
		found:Boolean:=FALSE;
		q:Velem;
		d:Integer;
		vs:Wide_Wide_String(1..1);
	begin
		low:=GC.u'First(1);
		high:=GC.u'Last(1);
		while low <= high loop
			if GC.u(low).c(1) = val then
				found:=TRUE;
				high:=low; 
				exit;
			end if;
			if GC.u(high).c(1) = val then
				found:=TRUE;
				low:=high;
				exit; 
			end if;
			if low + 1 >= high then
				vs(1):=val;
				--raise Program_Error with "E2003 putGC. Cannot find [\p{" & UTF.to8(vs) & "}]"; -- exptions
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(2003,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,UTF.to8(vs));
			end if;
			d:=(high - low) / 2;
			mid:=low + d;
			if GC.u(mid).c(1) = val then
				found:=TRUE;
				low:=mid;
				high:=mid;
				exit; 
			end if;
			if GC.u(mid).c(1) > val then
				high := mid;
			else
				low := mid;
			end if;
		end loop;
		if found then
			--Qappend(Kalle,"FOUND val=" & UTF.To8(vs));
			while TRUE loop
				if low = GC.u'First(1)
				then
					exit;
				end if;
				if GC.u(low - 1).c(1) = GC.u(low).c(1) 
				then
					low:=low - 1;
				else
					exit;
				end if;  
			end loop;
			while TRUE loop
				if high = GC.u'Last(1)
				then
					exit;
				end if;
				if GC.u(high + 1).c(1) = GC.u(high).c(1)
				then
					high:=high + 1;
				else
					exit;
				end if;  
			end loop;
			while low <= high loop
				q.f:=GC.u(low).f;
				q.l:=GC.u(low).l;
				Set_TY.Insert(Container => rvA.v, New_Item => q);
				low:=low + 1;
			end loop;
		end if;
		return;
	end putGC;

	function length(rvA:RangeVector) return Integer is
	begin
		return Integer(Set_TY.Length(rvA.v));
	end length;

	
-- ############################## rvList.adb ##############################
-- ############################## rvMerge.adb ##############################
procedure merge(rvA:in out RangeVector;force:Boolean) is
	vcursor: Set_TY.Cursor;
	ve:Velem:=null_velem;
	me:Velem:=null_velem;
	ok:Boolean:=FALSE;
begin
	for vcursor in Set_TY.Iterate(rvA.v) loop
		ve:=Set_TY.Element(vcursor);
		if ok then
			if ve.f = me.f then
				Set_TY.Delete(rvA.v,me);
			end if;
		else
			ok:=TRUE;
		end if;
		me:=ve;
	end loop;
end merge;

function equal (f,l:RangeVector) return Boolean is
	fcursor: Set_TY.Cursor;
	lcursor: Set_TY.Cursor;
	fe:Velem:=null_velem;
	le:Velem:=null_velem;
begin
	fcursor:=Set_TY.First(f.v);
	lcursor:=Set_TY.First(l.v);
	while Set_TY.Has_Element(fcursor) and Set_TY.Has_Element(lcursor) loop
		fe:= Set_TY.Element(fcursor);
		le:= Set_TY.Element(lcursor);
		if fe.f = le.f and fe.l = le.l then
			null;
		else
			return FALSE;
		end if;
		Set_TY.next(fcursor);
		Set_TY.next(lcursor);
	end loop;
	if Set_TY.Has_Element(fcursor)=FALSE and Set_TY.Has_Element(lcursor)=FALSE then
		return TRUE;
	end if;
	return FALSE;
end equal;
function less (f,l:RangeVector) return Boolean is
	fcursor: Set_TY.Cursor;
	lcursor: Set_TY.Cursor;
	fe:Velem:=null_velem;
	le:Velem:=null_velem;
begin
	fcursor:=Set_TY.First(f.v);
	lcursor:=Set_TY.First(l.v);
	while Set_TY.Has_Element(fcursor) and Set_TY.Has_Element(lcursor) loop
		fe:= Set_TY.Element(fcursor);
		le:= Set_TY.Element(lcursor);
		if fe.f < le.f then
			Set_TY.next(fcursor);
		elsif le.f < fe.f then
			Set_TY.next(lcursor);
		elsif fe.f = le.f and fe.l < le.l then
			Set_TY.next(fcursor);
		elsif le.f = fe.f and le.l < fe.l then
			Set_TY.next(lcursor);
		else
			Set_TY.next(fcursor);
			Set_TY.next(lcursor);
		end if;
	end loop;
	if Set_TY.Has_Element(fcursor)=FALSE and Set_TY.Has_Element(lcursor)=FALSE then
		return FALSE;
	elsif Set_TY.Has_Element(fcursor)=FALSE then
		return TRUE;
	else
		return FALSE;
	end if;
end less;
	
-- ############################## RangeVectorPackTail.adb ##############################
end Y2018.Text.Jets.RangeVectorPack;
