-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- ############################## Jets.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers.Ordered_Sets;
with Ada.Text_IO; use Ada.Text_IO;
with Y2018.Text.Core;
with Y2018.Text.Core.C32;
package Y2018.Text.Jets is
-- ############################## meta.ads ##############################

	type TRINITY is (GOOD,BAD,UGLY);
	type I_A is array (1..2) of Integer;

	type MCHAR_AR is Array(Integer range <>) of Wide_Wide_Character;

	MvertLine : constant Wide_Wide_Character   :=Wide_Wide_Character'Val(16#7C#); --  |
	MleftPal : constant Wide_Wide_Character    :=Wide_Wide_Character'Val(16#28#); -- (
	MrightPal : constant Wide_Wide_Character   :=Wide_Wide_Character'Val(16#29#); -- )
	MleftSquare : constant Wide_Wide_Character :=Wide_Wide_Character'Val(16#5B#); -- [
	MrightSquare : constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#5D#); -- ]
	MleftCurly : constant Wide_Wide_Character  :=Wide_Wide_Character'Val(16#7B#); -- {
	MrightCurly : constant Wide_Wide_Character :=Wide_Wide_Character'Val(16#7D#); -- }
	Mcircumflex : constant Wide_Wide_Character :=Wide_Wide_Character'Val(16#5E#); -- ^
	Mdollar : constant Wide_Wide_Character     :=Wide_Wide_Character'Val(16#24#); -- $
	Masterix : constant Wide_Wide_Character    :=Wide_Wide_Character'Val(16#2A#); -- *
	Mplus : constant Wide_Wide_Character       :=Wide_Wide_Character'Val(16#2B#); -- +
	Mquestion : constant Wide_Wide_Character   :=Wide_Wide_Character'Val(16#3F#); -- ?
	Mperiod : constant Wide_Wide_Character     :=Wide_Wide_Character'Val(16#2E#); -- .

	MCHAR:constant MCHAR_AR:=(MvertLine,MleftPal,MrightPal,MleftSquare,MrightSquare,MleftCurly,MrightCurly,Mcircumflex,Mdollar,Masterix,Mplus,Mquestion,Mperiod);

	Mlc_d: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#64#); --d
	Muc_d: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#44#); --D
	Mlc_s: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#73#); --s
	Muc_s: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#53#); --S
	Mlc_w: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#77#); --w
	Muc_w: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#57#); --W
	Mlc_p: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#70#); --p
	Muc_p: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#50#); --P
	backSlash: constant Wide_Wide_Character:= Wide_Wide_Character'Val(16#5C#); --\

	I_A_NO_ELEMENT : constant I_A:=(-1,0);
	
-- ############################## req.ads ##############################
type REQ_TY is (REQ_BEGIN, REQ_CHAR, REQ_PERIOD, REQ_CLASS_ELEM, REQ_CLASS, 
				 REQ_PALCAP, REQ_PAL, REQ_UPDOWN, REQ_CLASS_CHAR, REQ_CLASS_RANGE, 
				 REQ_CLASS_GC, REQ_CLASS_GCU, REQ_CLASS_OTHER, REQ_POS, REQ_NEG,
				 REQ_NULL);
-- ${Y2018.Text.Regex=}
--<p>type REQ_TY is</p>
-- <ul>
-- <li>REQ_BEGIN<br></li> 
-- <li>REQ_CHAR<br></li>
-- <li>REQ_PERIOD<br></li>
-- <li>REQ_CLASS_ELEM<br></li>
-- <li>REQ_CLASS<br></li>
-- <li>REQ_PALCAP<br></li>
-- <li>REQ_PAL<br></li>
-- <li>REQ_UPDOWN<br></li>
-- <li>REQ_CLASS_CHAR<br></li>
-- <li>REQ_CLASS_RANGE<br></li>
-- <li>REQ_CLASS_GC<br></li>
-- <li>REQ_CLASS_GCU<br></li>
-- <li>REQ_CLASS_OTHER<br></li>
-- <li>REQ_POS<br></li>
-- <li>REQ_NEG<br></li>
-- <li>REQ_NULL<br></li>
-- </ul>
-- ${}
-- ############################## JetsTail.adb ##############################
end Y2018.Text.Jets;
