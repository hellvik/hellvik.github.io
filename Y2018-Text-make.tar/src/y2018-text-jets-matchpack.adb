-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- ############################## MatchPack.adb ##############################
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers.Ordered_Maps;
with Y2018.Text.Jets.RegexTool; --use Y2018.Text.Jets.RegexTool;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Core.Msg;
with Y2018.Text.Core.Tool;
package body Y2018.Text.Jets.MatchPack is
-- ############################## matchPackOp.adb ##############################
function MatchID2RE_ID_less(Left, Right : MatchID) return Boolean is
begin
	return Left < Right;
end MatchID2RE_ID_less;
function MatchID2RE_ID_equal(Left, Right : RE_ID) return Boolean is
begin
	return Left = Right;
end MatchID2RE_ID_equal;

function RE_ID2MatchID_less(Left, Right : RE_ID) return Boolean is
begin
	return Left < Right;
end RE_ID2MatchID_less;
function RE_ID2MatchID_equal(Left, Right : MatchID) return Boolean is
begin
	return Left = Right;
end RE_ID2MatchID_equal;

function new_Match return Match_AC is
	y : Match_AC;
begin
	y := new Match;
	return y;
end new_Match;

procedure insert(matchValue:Match_AC;s:Unbounded_Wide_Wide_String;f:Integer;l:Integer;re:RE_Elem_AC) is
	mc:MatchID2RE_ID_TY.Cursor;
	kr:KElem;
begin
	if re=null then
		--raise Program_Error with "E4001 MatchPack.insert"; -- exception;
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4001,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	elsif re.V /= REQ_PALCAP then
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4002,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
	mc:=MatchID2RE_ID_TY.Find(matchValue.map,re.palcap_trackcount);
	if MatchID2RE_ID_TY.Has_Element(mc) then
		null;
	else
		kr.c:=re;
		kr.f:=f;
		kr.l:=l;
		RE_ID2KElem_TY.Insert(matchValue.v,re.id,kr);
		MatchID2RE_ID_TY.Insert(matchValue.map,re.palcap_trackcount,re.id);
	end if;
end insert;

function getMatch2(matchValue:Match_AC;mid:MatchID) return ValueOfMatch is
	id:RE_ID;
	mc:MatchID2RE_ID_TY.Cursor;
	c:RE_ID2KElem_TY.Cursor;
	ele:KElem;
	vom:ValueOfMatch:=(f=>1,l=>0);
begin
	mc:=MatchID2RE_ID_TY.Find(matchValue.map,mid);
	if MatchID2RE_ID_TY.Has_Element(mc) then
		id:=MatchID2RE_ID_TY.Element(mc);
	else
		return vom;
	end if;
	c:=RE_ID2KElem_TY.Find(matchValue.v,id);
	if RE_ID2KElem_TY.Has_Element(c) then
		ele:=RE_ID2KElem_TY.Element(c);
		vom.f:=ele.f;
		vom.l:=ele.l;
		return vom;
	else
		--raise Program_Error with "E4005 MatchPack.getMatch2"; -- exception;
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4005,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
end getMatch2;

function hasMatch(matchValue:Match_AC;mid:MatchID) return Boolean is
	mc:MatchID2RE_ID_TY.Cursor;
begin
	mc:=MatchID2RE_ID_TY.Find(matchValue.map,mid);
	return MatchID2RE_ID_TY.Has_Element(mc);
end hasMatch;

function count(matchValue:Match_AC) return Integer is
	mc:MatchID2RE_ID_TY.Cursor;
	c:RE_ID2KElem_TY.Cursor;
	ele:KElem;
	id:RE_ID;
begin
	mc:=MatchID2RE_ID_TY.Find(matchValue.map,0);
	if MatchID2RE_ID_TY.Has_Element(mc) then
		id:=MatchID2RE_ID_TY.Element(mc);
	else
		return 0;
	end if;
	c:=RE_ID2KElem_TY.Find(matchValue.v,id);
	if RE_ID2KElem_TY.Has_Element(c) then
		ele:=RE_ID2KElem_TY.Element(c);
		return ele.c.palcap_begin.begin_trackcount;
	else
		--raise Program_Error with "E4004 MatchPack.count"; -- exception;
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4004,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
end count;

procedure delete(matchValue:Match_AC;trackcount:Integer) is
	function qless(Left, Right:RE_ID) return Boolean is begin return Left < Right; end qless;
	function qequal(Left, Right:RE_ID) return Boolean is begin return Left = Right; end qequal;
	package RESET_TY is new Ada.Containers.Ordered_Sets(
		Element_type => RE_ID,
		"<"=> qless,
		"="=> qequal);
	delset: RESET_TY.Set;
	delcur: RESET_TY.Cursor;
	wreid:RE_ID;
	wmid :MatchID;
	k:KElem;
	--
	vcur: RE_ID2KElem_TY.Cursor;
	mcur:MatchID2RE_ID_TY.Cursor;
begin
	mcur:=MatchID2RE_ID_TY.First(matchValue.map);
	while MatchID2RE_ID_TY.Has_Element(mcur) loop
		if MatchID2RE_ID_TY.Key(mcur) >= trackcount then
			wreid:=MatchID2RE_ID_TY.Element(mcur);
			RESET_TY.Insert(delset,wreid);
		end if;
		MatchID2RE_ID_TY.Next(mcur);
	end loop;
	delcur:=RESET_TY.First(delset);
	while RESET_TY.Has_Element(delcur) loop
		wreid:=RESET_TY.Element(delcur);
		--
		vcur:=RE_ID2KElem_TY.Find(matchValue.v,wreid);
		if RE_ID2KElem_TY.Has_Element(vcur) then
			k:=RE_ID2KElem_TY.Element(vcur);
			wmid:=k.c.palcap_trackcount;
			RE_ID2KElem_TY.Delete(matchValue.v,vcur);
--			Qappend(Kajsa,"......: VALUE ",To_Wide_Wide_String(k.r));
		end if;
		--
		mcur:=MatchID2RE_ID_TY.Find(matchValue.map,wmid);
		if MatchID2RE_ID_TY.Has_Element(mcur) then
			MatchID2RE_ID_TY.Delete(matchValue.map,mcur);
		end if;
		--
		RESET_TY.Next(delcur);
	end loop;
end delete;

procedure merge(target_matchValue:Match_AC;source_matchValue:Match_AC) is
	k:KElem;
	reid:RE_ID;
	mid:MatchID;
	source_mcur:MatchID2RE_ID_TY.Cursor;
	target_mcur:MatchID2RE_ID_TY.Cursor;
	source_vcur:RE_ID2KElem_TY.Cursor;
	target_vcur:RE_ID2KElem_TY.Cursor;
begin
	source_mcur:=MatchID2RE_ID_TY.First(source_matchValue.map);
	while MatchID2RE_ID_TY.Has_Element(source_mcur) loop
		mid:=MatchID2RE_ID_TY.Key(source_mcur);
		reid:=MatchID2RE_ID_TY.Element(source_mcur);
		target_mcur:=MatchID2RE_ID_TY.Find(target_matchValue.map,mid);
		if MatchID2RE_ID_TY.Has_Element(target_mcur) then
			null;
		else
			source_vcur:=RE_ID2KElem_TY.Find(source_matchValue.v,reid);
			if RE_ID2KElem_TY.Has_Element(source_vcur) then
				k:=RE_ID2KElem_TY.Element(source_vcur);
			else
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4006,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
			end if;
			target_vcur:=RE_ID2KElem_TY.Find(target_matchValue.v,reid);
			if RE_ID2KElem_TY.Has_Element(target_vcur) then
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4007,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
			end if;
			RE_ID2KElem_TY.Insert(target_matchValue.v,reid,k);
			MatchID2RE_ID_TY.Insert(target_matchValue.map,mid,reid);
		end if;
		MatchID2RE_ID_TY.Next(source_mcur);
	end loop;
end merge;

--		*===================*
--		!                   !
--		*===================*
function RE_ID2KElem_less(Left,Right:RE_ID) return Boolean is
begin
	return Left < Right;
end RE_ID2KElem_less;

function RE_ID2KElem_equal(Left,Right:KElem) return Boolean is
begin
	return Left.f = Right.f and Left.l = Right.l;
end RE_ID2KElem_equal;
-- ############################## MatchPackTail.adb ##############################
end Y2018.Text.Jets.MatchPack;
