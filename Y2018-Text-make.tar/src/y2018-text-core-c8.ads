-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
package Y2018.Text.Core.C8 is
	C8_1_LOW: constant Integer := 16#0#;
	C8_1_HIGH: constant Integer := 16#7F#;
	C8_2_LOW: constant Integer := 16#C0#;
	C8_2_HIGH: constant Integer := 16#DF#;
	C8_3_LOW: constant Integer := 16#E0#;
	C8_3_HIGH: constant Integer := 16#EF#;
	C8_4_LOW: constant Integer := 16#F0#;
	C8_4_HIGH: constant Integer := 16#F7#;

	C8_X_LOW: constant Integer := 16#80#;
	C8_X_HIGH: constant Integer := 16#BF#;
end Y2018.Text.Core.C8;
