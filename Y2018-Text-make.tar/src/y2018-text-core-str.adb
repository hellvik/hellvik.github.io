-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings;
with Y2018.Text.Core.UTF;

package body Y2018.Text.Core.STR is
	--function "&"(left:Wide_Wide_String;right:Wide_Wide_String) return Wide_Wide_String is -- [00]
	--begin
	--return System."&"(left,right);
	--end "&";
	function "&"(left:Wide_Wide_String;right:Wide_Wide_Character) return Wide_Wide_String is -- [01]
	r:Wide_Wide_String(1..1);
	begin
		r(1):=right;
		return left & r;
	end "&";
	function "&"(left:Wide_Wide_String;right:Unbounded_Wide_Wide_String) return Wide_Wide_String is -- [02]
	begin
		return "&"(left,To_Wide_Wide_String(right));
	end "&";
	function "&"(left:Wide_Wide_String;right:Unbounded_String) return Wide_Wide_String is -- [03]
	begin
		return "&"(left,UTF.To32(To_String(right)));
	end "&";
	function "&"(left:Unbounded_Wide_Wide_String;right:Wide_Wide_String) return Unbounded_Wide_Wide_String is -- [04]
	begin
		return To_Unbounded_Wide_Wide_String("&"(To_Wide_Wide_String(left),right));
	end "&";
	function "&"(left:Unbounded_Wide_Wide_String;right:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is -- [05]
	begin
		return To_Unbounded_Wide_Wide_String("&"(To_Wide_Wide_String(left),To_Wide_Wide_String(right)));
	end "&";
	function "&"(left:Unbounded_Wide_Wide_String;right:Unbounded_String) return Unbounded_Wide_Wide_String is -- [06]
	begin
		return To_Unbounded_Wide_Wide_String("&"(To_Wide_Wide_String(left),UTF.To32(To_String(right))));
	end "&";
	function "&"(left:Unbounded_String;right:Wide_Wide_String) return Unbounded_String is -- [07]
	begin
		return To_Unbounded_String(UTF.To8("&"(UTF.To32(To_String(left)),right)));
	end "&";
	function "&"(left:Unbounded_String;right:Unbounded_Wide_Wide_String) return Unbounded_String is -- [08]
	begin
		return To_Unbounded_String(UTF.To8("&"(UTF.To32(To_String(left)),To_Wide_Wide_String(right))));
	end "&";
	function "&"(left:Unbounded_String;right:Unbounded_String) return Unbounded_String is -- [09]
	begin
		return To_Unbounded_String(UTF.To8("&"(UTF.To32(To_String(left)),UTF.To32(To_String(right)))));
	end "&";
	function "&"(left:Unbounded_Wide_Wide_String;right:Wide_Wide_Character) return Unbounded_Wide_Wide_String is -- [10]
	begin
		return To_Unbounded_Wide_Wide_String("&"(To_Wide_Wide_String(left),right));
	end "&";
	function "&"(left:Unbounded_String;right:Wide_Wide_Character) return Unbounded_String is -- [11]
	begin
		return To_Unbounded_String(UTF.To8("&"(UTF.To32(To_String(left)),right)));
	end "&";
	function "&"(left:Wide_Wide_Character;right:Wide_Wide_String) return Wide_Wide_String is -- [12]
		l:Wide_Wide_String(1..1);
	begin
		l(1):=left;
		return l & right;
	end "&";
	function "&"(left:Wide_Wide_Character;right:Wide_Wide_Character) return Wide_Wide_String is -- [13]
		l:Wide_Wide_String(1..1);
		r:Wide_Wide_String(1..1);
	begin
		l(1):=left;
		r(1):=right;
		return l & r;
	end "&";
	function "&"(left:Wide_Wide_Character;right:Unbounded_Wide_Wide_String) return Wide_Wide_String is -- [14]
		l:Wide_Wide_String(1..1);
	begin
		l(1):=left;
		return l & To_Wide_Wide_String(right);
	end "&";
	function "&"(left:Wide_Wide_Character;right:Unbounded_String) return Wide_Wide_String is -- [15]
		l:Wide_Wide_String(1..1);
	begin
		l(1):=left;
		return l & UTF.To32(To_String(right));
	end "&";
end Y2018.Text.Core.STR;
