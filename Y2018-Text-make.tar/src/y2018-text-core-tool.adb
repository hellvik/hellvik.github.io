-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
with Ada.Strings.UTF_Encoding; --use Ada.Strings.UTF_Encoding;
with Ada.Strings.UTF_Encoding.Conversions;
with Ada.Strings.UTF_Encoding.Wide_Wide_Strings; --use Ada.Strings.UTF_Encoding.Wide_Wide_Strings;
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings;
with Interfaces;
with Y2018.Text.Core;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.C32; use Y2018.Text.Core.C32;
with Y2018.Text.Core.Msg;

with Ada.Text_IO; use  Ada.Text_IO;

package body Y2018.Text.Core.Tool is
function To_Hex8(v :Wide_Wide_Character) return String is
begin
	return To_Hex8(Wide_Wide_Character'Pos(v));
end To_Hex8;
function To_Hex8(v :Character) return String is
	s : String(1 .. 8); 
	t : String(1 .. 2);
begin
	s:=To_Hex8(Character'Pos(v));
	if s(7) = '_' then t(1):= '0'; else t(1):=s(7); end if;
	t(2):=s(8);
	return t;
end To_Hex8;
function To_Hex8(v :Integer) return String is
	r : String(1..8):="_______0";
	k : Integer:=8;
	i : Long_Long_Integer;
begin
	if  v>=0 then i:= Long_Long_Integer(v);
	else i:= 16#100000000# + Long_Long_Integer(v); end if;
	while i > 0 loop
		case i mod 16 is
			when 0 => r(k):='0';
			when 1 => r(k):='1';
			when 2 => r(k):='2';
			when 3 => r(k):='3';
			when 4 => r(k):='4';
			when 5 => r(k):='5';
			when 6 => r(k):='6';
			when 7 => r(k):='7';
			when 8 => r(k):='8';
			when 9 => r(k):='9';
			when 10 => r(k):='A';
			when 11 => r(k):='B';
			when 12 => r(k):='C';
			when 13 => r(k):='D';
			when 14 => r(k):='E';
			when others => r(k):='F';
		end case;
		i:=i / 16;
		k:=k - 1;
	end loop;
	return r;
end To_Hex8;
function To_Hex8W(v :Wide_Wide_Character) return Wide_Wide_String is
begin
	return To_Hex8W(Wide_Wide_Character'Pos(v));
end To_Hex8W;

function To_Hex8W(v :Character) return Wide_Wide_String is
	s : Wide_Wide_String(1 .. 8); 
	t : Wide_Wide_String(1 .. 2);
begin
	s:=To_Hex8W(Character'Pos(v));
	if s(7) = Wide_Wide_Character'Val(16#5F#) then
		t(1):=Wide_Wide_Character'Val(16#30#); else t(1):=s(7); 
	end if;
	t(2):=s(8);
	return t;
end To_Hex8W;

function To_Hex8W(v :Integer) return Wide_Wide_String is
	r : Wide_Wide_String(1..8):="_______0";
	k : Integer:=8;
	i : Long_Long_Integer;
begin
	if  v>=0 then i:= Long_Long_Integer(v);
	else i:= 16#100000000# + Long_Long_Integer(v); end if;
	while i > 0 loop
		case i mod 16 is
			when 0 => r(k):=Wide_Wide_Character'Val(16#30#);--'0';
			when 1 => r(k):=Wide_Wide_Character'Val(16#31#);--'1';
			when 2 => r(k):=Wide_Wide_Character'Val(16#32#);--'2';
			when 3 => r(k):=Wide_Wide_Character'Val(16#33#);--'3';
			when 4 => r(k):=Wide_Wide_Character'Val(16#34#);--'4';
			when 5 => r(k):=Wide_Wide_Character'Val(16#35#);--'5';
			when 6 => r(k):=Wide_Wide_Character'Val(16#36#);--'6';
			when 7 => r(k):=Wide_Wide_Character'Val(16#37#);--'7';
			when 8 => r(k):=Wide_Wide_Character'Val(16#38#);--'8';
			when 9 => r(k):=Wide_Wide_Character'Val(16#39#);--'9';
			when 10 => r(k):=Wide_Wide_Character'Val(16#41#);--'A';
			when 11 => r(k):=Wide_Wide_Character'Val(16#42#);--'B';
			when 12 => r(k):=Wide_Wide_Character'Val(16#43#);--'C';
			when 13 => r(k):=Wide_Wide_Character'Val(16#44#);--'D';
			when 14 => r(k):=Wide_Wide_Character'Val(16#45#);--'E';
			when others => r(k):=Wide_Wide_Character'Val(16#46#);--'F';
		end case;
		i:=i / 16;
		k:=k - 1;
	end loop;
	return r;
end To_Hex8W;
function To_HexX(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 2;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FF# then null; else raise Program_Error with Y2018.Text.Core.Tool.getMsg(21,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); end if;
		for Q in 1..2 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexX;

function To_HexX(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexX(s,padding);
end To_HexX;
-- 20191103143745 GENERATED ADB ---
	function To_HexX(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexX(To_Wide_Wide_String(S),padding));
	end To_HexX;
	function To_HexX(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexX(UTF.To32(To_String(S)),padding)));
	end To_HexX;
	function To_HexX(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexX(To_Wide_Wide_String(s)));
	end To_HexX;
	function To_HexX(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexX(UTF.To32(To_String(s)))));
	end To_HexX;
-- END GENERATED ADB ---
function To_HexU(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 4;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FFFF# then null; else raise Program_Error with Y2018.Text.Core.Tool.getMsg(22,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); end if;
		for Q in 1..4 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexU;

function To_HexU(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexU(s,padding);
end To_HexU;
-- 20191103143745 GENERATED ADB ---
	function To_HexU(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexU(To_Wide_Wide_String(S),padding));
	end To_HexU;
	function To_HexU(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexU(UTF.To32(To_String(S)),padding)));
	end To_HexU;
	function To_HexU(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexU(To_Wide_Wide_String(s)));
	end To_HexU;
	function To_HexU(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexU(UTF.To32(To_String(s)))));
	end To_HexU;
-- END GENERATED ADB ---
function To_HexV(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 6;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FFFFFF# then null; else raise Program_Error with Y2018.Text.Core.Tool.getMsg(23,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); end if;
		for Q in 1..6 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexV;

function To_HexV(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexV(s,padding);
end To_HexV;
-- 20191103143745 GENERATED ADB ---
	function To_HexV(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexV(To_Wide_Wide_String(S),padding));
	end To_HexV;
	function To_HexV(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexV(UTF.To32(To_String(S)),padding)));
	end To_HexV;
	function To_HexV(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexV(To_Wide_Wide_String(s)));
	end To_HexV;
	function To_HexV(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexV(UTF.To32(To_String(s)))));
	end To_HexV;
-- END GENERATED ADB ---
function To_HexY(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 8;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		for Q in 1..8 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexY;

function To_HexY(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexY(s,padding);
end To_HexY;
-- 20191103143745 GENERATED ADB ---
	function To_HexY(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexY(To_Wide_Wide_String(S),padding));
	end To_HexY;
	function To_HexY(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexY(UTF.To32(To_String(S)),padding)));
	end To_HexY;
	function To_HexY(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexY(To_Wide_Wide_String(s)));
	end To_HexY;
	function To_HexY(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexY(UTF.To32(To_String(s)))));
	end To_HexY;
-- END GENERATED ADB ---
function Is_Valid(s:Wide_Wide_String) return Boolean is
	i : Integer;
begin
	for J in s'FIRST(1) .. s'LAST(1) loop
		i:=Wide_Wide_Character'Pos(s(J));
		if	(i in C32_1_LOW .. C32_1_HIGH) or
			(i in C32_2_LOW .. C32_2_HIGH) or
			(i in C32_3_LOW .. C32_3_HIGH) or
			(i in C32_4_LOW .. C32_4_HIGH) or
			(i in C32_5_LOW .. C32_5_HIGH) or
			(i in C32_6_LOW .. C32_6_HIGH) or
			(i in C32_7_LOW .. C32_7_HIGH) or
			(i in C32_8_LOW .. C32_8_HIGH) or
			(i in C32_9_LOW .. C32_9_HIGH) then
			null;
		else
			return FALSE;
		end if;	
	end loop;
	return TRUE;
end Is_Valid;

function Substr(S:Wide_Wide_String;pos:Integer;len:Integer) return Wide_Wide_String is
	blank : constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#20#);
	QC : Wide_Wide_Character;
	QS : Wide_Wide_String(1..len);
begin
	if len = 0 then return QS; end if;
	for QI in QS'First(1) .. QS'Last(1) loop
		if QI + pos -1 <= S'Last(1) and QI + pos -1 >= S'First(1) then
			QC := S(QI + pos -1);
			QS(QI) := QC;
		else
			QS(QI) := blank;
		end if;
	end loop;
	return QS;
end Substr;

function Substr(s:Wide_Wide_String;pos:Integer) return Wide_Wide_String is
begin
	return Substr(s,pos,s'LAST(1));
end Substr;
-- 20191103143746 GENERATED ADB ---
	function Substr(S:Unbounded_Wide_Wide_String;pos:Integer;len:Integer) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Substr(To_Wide_Wide_String(S),pos,len));
	end Substr;
	function Substr(S:Unbounded_String;pos:Integer;len:Integer) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Substr(UTF.To32(To_String(S)),pos,len)));
	end Substr;
	function Substr(s:Unbounded_Wide_Wide_String;pos:Integer) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Substr(To_Wide_Wide_String(s),pos));
	end Substr;
	function Substr(s:Unbounded_String;pos:Integer) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Substr(UTF.To32(To_String(s)),pos)));
	end Substr;
	function Is_Valid(s:Unbounded_Wide_Wide_String) return Boolean is
	begin
		return Is_Valid(To_Wide_Wide_String(s));
	end Is_Valid;
	function Is_Valid(s:Unbounded_String) return Boolean is
	begin
		return Is_Valid(UTF.To32(To_String(s)));
	end Is_Valid;
-- END GENERATED ADB ---
function CmpS(first:Wide_Wide_String;second:Wide_Wide_String) return Integer is
	l : Integer;
	f : Integer;
	fm : Wide_Wide_Character;
	sm : Wide_Wide_Character;
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	f:=first'FIRST(1);
	if f > second'FIRST(1) then f:=second'FIRST(1); end if;
	l:=first'LAST(1);
	if l < second'LAST(1) then l:=second'LAST(1); end if;
	for i in f .. l loop
		fm:=blank;
		sm:=blank;
		if (i >= first'FIRST(1)) and (i <= first'LAST(1)) then fm:=first(i); end if;
		if (i >= second'FIRST(1)) and (i <= second'LAST(1)) then sm:=second(i); end if;
		if fm > sm then return 1;
		elsif fm < sm then return -1; 
		end if;
	end loop;
	return 0;
end CmpS;
-- 20191103143746 GENERATED ADB ---
	function CmpS(first:Wide_Wide_String;second:Unbounded_Wide_Wide_String) return Integer is
	begin
		return CmpS(first,To_Wide_Wide_String(second));
	end CmpS;
	function CmpS(first:Wide_Wide_String;second:Unbounded_String) return Integer is
	begin
		return CmpS(first,UTF.To32(To_String(second)));
	end CmpS;
	function CmpS(first:Unbounded_Wide_Wide_String;second:Wide_Wide_String) return Integer is
	begin
		return CmpS(To_Wide_Wide_String(first),second);
	end CmpS;
	function CmpS(first:Unbounded_Wide_Wide_String;second:Unbounded_Wide_Wide_String) return Integer is
	begin
		return CmpS(To_Wide_Wide_String(first),To_Wide_Wide_String(second));
	end CmpS;
	function CmpS(first:Unbounded_Wide_Wide_String;second:Unbounded_String) return Integer is
	begin
		return CmpS(To_Wide_Wide_String(first),UTF.To32(To_String(second)));
	end CmpS;
	function CmpS(first:Unbounded_String;second:Wide_Wide_String) return Integer is
	begin
		return CmpS(UTF.To32(To_String(first)),second);
	end CmpS;
	function CmpS(first:Unbounded_String;second:Unbounded_Wide_Wide_String) return Integer is
	begin
		return CmpS(UTF.To32(To_String(first)),To_Wide_Wide_String(second));
	end CmpS;
	function CmpS(first:Unbounded_String;second:Unbounded_String) return Integer is
	begin
		return CmpS(UTF.To32(To_String(first)),UTF.To32(To_String(second)));
	end CmpS;
-- END GENERATED ADB ---

function Right(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	r : Wide_Wide_String(1 .. length);
	i : Integer;
	j : Integer;
begin
	if length < 0 then raise Program_Error with Y2018.Text.Core.Tool.getMsg(40,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); end if; 
	i:=length;
	j:=source'LAST(1);
	while i > 0 loop
		if j > 0 then
			r(i):=source(j);
		else
			r(i):=padding;
		end if;
		i := i - 1;
		j := j - 1;
	end loop;
	return r;
end Right;

function Left(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	r : Wide_Wide_String(1 .. length);
	i : Integer;
	j : Integer;
begin
	if length < 0 then raise Program_Error with Y2018.Text.Core.Tool.getMsg(41,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); end if; 
	i:=length;
	j:=source'LAST(1);
	while i <= length loop
		if j <= source'LAST(1) then
			r(i):=source(j);
		else
			r(i):=padding;
		end if;
		i := i + 1;
		j := j + 1;
	end loop;
	return r;
end Left;

function Center(S:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	R : Wide_Wide_String(1 .. length);
	upR : Integer;
	upS : Integer;
	dwR : Integer;
	dwS : Integer;
	ok : Boolean := TRUE;
	empty : Wide_Wide_String(1 .. 0);
begin
	if length = 0 then return empty; end if;
	upR:= (R'Last(1) - R'First(1) + 1) / 2; dwR:=upR - 1;
	upS:= (S'Last(1) - S'First(1) + 1) / 2; dwS:=upS - 1;
	while ok loop
		ok:= FALSE;
		if upR <= R'Last(1) then
			if upS <= S'Last(1) then
				R(upR):=S(upS);
			else
				R(upR):=padding;
			end if;
			ok:=TRUE;
		end if;
		if dwR >= 1 then
			if dwS >= 1 then
				R(dwR):= S(dwS);
			else
				R(dwR):=padding;
			end if;
			ok:=TRUE;
		end if;	
		upR := upR + 1; dwR := dwR - 1;
		upS := upS + 1; dwS := dwS - 1;
	end loop;
	return R;
end Center;

function LeftStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	for J in S'First(1) .. S'Last(1) loop
		if S(J) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'Last(1);
	SI:=S'Last(1);
	while RI >= 1 loop
		R(RI):=S(SI);
		RI:=RI-1;
		SI:=SI-1;
	end loop;
	return R.all;
end LeftStrip;

function RightStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'First(1);
	SI:=S'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end RightStrip;

function Strip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1;
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	SI:=S'First(1);
	while SI <= S'Last(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI + 1;
	end loop;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end Strip;

function LeftStrip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return LeftStrip(source,blank);
end LeftStrip;

function RightStrip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return RightStrip(source,blank);
end RightStrip;

function Strip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return Strip(source,blank);
end Strip;
-- 20191103143746 GENERATED ADB ---
	function Strip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Strip(To_Wide_Wide_String(S),padding));
	end Strip;
	function Strip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Strip(UTF.To32(To_String(S)),padding)));
	end Strip;
	function Strip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Strip(To_Wide_Wide_String(source)));
	end Strip;
	function Strip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Strip(UTF.To32(To_String(source)))));
	end Strip;
	function Center(S:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Center(To_Wide_Wide_String(S),length,padding));
	end Center;
	function Center(S:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Center(UTF.To32(To_String(S)),length,padding)));
	end Center;
	function LeftStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(LeftStrip(To_Wide_Wide_String(S),padding));
	end LeftStrip;
	function LeftStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(LeftStrip(UTF.To32(To_String(S)),padding)));
	end LeftStrip;
	function LeftStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(LeftStrip(To_Wide_Wide_String(source)));
	end LeftStrip;
	function LeftStrip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(LeftStrip(UTF.To32(To_String(source)))));
	end LeftStrip;
	function Left(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Left(To_Wide_Wide_String(source),length,padding));
	end Left;
	function Left(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Left(UTF.To32(To_String(source)),length,padding)));
	end Left;
	function Right(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Right(To_Wide_Wide_String(source),length,padding));
	end Right;
	function Right(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Right(UTF.To32(To_String(source)),length,padding)));
	end Right;
	function RightStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(RightStrip(To_Wide_Wide_String(S),padding));
	end RightStrip;
	function RightStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(RightStrip(UTF.To32(To_String(S)),padding)));
	end RightStrip;
	function RightStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(RightStrip(To_Wide_Wide_String(source)));
	end RightStrip;
	function RightStrip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(RightStrip(UTF.To32(To_String(source)))));
	end RightStrip;
-- END GENERATED ADB ---
function To8(v:Boolean) return String is
begin
	if v then return "TRUE";
	else return "FALSE"; end if;
end To8;

function To32(v:Boolean) return Wide_Wide_String is
begin
	if v then return UTF.To32("TRUE");
	else return UTF.To32("FALSE"); end if;
end To32;

function To8(v:Integer) return String is
	t: Unbounded_String;
begin
	t:=To_Unbounded_String(Integer'Image(v));
	return To_String(t);
end To8;

function To32(v:Integer) return Wide_Wide_String is
	t: Unbounded_String;
begin
	t:=To_Unbounded_String(Integer'Image(v));
	return UTF.To32(To_String(t));
end To32;

function Get_GC(c:Wide_Wide_Character) return Wide_Wide_String is
	val:Integer;
	high:Integer;
	low:Integer;
	mid: Integer;
	d: Integer;
	empty:constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#20#),Wide_Wide_Character'Val(16#20#)); 
begin
	val:=Wide_Wide_Character'Pos(c);
	low:=GC.a'First(1);
	high:=GC.a'Last(1);
	while low <= high loop
		if GC.a(low).f <= val and GC.a(low).l >= val then
			return GC.a(low).c; 
		end if;
		if GC.a(high).f <= val and GC.a(high).l >= val then
			return GC.a(high).c; 
		end if;
		if low + 1 >= high then return empty; end if;
		d:=(high - low) / 2;
		mid:=low + d;
		if GC.a(mid).f <= val and GC.a(mid).l >= val then
			return GC.a(mid).c; 
		end if;
		if GC.a(mid).f > val then
			high := mid;
		else
			low := mid;
		end if;
	end loop;
	return empty;
end Get_GC;

function Get_UC(c:Wide_Wide_Character) return Wide_Wide_Character is
	val:Integer;
	high:Integer;
	low:Integer;
	mid: Integer;
	d: Integer;
begin
	val:=Wide_Wide_Character'Pos(c);
	low:=ULTcase.a'First(1);
	high:=ULTcase.a'Last(1);
	while low <= high loop
		if ULTcase.a(low).f <= val and ULTcase.a(low).l >= val then
			if ULTcase.a(low).uc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(low).uc);
		end if;
		if ULTcase.a(high).f <= val and ULTcase.a(high).l >= val then
			if ULTcase.a(high).uc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(high).uc);
		end if;
		if low + 1 >= high then return c; end if;
		d:=(high - low) / 2;
		mid:=low + d;
		if ULTcase.a(mid).f <= val and ULTcase.a(mid).l >= val then
			if ULTcase.a(mid).uc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(mid).uc);
		end if;
		if ULTcase.a(mid).f > val then
			high := mid;
		else
			low := mid;
		end if;
	end loop;
	return c;
end Get_UC;

function Get_LC(c:Wide_Wide_Character) return Wide_Wide_Character is
	val:Integer;
	high:Integer;
	low:Integer;
	mid: Integer;
	d: Integer;
begin
	val:=Wide_Wide_Character'Pos(c);
	low:=ULTcase.a'First(1);
	high:=ULTcase.a'Last(1);
	while low <= high loop
		if ULTcase.a(low).f <= val and ULTcase.a(low).l >= val then
			if ULTcase.a(low).lc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(low).lc);
		end if;
		if ULTcase.a(high).f <= val and ULTcase.a(high).l >= val then
			if ULTcase.a(high).lc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(high).lc);
		end if;
		if low + 1 >= high then return c; end if;
		d:=(high - low) / 2;
		mid:=low + d;
		if ULTcase.a(mid).f <= val and ULTcase.a(mid).l >= val then
			if ULTcase.a(mid).lc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(mid).lc);
		end if;
		if ULTcase.a(mid).f > val then
			high := mid;
		else
			low := mid;
		end if;
	end loop;
	return c;
end Get_LC;

function Get_TC(c:Wide_Wide_Character) return Wide_Wide_Character is
	val:Integer;
	high:Integer;
	low:Integer;
	mid: Integer;
	d: Integer;
begin
	val:=Wide_Wide_Character'Pos(c);
	low:=ULTcase.a'First(1);
	high:=ULTcase.a'Last(1);
	while low <= high loop
		if ULTcase.a(low).f <= val and ULTcase.a(low).l >= val then
			if ULTcase.a(low).tc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(low).tc);
		end if;
		if ULTcase.a(high).f <= val and ULTcase.a(high).l >= val then
			if ULTcase.a(high).tc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(high).tc);
		end if;
		if low + 1 >= high then return c; end if;
		d:=(high - low) / 2;
		mid:=low + d;
		if ULTcase.a(mid).f <= val and ULTcase.a(mid).l >= val then
			if ULTcase.a(mid).tc = -1 then return c; end if;
			return Wide_Wide_Character'Val(ULTcase.a(mid).tc);
		end if;
		if ULTcase.a(mid).f > val then
			high := mid;
		else
			low := mid;
		end if;
	end loop;
	return c;
end Get_TC;

function To_UC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Get_UC(instr(J));
	end loop;
	return utstr;
end To_UC;
	
function To_LC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Get_LC(instr(J));
	end loop;
	return utstr;
end To_LC;

function To_TC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Get_TC(instr(J));
	end loop;
	return utstr;
end To_TC;

function getMsg(n:Integer;K:Y2018.Text.Core.IntegerArray;E:Y2018.Text.Core.StringArray_CAA;s1:String;s2:String;s3:String) return String is
	t: Unbounded_String;
	kLow: Integer:=K'First(1); -- Y2018.Text.Core.Msg.K
	kHigh: Integer:=K'Last(1);
	i:Integer:=-1;
	j:Integer;
	v:Integer;
	m:Integer:=-1;
	mi: Unbounded_String:=To_Unbounded_String("<NOT DOCUMENTED>");
	function image(i:Integer) return String is
		si:String:=Integer'Image(i+1000000);
		--                        Text....
	begin
		si(si'First):='T';
		si(si'First + 1):='e';
		si(si'First + 2):='x';
		si(si'First + 3):='t';
		return si;
	end image;
begin
	if n <= K(kHigh) and n >= K(kLow) then
		loop
			j:=kLow;
			v:=kHigh;
			if n=K(kLow) then
				m:=n;
				mi:=To_Unbounded_String(E(kLow).all);
				exit;
			elsif n=K(kHigh) then
				m:=n;
				mi:=To_Unbounded_String(E(kHigh).all);
				exit;
			else
				i:=kHigh - kLow;
				if i=0 then
					exit;
				else 
					i:=i / 2;
					if n=K(kLow + i) then
						m:=n;
						mi:=To_Unbounded_String(E(kLow + i).all);
						exit;
					elsif n < K(kLow + i) then
						kHigh:= kLow + i;
					elsif n > K(kLow + i) then
						kLow:= kLow + i;
					end if;
				end if;
			end if;
			if j=kLow and v=kHigh then
				exit;
			end if;
		end loop;
	else
		null;
	end if;
	if m<0 then
		Append(t,image(n));
		Append(t," ");
		Append(t,mi);
		if s1'Length > 0 then
			Append(t," ");
			Append(t,s1);
		end if;
		if s2'Length > 0 then
			Append(t," ");
			Append(t,s2);
		end if;
		if s3'Length > 0 then
			Append(t," ");
			Append(t,s3);
		end if;
		return To_String(t);
	else
		Append(t,image(n));
		Append(t," ");
		declare
			w:String:=To_String(mi);
		begin
			i:=w'First(1);
			j:=w'First(1);
			v:=1;
			while i <= w'Last(1) loop
				if w(i) = '%' then
					if i-1 > j then
						Append(t,Unbounded_Slice(mi,j,i-1));
					end if;
					j:=i + 1;
					if v=1 and s1'Length > 0 then
						Append(t,s1);
						v:=2;
					elsif v=2 and s2'Length > 0 then
						Append(t,s2);
						v:=3;
					elsif v=3 and s3'Length > 0 then
						Append(t,s3);
						v:=4;
					end if;
				end if;
				i:=i+1;
			end loop;
			if j <= w'Last(1) then
				Append(t,Unbounded_Slice(mi,j,w'Last(1)));
			end if;
			if v=1 and s1'Length > 0 then
				Append(t," ");
				Append(t,s1);
			end if;
			if (v=1 or v=2 ) and s2'Length > 0 then
				Append(t," ");
				Append(t,s2);
			end if;
			if (v=1 or v=2 or v=3) and s3'Length > 0 then
				Append(t," ");
				Append(t,s3);
			end if;
		end;
		return To_String(t);
	end if;
end getMsg;
function getMsg(n:Integer;K:Y2018.Text.Core.IntegerArray;E:Y2018.Text.Core.StringArray_CAA) return String is
begin
	return getMsg(n,K,E,"","","");
end getMsg;
function getMsg(n:Integer;K:Y2018.Text.Core.IntegerArray;E:Y2018.Text.Core.StringArray_CAA;s1:String) return String is
begin
	return getMsg(n,K,E,s1,"","");
end getMsg;
function getMsg(n:Integer;K:Y2018.Text.Core.IntegerArray;E:Y2018.Text.Core.StringArray_CAA;s1:String;s2:String) return String is
begin
	return getMsg(n,K,E,s1,s2,"");
end getMsg;

-- 20191103143746 GENERATED ADB ---
	function To_UC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_UC(To_Wide_Wide_String(instr)));
	end To_UC;
	function To_UC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_UC(UTF.To32(To_String(instr)))));
	end To_UC;
	function To_LC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_LC(To_Wide_Wide_String(instr)));
	end To_LC;
	function To_LC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_LC(UTF.To32(To_String(instr)))));
	end To_LC;
	function To_TC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_TC(To_Wide_Wide_String(instr)));
	end To_TC;
	function To_TC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_TC(UTF.To32(To_String(instr)))));
	end To_TC;
-- END GENERATED ADB ---
end Y2018.Text.Core.Tool;
