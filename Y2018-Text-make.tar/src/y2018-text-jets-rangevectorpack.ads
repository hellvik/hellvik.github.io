-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
-- ############################## RangeVectorPack.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers;
with Ada.Containers.Ordered_Sets;
with Ada.Text_IO; use Ada.Text_IO;
package Y2018.Text.Jets.RangeVectorPack is
	type RangeVector is tagged private;
	type RangeVector_AC is access RangeVector;
	type Velem is
	record
	f: Integer;
	l: Integer;
	end record;
	null_velem:constant Velem:=(f=>0,l=>0);
-- ############################## rvTool.ads ##############################
	function less(f,l:Velem) return Boolean;
	function equal (f,l:Velem) return Boolean;
	package Set_TY is new Ada.Containers.Ordered_Sets(
		Element_type => Velem,
		"<"=> less,
		"="=> equal);

	procedure put(rvA:in out RangeVector;f:Wide_Wide_Character;l:Wide_Wide_Character);
	procedure put(rvA:in out RangeVector;val:Wide_Wide_Character);
	procedure putGC(rvA:in out RangeVector;val:Wide_Wide_String); 
	procedure putGC(rvA:in out RangeVector;val:Wide_Wide_Character); 
	function exists(rvA:RangeVector;val:Wide_Wide_Character) return Boolean;
	function length(rvA:RangeVector) return Integer;
	
-- ############################## rvList.ads ##############################
-- ############################## rvMerge.ads ##############################
procedure merge(rvA:in out RangeVector;force:Boolean);
function equal (f,l:RangeVector) return Boolean;
function less (f,l:RangeVector) return Boolean;
-- ############################## RangeVectorPackSet.ads ##############################
	private type RangeVector is tagged
	record
		v: Set_TY.Set;
	end record;
-- ############################## RangeVectorPackTail.adb ##############################
end Y2018.Text.Jets.RangeVectorPack;
