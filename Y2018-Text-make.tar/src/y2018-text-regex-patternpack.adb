-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
-- ############################## PatternPack.adb ##############################
--
with Ada.Strings.Wide_Wide_Unbounded; --use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.Msg;
with Y2018.Text.Jets.PatternPack; 
with Y2018.Text.Jets.MatchPack; 
with Y2018.Text.Jets.RegexTool;
with Y2018.Text.Regex.MatchPack;
package body Y2018.Text.Regex.PatternPack is

function compile(s : Wide_Wide_String) return Pattern_AC is
begin
	return compile(s,G_NONE);
end compile;
	
function compile(s : Wide_Wide_String;option :  G_Option) return Pattern_AC is
	p:Pattern_AC;
begin
	if ParseString(s) = FALSE then
		--raise Program_Error with "E4101 Compile"; -- exception;
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4101,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
	p:=new Pattern;
	p.jAC:=Y2018.Text.Jets.PatternPack.compileM(s);
	p.sm:=To_Unbounded_Wide_Wide_String(s);
	case option is
		when G_UPPERCASE =>
			p.option:=option;
		when others =>
			p.option:=option;
	end case;
	return p;
end compile;

function matches (ptc:Pattern_AC;s : Wide_Wide_String) return G_Cursor is
	nextPos:Integer;
	j:Y2018.Text.Jets.MatchPack.Match_AC;
begin
	case ptc.option is
		when G_UPPERCASE =>
			declare
				sn : Wide_Wide_String:=Y2018.Text.Core.Tool.To_UC(s);
			begin
				if Jets.PatternPack.matches(ptc.jAC,1,nextPos,sn,j) then
					declare
						g:G_Cursor:=(ptc=> ptc,us=> To_Unbounded_Wide_Wide_String(s),ux=> To_Unbounded_Wide_Wide_String(sn),m=>j,nextPos=>nextPos);
					begin
						return g;
					end;
				end if;
			end;
		when others =>
			if Jets.PatternPack.matches(ptc.jAC,1,nextPos,s,j) then
				declare
					g:G_Cursor:=(ptc=> ptc,us=> To_Unbounded_Wide_Wide_String(s),ux=> Null_Unbounded_Wide_Wide_String,m=>j,nextPos=>nextPos);
				begin
					return g;
				end;
			end if;
	end case;
	return G_No_Element;
end matches;
function next (Position : G_Cursor) return G_Cursor is
	nextPos:Integer;
	j:Y2018.Text.Jets.MatchPack.Match_AC;
begin
	if Position = G_No_Element then
		return Position;
	elsif Position.nextPos <= Ada.Strings.Wide_Wide_Unbounded.Length(Position.us) then
		case Position.ptc.option is
			when G_UPPERCASE =>
				j:=Position.m;
				if Jets.PatternPack.matches(Position.ptc.jAC,Position.nextPos,nextPos,Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(Position.ux),j) then
					declare
						g:G_Cursor:=(ptc=> Position.ptc,us=> Position.us,ux=> Position.ux,m=>j,nextPos=>nextPos);
					begin
						return g;
					end;
				end if;
			when others =>
				j:=Position.m;
				if Jets.PatternPack.matches(Position.ptc.jAC,Position.nextPos,nextPos,Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(Position.us),j) then
					declare
						g:G_Cursor:=(ptc=> Position.ptc,us=> Position.us,ux=> Position.ux,m=>j,nextPos=>nextPos);
					begin
						return g;
					end;
				end if;
		end case;
	end if;
	return G_No_Element;
end next;
function has_Element (Position : G_Cursor) return Boolean is	
begin
	return (if Position = G_No_Element then FALSE else TRUE);
end has_Element;
function element (Position : G_Cursor) return Y2018.Text.Regex.MatchPack.Match_AC is
begin
	if Position = G_No_Element then
		return null;
	end if;
	return Y2018.Text.Regex.MatchPack.new_Match(Position.m,Position.us);
end element;
function source (Position : G_Cursor) return Wide_Wide_String is
	empty:Wide_Wide_String(1..0);
	lst:Integer;
begin
	if Position = G_No_Element then
		return empty;
	end if;
	lst:=Ada.Strings.Wide_Wide_Unbounded.Length(Position.us);
	if lst < Position.nextPos then
		return empty;
	end if;
	declare
		g:Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Slice(Position.us,Position.nextPos,lst);
		len:Integer:=g'Last(1) - g'First(1) + 1;
		r:Wide_Wide_String(1 .. len);
	begin
		for i in 1 .. len loop
			r(i) := g(g'First + i - 1);
		end loop;
		return r;
	end;
end source;

function toString(ptc:Pattern_AC) return Wide_Wide_String is
begin
	return To_Wide_Wide_String(ptc.sm);
end toString;
function QuoteMeta(s:Wide_Wide_String) return Wide_Wide_String is
begin
	return Y2018.Text.Jets.RegexTool.QuoteMetaM(s);
end QuoteMeta; 
function ParseString(s:Wide_Wide_String) return Boolean is
begin
	if Y2018.Text.Jets.RegexTool.ParseStringM(s) = s'Last(1) + 1 then
		return TRUE;
	else
		return FALSE;
	end if;
end ParseString; 





-- ############################## PatternPackTail.adb ##############################
end Y2018.Text.Regex.PatternPack;
