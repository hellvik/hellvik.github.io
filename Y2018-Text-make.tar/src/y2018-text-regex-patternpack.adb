-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## PatternPack.adb ##############################
--
with Ada.Strings.Wide_Wide_Unbounded; --use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Core.Tool;
with Y2018.Text.Jets.PatternPack;
with Y2018.Text.Jets.MatchPack; 
with Y2018.Text.Jets.RegexTool;
with Y2018.Text.Regex.ToilPack;
with Y2018.Text.Regex;
with GNAT.Source_Info;
package body Y2018.Text.Regex.PatternPack is
procedure Pattern(p:in out Y2018.Text.Regex.PatternPack.Pattern_TY;s : Wide_Wide_String) is
begin
	Pattern(p,s,G_NONE);
end Pattern;
	
procedure Pattern(p:in out Y2018.Text.Regex.PatternPack.Pattern_TY;s : Wide_Wide_String;option :  Y2018.Text.Regex.G_Option) is
begin
	if ParseString(s) = FALSE then
raise Program_Error with E_TY'Image(Y2018.Text.E4101) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Pattern string incompatible";
	end if;
	if not Y2018.Text.Jets.PatternPack."="(p.jAC,null) then
		Y2018.Text.Jets.PatternPack.Finalize(p.jAC.all);
	end if;
	if option = Y2018.Text.Regex.G_UPPERCASE then
		declare
			r: Wide_Wide_String(s'First .. s'Last);
			i:Integer;
			state:Boolean;
			w:constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#5C#);
			sqx:Wide_Wide_String(1..1);
			sqy:Wide_Wide_String(1..1);
		begin
			i:=s'First;
			state:=FALSE;
			while i<=s'Last loop
				if state then
					r(i):=s(i);
					state:=FALSE;
				elsif s(i) = w then
					r(i):=s(i);
					state:=TRUE;
				else
					sqx(1):=s(i);
					sqy:=Y2018.Text.Core.Tool.To_UC(sqx);
					r(i):=sqy(1);
				end if;
				i:=i+1;
			end loop;
			p.jAC:=Y2018.Text.Jets.PatternPack.compileM(r);
			p.sm:=To_Unbounded_Wide_Wide_String(r);
		end;
	else
		p.jAC:=Y2018.Text.Jets.PatternPack.compileM(s);
		p.sm:=To_Unbounded_Wide_Wide_String(s);
	end if;
	p.option:=option;
end Pattern;

procedure Toil (t:in out Y2018.Text.Regex.ToilPack.Toil_TY;p:Pattern_TY;s : Wide_Wide_String) is
	nextPos:Integer;
	m:Y2018.Text.Jets.MatchPack.Match_TY;
	ux:Unbounded_Wide_Wide_String;  -- String for match-operators
begin
	case p.option is
		when G_UPPERCASE =>
			ux:=To_Unbounded_Wide_Wide_String(Y2018.Text.Core.Tool.To_UC(s));
		when others =>
			ux:=To_Unbounded_Wide_Wide_String(s);
	end case;
	if Jets.PatternPack.matches(p.jAC,1,nextPos,To_Wide_Wide_String(ux),m) then
		Y2018.Text.Regex.ToilPack.populateToil(
			t,  
			p.jAC,
			m,
			To_Unbounded_Wide_Wide_String(s),
			ux,
			nextPos,
			p.option
		);
	end if;
end Toil;

function ToString(p:Pattern_TY) return Wide_Wide_String is
begin
	return To_Wide_Wide_String(p.sm);
end ToString;
function QuoteMeta(s:Wide_Wide_String) return Wide_Wide_String is
begin
	return Y2018.Text.Jets.RegexTool.QuoteMetaM(s);
end QuoteMeta; 
function ParseString(s:Wide_Wide_String) return Boolean is
begin
	if Y2018.Text.Jets.RegexTool.ParseStringM(s) = s'Last(1) + 1 then
		return TRUE;
	else
		return FALSE;
	end if;
end ParseString;

function size(p:Pattern_TY) return Integer is
begin
	if Y2018.Text.Jets.PatternPack."="(p.jAC,null) then
		return 0;
	else
		return Y2018.Text.Jets.PatternPack.get_begin_trackcount(p.jAC);
	end if;
end size;
function option(p:Pattern_TY) return Y2018.Text.Regex.G_Option is
begin
	return p.option;
end option;


procedure Finalize(p: in out Pattern_TY) is
begin
	if Y2018.Text.Jets.PatternPack."="(p.jAC,null) then
		null;
	else
		Y2018.Text.Jets.PatternPack.Finalize(p.jAC.all);
		p.jAC:=null;
	end if;
end Finalize;
procedure Initialize(p: in out Pattern_TY) is
begin
	p.jAC:=null;
	p.option:=G_NONE;
	p.sm:=Null_Unbounded_Wide_Wide_String;
end Initialize;
end Y2018.Text.Regex.PatternPack;


