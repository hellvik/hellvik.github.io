-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## PatternPack.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers;
with Ada.Containers.Vectors;
with Ada.Containers.Ordered_Maps;
with Ada.Unchecked_Deallocation;
with Y2018.Text.Jets.RangeVectorPack; --use Y2018.Text.Jets.RangeVectorPack;
with Y2018.Text.Jets.RegexTool; use Y2018.Text.Jets.RegexTool;
with Y2018.Text.Jets.MatchPack; --use Y2018.Text.Jets.MatchPack;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Ada.Finalization; use Ada.Finalization;
package Y2018.Text.Jets.PatternPack is
	type Pattern is tagged private; --limited private;
	type Pattern_AC is access Pattern;
-- ############################## free.ads ##############################
	procedure RE_ELEM_FreeNode(y:in out RE_Elem_AC);
-- ############################## compile.ads ##############################
function compileM(s : Wide_Wide_String) return Pattern_AC;
-- ############################## matches.ads ##############################
function matches(ptc:Pattern_AC;startPos:Integer;nextPos:out Integer;s : Wide_Wide_String;m: out MatchPack.Match_TY) return Boolean;
function get_begin_trackcount(ptc:Pattern_AC) return Integer;
-- ############################## pattern.ads ##############################
	procedure Finalize(p : in out Pattern);
	type PST_TY is (PST_NONE, PST_MATCH, PST_FAIL);
	private type Pattern is tagged -- limited
		record -- nonlimited tagged type cannot have limited components
			state: PST_TY;
			top: RE_Elem_AC;
			current:RE_ID;
			map:MatchPack.MatchID2RE_ID_TY.Map; -- mapping of MatchID's to RE id's. Key is MatchID.
			pool:RegexTool.Pool_TY;
		end record;
-- ############################## PatternPackTail.adb ##############################
end Y2018.Text.Jets.PatternPack;
