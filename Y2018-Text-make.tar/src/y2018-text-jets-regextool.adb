-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## RegexTool.adb ##############################
with Ada.Containers.Vectors;
with Ada.Finalization; use Ada.Finalization;
with Ada.Unchecked_Deallocation;
with Y2018.Text.Core; use Y2018.Text.Core;
with Y2018.Text.Core.GC;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.C32;
with Ada.Containers.Ordered_Maps;
with Ada.Containers.Ordered_Sets;
with Y2018.Text.Jets.RangeVectorPack;
with GNAT.Source_Info;
package body Y2018.Text.Jets.RegexTool is
	
-- ############################## metaZwei.adb ##############################
function ParseStringM(s:Wide_Wide_String) return Integer is
	i:Integer:=s'First(1);
begin
	while i<=s'Last(1) loop
		if s(i) = backSlash then
			if i + 1 <= s'Last(1) then
				case s(i+1) is
					when Wide_Wide_Character'Val(16#64#) => null;
					when Wide_Wide_Character'Val(16#44#) => null;
					when Wide_Wide_Character'Val(16#73#) => null;
					when Wide_Wide_Character'Val(16#53#) => null;
					when Wide_Wide_Character'Val(16#77#) => null;
					when Wide_Wide_Character'Val(16#57#) => null;
					when Wide_Wide_Character'Val(16#70#) => null;
					when Wide_Wide_Character'Val(16#50#) => null;
					when backSlash => null;
					--
					when MvertLine => null;
					when MleftPal => null;
					when MrightPal => null;
					when MleftSquare => null;
					when MrightSquare => null;
					when MleftCurly => null;
					when MrightCurly => null;
					when Mcircumflex => null;
					when Mdollar => null;
					when Masterix => null;
					when Mplus => null;
					when Mquestion => null;
					when Mperiod => null;
					--
					when others => return i-1; 
				end case;
				i:=i+2;
			else
				return i-1;
			end if;
		else
			i:=i+1;
		end if;
	end loop;
	return i;
end ParseStringM;
function QuoteMetaM(s:Wide_Wide_String) return Wide_Wide_String is
	t: Unbounded_Wide_Wide_String;
	d1:Wide_Wide_String(1..1);
	d2:Wide_Wide_String(1..2):=backSlash & " ";
begin
	for i in s'First(1) .. s'Last(1) loop
		case s(i) is
			when MvertLine=> d2(2):=s(i); append(t,d2);
			when MleftPal=> d2(2):=s(i); append(t,d2);
			when MrightPal=> d2(2):=s(i); append(t,d2);
			when MleftSquare=> d2(2):=s(i); append(t,d2);
			when MrightSquare=> d2(2):=s(i); append(t,d2);
			when MleftCurly=> d2(2):=s(i); append(t,d2);
			when MrightCurly=> d2(2):=s(i); append(t,d2);
			when Mcircumflex=> d2(2):=s(i); append(t,d2);
			when Mdollar=> d2(2):=s(i); append(t,d2);
			when Masterix=> d2(2):=s(i); append(t,d2);
			when Mplus=> d2(2):=s(i); append(t,d2);
			when Mquestion=> d2(2):=s(i); append(t,d2);
			when Mperiod=> d2(2):=s(i); append(t,d2);
			when backSlash=> d2(2):=s(i); append(t,d2);
			when others => d1(1):=s(i); append(t,d1);
		end case;
	end loop;
	return To_Wide_Wide_String(t);
end QuoteMetaM;
-- ############################## reFunc.adb ##############################
procedure Finalize(pool : in out Pool_TY) is
	procedure RE_ELEM_Free is new Ada.Unchecked_Deallocation (RE_Elem, RE_Elem_AC);
	procedure removeThis(t:in out RE_Elem_AC) is
	begin
		if t.right /= null then
			removeThis(t.right);
			t.right:=null;
		end if;
		case t.v is
			when REQ_BEGIN =>
				if t.begin_down /= null then
					removeThis(t.begin_down);
					t.begin_down:=null;
				end if;
			when REQ_CLASS_ELEM => -- Do not exists in RegexPattern
				if t.class_elem_pos /= null then
					removeThis(t.class_elem_pos);
					t.class_elem_pos:=null;
				end if;
				if t.class_elem_neg /= null then
					removeThis(t.class_elem_neg);
					t.class_elem_neg:=null;
				end if;
			when REQ_PALCAP => 
				if t.palcap_down /= null then
					removeThis(t.palcap_down);
					t.palcap_down:=null;
				end if;
			when REQ_PAL => 
				if t.pal_down /= null then
					removeThis(t.pal_down);
					t.pal_down:=null;
				end if;
			when REQ_UPDOWN => 
				if t.updown_down /= null then
					removeThis(t.updown_down);
					t.updown_down:=null;
				end if;
			when REQ_POS =>
				if t.pos_down /= null then
					removeThis(t.pos_down);
					t.pos_down:=null;
				end if;
			when REQ_NEG =>
				if t.neg_down /= null then
					removeThis(t.neg_down);
					t.neg_down:=null;
				end if;
			when others =>
				null;
		end case;
		RE_ELEM_Free(t);
	end removeThis;
begin
	if pool.root /= null then
		removeThis(pool.root);
		pool.root:=null;
	end if;
end Finalize;
--procedure Initialize(pool : in out Pool_TY);
--procedure Adjust(pool : in out Pool_TY);

function CREATE_RE(id:in out RE_ID;reqv: REQ_TY) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.id:= id; id:=id + 1;
	return y;
end CREATE_RE;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.left:=vleft;
	if vleft = null then null;
	else
		vleft.right:=y;
	end if;	
	y.id:= id; id:=id + 1;
	return y;
end CREATE_RE;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC;vup:RE_Elem_AC) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.left:=vleft;
	if vleft = null then null;
	else
		vleft.right:=y;
	end if;	
	y.id:= id; id:=id + 1;
	case reqv is
		when REQ_BEGIN =>
			y.begin_up:=vup;
		when REQ_PALCAP =>
			y.palcap_up:=vup;
		when REQ_PAL =>
			y.pal_up:=vup;
		when REQ_UPDOWN =>
			y.updown_up:=vup;
		when others => null;
	end case;
	if vup = null then null;
	else
		case vup.V is
			when REQ_BEGIN =>
				vup.begin_down:=y;
			when REQ_PALCAP =>
				vup.palcap_down:=y;
			when REQ_PAL =>
				vup.pal_down:=y;
			when REQ_UPDOWN =>
				vup.updown_down:=y;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E1001) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Not BEGIN, PALCAP, PAL or UPDOWN" & ":" & REQ_TY'Image(vup.V); 
		end case;
	end if;
	return y;
end CREATE_RE;
procedure Init_RE(y :in out RE_ELEM_AC) is
begin
	y.id := NO_RE_ID; -- ** HAS TO BE UPDATED **
	y.left := null;
	y.right := null;
	case y.V is
		when REQ_BEGIN =>
			y.begin_circumflex := false;
			y.begin_dollar := false;
			y.begin_up := null;
			y.begin_down := null;
		when REQ_CHAR =>
			y.char_value := Wide_Wide_Character'Val(16#0#);
			y.char_negative := false;
			y.char_min := 1;
			y.char_max := 1;
			y.char_greedy := true;
		when REQ_PERIOD =>
			y.period_min := 1;
			y.period_max := 1;
			y.period_greedy := true;
		when REQ_CLASS_ELEM => 
			y.class_elem_min := 1;
			y.class_elem_max := 1;
			y.class_elem_greedy := true;
			y.class_elem_pos := null;
			y.class_elem_neg := null;
		when REQ_CLASS =>
			y.class_min := 1;
			y.class_max := 1;
			y.class_greedy := true;
		when REQ_CLASS_CHAR =>
			y.class_char_negative := false;
			y.class_char_value := Wide_Wide_Character'Val(16#0#);
		when REQ_CLASS_RANGE =>
			y.class_range_negative := false;
			y.class_range_first := Wide_Wide_Character'Val(Y2018.Text.Core.C32.C32_1_LOW);
			y.class_range_last := Wide_Wide_Character'Val(Y2018.Text.Core.C32.C32_9_HIGH);
		when REQ_CLASS_GC =>
			y.class_gc_negative := false;
			y.class_gc_value := (Wide_Wide_Character'Val(16#0#),Wide_Wide_Character'Val(16#0#));
		when REQ_CLASS_GCU => 
			y.class_gcu_negative := false;
			y.class_gcu_value := Wide_Wide_Character'Val(16#0#);
		when REQ_CLASS_OTHER =>
			y.class_other_negative := false;
			y.class_other_value := Wide_Wide_Character'Val(16#0#);
		when REQ_PALCAP =>
			y.palcap_min := 1;
			y.palcap_max := 1;
			y.palcap_greedy := true;
			y.palcap_up := null;
			y.palcap_down := null;
		when REQ_PAL =>
			y.pal_dummy:= false;
			y.pal_min := 1;
			y.pal_max := 1;
			y.pal_greedy := true;
			y.pal_up := null;
			y.pal_down := null;
		when REQ_UPDOWN =>
			y.updown_up := null;
			y.updown_down := null;
		when REQ_POS =>
			y.pos_up := null;
			y.pos_down := null;
		when REQ_NEG =>
			y.neg_up := null;
			y.neg_down := null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E1002) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Not supported RE-type" & ":" & REQ_TY'Image(y.V); 
	end case;
end Init_RE;

function New_RangeVector(actual:RE_Elem_AC) return RangeVectorPack.RangeVector is
	viff:RE_Elem_AC;
	rv: RangeVectorPack.RangeVector;
begin
	viff:=actual;
	while viff/=null loop
		case viff.V is
			when REQ_CLASS_CHAR =>
				RangeVectorPack.putC(rv,viff.class_char_value);
			when REQ_CLASS_RANGE =>
				RangeVectorPack.putC(rv,viff.class_range_first,viff.class_range_last);
			when REQ_CLASS_GC =>
				RangeVectorPack.putGC(rv,viff.class_gc_value);
			when REQ_CLASS_GCU =>
				RangeVectorPack.putGC(rv,viff.class_gcu_value);
			when REQ_CLASS_OTHER =>
				case viff.class_other_value is
					when Mlc_d =>
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#30#),Wide_Wide_Character'Val(16#39#));
					when Muc_d =>
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#30#),Wide_Wide_Character'Val(16#39#));
					when Mlc_s=>
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#9#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#A#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#C#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#D#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#20#));
					when Muc_s =>
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#9#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#A#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#C#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#D#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#20#));
					when Mlc_w => 
						RangeVectorPack.putGC(rv,Wide_Wide_Character'Val(16#4C#));
						RangeVectorPack.putGC(rv,Wide_Wide_Character'Val(16#4E#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#5F#));
					when Muc_w => 
						RangeVectorPack.putGC(rv,Wide_Wide_Character'Val(16#4C#));
						RangeVectorPack.putGC(rv,Wide_Wide_Character'Val(16#4E#));
						RangeVectorPack.putC(rv,Wide_Wide_Character'Val(16#5F#));
when others => raise Program_Error with E_TY'Image(Y2018.Text.E1003) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Insert fail REQ_CLASS_OTHER";
				end case;
			when others =>
				null;
		end case;
		viff:=viff.right;
	end loop;
	RangeVectorPack.merge(rv,false);
	return rv;
end New_RangeVector;
-- ############################## reList.adb ##############################
-- ############################## ToolCommon.adb ##############################

function To_Unbounded_Wide_Wide_String(s : Wide_Wide_String;Low:Integer;High:Integer) return Unbounded_Wide_Wide_String is
	len:Integer:=High - Low + 1;
begin
	declare
		r:Wide_Wide_String(1  .. len);
	begin
		for I in 1 .. len loop
			if Low + I - 1 <= s'Last(1) then
				r(I):=s(Low + I - 1);
			else
				r(I):=Wide_Wide_Character'Val(16#5F#);
			end if;
		end loop;
		return To_Unbounded_Wide_Wide_String(r);
	end;
end To_Unbounded_Wide_Wide_String;
function getMin(this:RE_Elem_AC) return Integer is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return 1;
		when REQ_CHAR =>
			return this.char_min;
		when REQ_PERIOD =>
			return this.period_min;
		when REQ_CLASS =>
			return this.class_min;
		when REQ_PALCAP =>
			return this.palcap_min;
		when REQ_PAL =>
			return this.pal_min;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getMin(that);
		when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E1031) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " REQ node has no 'min'" & ":" & REQ_TY'Image(this.V);
	end case;
end getMin;
function getMax(this:RE_Elem_AC) return Integer is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return 1;
		when REQ_CHAR =>
			return this.char_max;
		when REQ_PERIOD =>
			return this.period_max;
		when REQ_CLASS =>
			return this.class_max;
		when REQ_PALCAP =>
			return this.palcap_max;
		when REQ_PAL =>
			return this.pal_max;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getMax(that);
		when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E1032) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " REQ node has no 'max'" & ":" & REQ_TY'Image(this.V);
	end case;
end getMax;
function getGreedy(this:RE_Elem_AC) return Boolean is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return TRUE;
		when REQ_CHAR =>
			return this.char_greedy;
		when REQ_PERIOD =>
			return this.period_greedy;
		when REQ_CLASS =>
			return this.class_greedy;
		when REQ_PALCAP =>
			return this.palcap_greedy;
		when REQ_PAL =>
			return this.pal_greedy;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getGreedy(that);
		when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E1033) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " REQ node has no 'greedy'" & ":" & REQ_TY'Image(this.V);
	end case;
end getGreedy;
function isInMCHAR(c:Wide_Wide_Character) return Boolean is
begin
	for i in MCHAR'First .. MCHAR'Last loop
		if MCHAR(i) = c then
			return TRUE;
		end if;
	end loop;
	return FALSE;
end isInMCHAR;
-- ############################## RegexToolTail.adb ##############################
end Y2018.Text.Jets.RegexTool;
