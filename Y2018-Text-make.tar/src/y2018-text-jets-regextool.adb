-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190407173029.
-- ############################## RegexTool.adb ##############################
with Ada.Containers.Vectors;
with Y2018.Text.Core; use Y2018.Text.Core;
with Y2018.Text.Core.GC;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.C32;
with Y2018.Text.Core.Msg;
with Ada.Containers.Ordered_Maps;
with Ada.Containers.Ordered_Sets;
with Y2018.Text.Jets.RangeVectorPack;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
package body Y2018.Text.Jets.RegexTool is
	
-- ############################## metaZwei.adb ##############################
function ParseStringM(s:Wide_Wide_String) return Integer is
	i:Integer:=s'First(1);
begin
	while i<=s'Last(1) loop
		if s(i) = backSlash then
			if i + 1 <= s'Last(1) then
				case s(i+1) is
					when Wide_Wide_Character'Val(16#64#) => null;
					when Wide_Wide_Character'Val(16#44#) => null;
					when Wide_Wide_Character'Val(16#73#) => null;
					when Wide_Wide_Character'Val(16#53#) => null;
					when Wide_Wide_Character'Val(16#77#) => null;
					when Wide_Wide_Character'Val(16#57#) => null;
					when Wide_Wide_Character'Val(16#70#) => null;
					when Wide_Wide_Character'Val(16#50#) => null;
					when backSlash => null;
					--
					when MvertLine => null;
					when MleftPal => null;
					when MrightPal => null;
					when MleftSquare => null;
					when MrightSquare => null;
					when MleftCurly => null;
					when MrightCurly => null;
					when Mcircumflex => null;
					when Mdollar => null;
					when Masterix => null;
					when Mplus => null;
					when Mquestion => null;
					when Mperiod => null;
					--
					when others => return i-1; 
				end case;
				i:=i+2;
			else
				return i-1;
			end if;
		else
			i:=i+1;
		end if;
	end loop;
	return i;
end ParseStringM;
function QuoteMetaM(s:Wide_Wide_String) return Wide_Wide_String is
	j:Integer:=0;
begin
	for i in s'First(1) .. s'Last(1) loop
		case s(i) is
			when MvertLine=> j:=j + 1; -- '|'
			when MleftPal=> j:=j + 1; -- '('
			when MrightPal=> j:=j + 1; -- ')'
			when MleftSquare=> j:=j + 1; -- '['
			when MrightSquare=> j:=j + 1; -- ']'
			when MleftCurly=> j:=j + 1; -- '{'
			when MrightCurly=> j:=j + 1; -- '}'
			when Mcircumflex=> j:=j + 1; -- '^'
			when Mdollar=> j:=j + 1; -- '$'
			when Masterix=> j:=j + 1; -- '*'
			when Mplus=> j:=j + 1; -- '+'
			when Mquestion=> j:=j + 1; -- '?'
			when Mperiod=> j:=j + 1; -- '.'
			when backSlash=> j:=j + 1; -- '\'
			when others => null;
		end case;
	end loop;
	if j= 0 then
		return s;
	end if;
	declare
		t:Wide_Wide_String(1 .. (s'Last(1) - s'First(1) +1 +j));
	begin
		j:=1;
		for i in s'First(1) .. s'Last(1) loop
			case s(i) is
				when MvertLine=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MleftPal=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MrightPal=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MleftSquare=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MrightSquare=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MleftCurly=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when MrightCurly=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Mcircumflex=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Mdollar=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Masterix=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Mplus=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Mquestion=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when Mperiod=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when backSlash=> t(j):=backSlash; t(j+1):=s(i); j:=j + 2;
				when others => t(j+1):=s(i); j:=j + 1;
			end case;
		end loop;
		return t;
	end;
end QuoteMetaM;
-- ############################## reFunc.adb ##############################
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.id:= id; id:=id + 1;
	return y;
end CREATE_RE;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.left:=vleft;
	if vleft = null then null;
	else
		vleft.right:=y;
	end if;	
	y.id:= id; id:=id + 1;
	return y;
end CREATE_RE;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC;vup:RE_Elem_AC) return RE_ELEM_AC is
	y : RE_ELEM_AC;
begin	
	y := new RE_Elem(reqv);
	Init_RE(y);
	y.left:=vleft;
	if vleft = null then null;
	else
		vleft.right:=y;
	end if;	
	y.id:= id; id:=id + 1;
	case reqv is
		when REQ_BEGIN =>
			y.begin_up:=vup;
		when REQ_PALCAP =>
			y.palcap_up:=vup;
		when REQ_PAL =>
			y.pal_up:=vup;
		when REQ_UPDOWN =>
			y.updown_up:=vup;
		when others => null;
	end case;
	if vup = null then null;
	else
		case vup.V is
			when REQ_BEGIN =>
				vup.begin_down:=y;
			when REQ_PALCAP =>
				vup.palcap_down:=y;
			when REQ_PAL =>
				vup.pal_down:=y;
			when REQ_UPDOWN =>
				vup.updown_down:=y;
			--when others => raise Program_Error with "E1001 CREATE_RE"; -- exception; 
			when others => raise Program_Error with Y2018.Text.Core.Tool.getMsg(1001,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,REQ_TY'Image(vup.V)); 
		end case;
	end if;
	return y;
end CREATE_RE;
procedure Init_RE(y :in out RE_ELEM_AC) is
begin
	y.id := NO_RE_ID; -- ** HAS TO BE UPDATED **
	y.left := null;
	y.right := null;
	case y.V is
		when REQ_BEGIN =>
			y.begin_circumflex := false;
			y.begin_dollar := false;
			y.begin_up := null;
			y.begin_down := null;
		when REQ_CHAR =>
			y.char_value := Wide_Wide_Character'Val(16#0#);
			y.char_negative := false;
			y.char_min := 1;
			y.char_max := 1;
			y.char_greedy := true;
		when REQ_PERIOD =>
			y.period_min := 1;
			y.period_max := 1;
			y.period_greedy := true;
		when REQ_CLASS_ELEM => 
			y.class_elem_min := 1;
			y.class_elem_max := 1;
			y.class_elem_greedy := true;
			y.class_elem_pos := null;
			y.class_elem_neg := null;
		when REQ_CLASS =>
			y.class_min := 1;
			y.class_max := 1;
			y.class_greedy := true;
		when REQ_CLASS_CHAR =>
			y.class_char_negative := false;
			y.class_char_value := Wide_Wide_Character'Val(16#0#);
		when REQ_CLASS_RANGE =>
			y.class_range_negative := false;
			y.class_range_first := Wide_Wide_Character'Val(Y2018.Text.Core.C32.C32_1_LOW);
			y.class_range_last := Wide_Wide_Character'Val(Y2018.Text.Core.C32.C32_9_HIGH);
		when REQ_CLASS_GC =>
			y.class_gc_negative := false;
			y.class_gc_value := (Wide_Wide_Character'Val(16#0#),Wide_Wide_Character'Val(16#0#));
		when REQ_CLASS_GCU => 
			y.class_gcu_negative := false;
			y.class_gcu_value := Wide_Wide_Character'Val(16#0#);
		when REQ_CLASS_OTHER =>
			y.class_other_negative := false;
			y.class_other_value := Wide_Wide_Character'Val(16#0#);
		when REQ_PALCAP =>
			y.palcap_min := 1;
			y.palcap_max := 1;
			y.palcap_greedy := true;
			y.palcap_up := null;
			y.palcap_down := null;
		when REQ_PAL =>
			y.pal_dummy:= false;
			y.pal_min := 1;
			y.pal_max := 1;
			y.pal_greedy := true;
			y.pal_up := null;
			y.pal_down := null;
		when REQ_UPDOWN =>
			y.updown_up := null;
			y.updown_down := null;
		when REQ_POS =>
			y.pos_up := null;
			y.pos_down := null;
		when REQ_NEG =>
			y.neg_up := null;
			y.neg_down := null;
		--when others => raise Program_Error with "E1002 Init_RE"; -- exception; 
		when others => raise Program_Error with Y2018.Text.Core.Tool.getMsg(1002,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,REQ_TY'Image(y.V)); 
	end case;
end Init_RE;

function New_RangeVector(actual:RE_Elem_AC) return RangeVectorPack.RangeVector is
	viff:RE_Elem_AC;
	rv: RangeVectorPack.RangeVector_AC;
begin
	rv:=new RangeVectorPack.RangeVector;
	viff:=actual;
	while viff/=null loop
		case viff.V is
			when REQ_CLASS_CHAR =>
				RangeVectorPack.put(rv.all,viff.class_char_value);
			when REQ_CLASS_RANGE =>
				RangeVectorPack.put(rv.all,viff.class_range_first,viff.class_range_last);
			when REQ_CLASS_GC =>
				RangeVectorPack.putGC(rv.all,viff.class_gc_value);
			when REQ_CLASS_GCU =>
				RangeVectorPack.putGC(rv.all,viff.class_gcu_value);
			when REQ_CLASS_OTHER =>
				case viff.class_other_value is
					when Mlc_d =>
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#30#),Wide_Wide_Character'Val(16#39#));
					when Muc_d =>
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#30#),Wide_Wide_Character'Val(16#39#));
					when Mlc_s=>
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#9#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#A#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#C#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#D#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#20#));
					when Muc_s =>
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#9#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#A#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#C#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#D#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#20#));
					when Mlc_w => 
						RangeVectorPack.putGC(rv.all,Wide_Wide_Character'Val(16#4C#));
						RangeVectorPack.putGC(rv.all,Wide_Wide_Character'Val(16#4E#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#5F#));
					when Muc_w => 
						RangeVectorPack.putGC(rv.all,Wide_Wide_Character'Val(16#4C#));
						RangeVectorPack.putGC(rv.all,Wide_Wide_Character'Val(16#4E#));
						RangeVectorPack.put(rv.all,Wide_Wide_Character'Val(16#5F#));
					--when others => raise Program_Error with "E1003 New_RangeVector Insert fail REQ_CLASS_OTHER";
					when others => raise Program_Error with Y2018.Text.Core.Tool.getMsg(1003,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
				end case;
			when others =>
				null;
		end case;
		viff:=viff.right;
	end loop;
	RangeVectorPack.merge(rv.all,false);
	return rv.all;
end New_RangeVector;
-- ############################## reList.adb ##############################
-- ############################## ToolCommon.adb ##############################

function To_Unbounded_Wide_Wide_String(s : Wide_Wide_String;Low:Integer;High:Integer) return Unbounded_Wide_Wide_String is
	len:Integer:=High - Low + 1;
begin
	declare
		r:Wide_Wide_String(1  .. len);
	begin
		for I in 1 .. len loop
			if Low + I - 1 <= s'Last(1) then
				r(I):=s(Low + I - 1);
			else
				r(I):=Wide_Wide_Character'Val(16#5F#);
			end if;
		end loop;
		return To_Unbounded_Wide_Wide_String(r);
	end;
end To_Unbounded_Wide_Wide_String;
function getMin(this:RE_Elem_AC) return Integer is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return 1;
		when REQ_CHAR =>
			return this.char_min;
		when REQ_PERIOD =>
			return this.period_min;
		when REQ_CLASS =>
			return this.class_min;
		when REQ_PALCAP =>
			return this.palcap_min;
		when REQ_PAL =>
			return this.pal_min;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getMin(that);
		when others =>
			--raise Program_Error with "E1031 getMin";  -- exception;
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(1031,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,REQ_TY'Image(this.V));
	end case;
end getMin;
function getMax(this:RE_Elem_AC) return Integer is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return 1;
		when REQ_CHAR =>
			return this.char_max;
		when REQ_PERIOD =>
			return this.period_max;
		when REQ_CLASS =>
			return this.class_max;
		when REQ_PALCAP =>
			return this.palcap_max;
		when REQ_PAL =>
			return this.pal_max;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getMax(that);
		when others =>
			--raise Program_Error with "E1032 getMax";  -- exception;
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(1032,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,REQ_TY'Image(this.V));
	end case;
end getMax;
function getGreedy(this:RE_Elem_AC) return Boolean is
	that:RE_Elem_AC;
begin
	case this.V is
		when REQ_BEGIN =>
			return TRUE;
		when REQ_CHAR =>
			return this.char_greedy;
		when REQ_PERIOD =>
			return this.period_greedy;
		when REQ_CLASS =>
			return this.class_greedy;
		when REQ_PALCAP =>
			return this.palcap_greedy;
		when REQ_PAL =>
			return this.pal_greedy;
		when REQ_UPDOWN =>
			that:=this;
			while that.V=REQ_UPDOWN loop
				that:=that.updown_up;
			end loop;
			return getGreedy(that);
		when others =>
			--raise Program_Error with "E1033 getGreedy";  -- exception;
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(1033,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,REQ_TY'Image(this.V));
	end case;
end getGreedy;
function isInMCHAR(c:Wide_Wide_Character) return Boolean is
begin
	for i in MCHAR'First .. MCHAR'Last loop
		if MCHAR(i) = c then
			return TRUE;
		end if;
	end loop;
	return FALSE;
end isInMCHAR;
-- ############################## RegexToolTail.adb ##############################
end Y2018.Text.Jets.RegexTool;
