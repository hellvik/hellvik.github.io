-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## TestQ.ads ##############################
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Containers;
with Ada.Containers.Vectors;
with Ada.Strings.Unbounded;	use Ada.Strings.Unbounded;
package Y2018.Text.TestQ is
-- ############################## core.ads ##############################
type ANKA is (
	KALLE,KNATTE,TJATTE,FNATTE,KAJSA,KNASE,BITTAN);

procedure Qinit(s:String);

procedure QBlock(s:String);

procedure Qappend(s:String);
procedure Qappend(a:ANKA;s:String);
procedure Qappend(s:String;i1:Integer);
procedure Qappend(a:ANKA;s:String;i1:Integer);

procedure Qappend(s:String;i1:Integer;i2:Integer);
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer);

procedure Qappend(s:String;b:Boolean);
procedure Qappend(a:ANKA;s:String;b:Boolean);

procedure Qappend(s:String;i1:Integer;s1:String);
procedure Qappend(a:ANKA;s:String;i1:Integer;s1:String);

procedure Qappend(s:String;i1:Integer;i2:Integer;s2:String);
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer;s2:String);

procedure Qappend(s:String;wws:Wide_Wide_String);
procedure Qappend(a:ANKA;s:String;wws:Wide_Wide_String);

procedure Qappend(s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer);
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer);

procedure Qappend(s:String;c:Wide_Wide_Character); 
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character); 
	--=====--
	-- ALT --
	--=====--
procedure Qappend_alt(s:String);
procedure Qappend_alt(a:ANKA;s:String);
procedure Qappend_alt(s:String;i1:Integer);
procedure Qappend_alt(a:ANKA;s:String;i1:Integer);

procedure Qappend_alt(s:String;i1:Integer;i2:Integer);
procedure Qappend_alt(a:ANKA;s:String;i1:Integer;i2:Integer);

procedure Qappend_alt(s:String;b:Boolean);
procedure Qappend_alt(a:ANKA;s:String;b:Boolean);

procedure Qappend_alt(s:String;i1:Integer;s1:String);
procedure Qappend_alt(a:ANKA;s:String;i1:Integer;s1:String);

procedure Qappend_alt(s:String;i1:Integer;i2:Integer;s2:String);
procedure Qappend_alt(a:ANKA;s:String;i1:Integer;i2:Integer;s2:String);

procedure Qappend_alt(s:String;wws:Wide_Wide_String);
procedure Qappend_alt(a:ANKA;s:String;wws:Wide_Wide_String);

procedure Qappend_alt(s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer);
procedure Qappend_alt(a:ANKA;s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer);

procedure Qappend_alt(s:String;c:Wide_Wide_Character); 
procedure Qappend_alt(a:ANKA;s:String;c:Wide_Wide_Character); 
-- ############################## TestTailQ.adb ##############################
end Y2018.Text.TestQ;
