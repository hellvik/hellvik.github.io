-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
with Ada.Strings.UTF_Encoding; --use Ada.Strings.UTF_Encoding;
with Ada.Strings.UTF_Encoding.Conversions;
with Ada.Strings.UTF_Encoding.Wide_Wide_Strings; --use Ada.Strings.UTF_Encoding.Wide_Wide_Strings;
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings;
with Interfaces;
with Y2018.Text.Core.C8;  use Y2018.Text.Core.C8;
with Y2018.Text.Core.C32; use Y2018.Text.Core.C32;
with Y2018.Text.Core.Msg;
with Y2018.Text.Core.Tool;

with Ada.Text_IO; use  Ada.Text_IO;

package body Y2018.Text.Core.UTF is

function To32 (s : String) return Wide_Wide_String is
	type Wide_Wide_String_Access is access Wide_Wide_String;
	wordcount : Integer := 0;
	r : Wide_Wide_String_Access;
	i :Integer;
	j :Integer:=1;
	k :Integer;
	rnull : Wide_Wide_String(1..0);
	blank : constant String(1..1) := " ";
	w2: String(1..2);
	function r80
					(c:Character;j:Integer) return Integer is
		i : Interfaces.Unsigned_8;
	begin
		i:=Interfaces.Unsigned_8(Character'Pos(c));
		return Integer(Interfaces.Shift_Right(Interfaces.Shift_Left(i,j),j));
	end r80;
begin
	while j <= s'LAST(1) loop
		i:=Character'Pos(s(j));
		wordcount:=wordcount + 1;
		if i in C8_1_LOW .. C8_1_HIGH then
			j:=j+1;
		elsif i in C8_2_LOW .. C8_2_HIGH then
			if Character'Pos(s(j+1)) < 16#80# then
				--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E50 byte 2/" & Integer'Image(Character'Pos(s(j+1))); 
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(50,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E, Integer'Image(Character'Pos(s(j+1)))); 
			end if;
			j:=j+2;
		elsif i in C8_3_LOW .. C8_3_HIGH then
			if Character'Pos(s(j+1)) < 16#80# or
				Character'Pos(s(j+2)) < 16#80# then
				--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E51 byte 3/"; 
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(51,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E); 
			end if;
			j:=j+3;
		elsif i in C8_4_LOW .. C8_4_HIGH then
			if Character'Pos(s(j+1)) < 16#80# or	--

				Character'Pos(s(j+2)) < 16#80# or
				Character'Pos(s(j+3)) < 16#80# then 
				--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E52 byte 4/";
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(52,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
			end if;
			j:=j+4;
		else
			--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E53 Illegal";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(53,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
		end if;	
	end loop;			w2(1) := Character'Val(16#0#);
			w2(2) :=' ';

	if wordcount = 0 then return rnull; end if;
	if j - 1 > s'LAST(1) then
		--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E54 " & Integer'Image(j - 1) & "> 'LAST";
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(54,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(j - 1));
	end if;
	r:= new Wide_Wide_String(1 .. wordcount);
	wordcount:=1;
	j:=1;
	while j <= s'LAST(1) loop
		i:=Character'Pos(s(j));
		if    i in C8_1_LOW .. C8_1_HIGH then
			r(wordcount):=Wide_Wide_Character'Val(i);
			j:=j+1;
		elsif i in C8_2_LOW .. C8_2_HIGH then
			k:=
				r80(s(j),3) * 16#40# + r80(s(j+1),1);
			r(wordcount):=Wide_Wide_Character'Val(k);
			j:=j+2;
		elsif i in C8_3_LOW .. C8_3_HIGH then
			k:=
				r80(s(j),4) * 16#1000# + r80(s(j+1),1) * 16#40# + r80(s(j+2),1);
			r(wordcount):=Wide_Wide_Character'Val(k);
			j:=j+3;
		elsif i in C8_4_LOW .. C8_4_HIGH then
			k:=
				r80(s(j),5) * 16#40000# + r80(s(j+1),1) * 16#1000# + r80(s(j+2),1) * 16#40# + r80(s(j+3),1);
			r(wordcount):=Wide_Wide_Character'Val(k);
			j:=j+4;
		else
			--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E55 Illegal " & Integer'Image(i);
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(55,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(i));
		end if;	
		wordcount:=wordcount + 1;
	end loop;
	return r.all;
end To32;

function To8 (s : Wide_Wide_String) return String is
	type String_Access is access String;
	bytecount : Integer := 0;
	r : String_Access;
	i :Integer;
	rnull : String(1..0);
begin
	for J in s'FIRST(1) .. s'LAST(1) loop
		i:=Wide_Wide_Character'Pos(s(J));
		if i in C32_1_LOW .. C32_1_HIGH then
			bytecount:=bytecount + 1;
		elsif i in C32_2_LOW .. C32_2_HIGH then
			bytecount:=bytecount + 2;
		elsif i in C32_3_LOW .. C32_3_HIGH then
			bytecount:=bytecount + 3;
		elsif i in C32_4_LOW .. C32_4_HIGH then
			bytecount:=bytecount + 3;
		elsif i in C32_5_LOW .. C32_5_HIGH then
			bytecount:=bytecount + 3;
		elsif i in C32_6_LOW .. C32_6_HIGH then
			bytecount:=bytecount + 3;
		elsif i in C32_7_LOW .. C32_7_HIGH then
			bytecount:=bytecount + 4;
		elsif i in C32_8_LOW .. C32_8_HIGH then
			bytecount:=bytecount + 4;
		elsif i in C32_9_LOW .. C32_9_HIGH then
			bytecount:=bytecount + 4;
		else
			--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E56 Out of range";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(56,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
		end if;	
	end loop;
	
	if bytecount = 0 then return rnull; end if;
	r:= new String(1 .. bytecount);
	for J in 1 .. bytecount loop r(J):='='; end loop; --STRYK--
	bytecount := 1;
	for J in s'FIRST(1) .. s'LAST(1) loop
		i:=Wide_Wide_Character'Pos(s(J));
		if i in C32_1_LOW .. C32_1_HIGH then
			r(bytecount):=Character'Val(i); 
			bytecount:=bytecount + 1;
		elsif i in C32_2_LOW .. C32_2_HIGH then
			r(bytecount):=    Character'Val(16#C0# + i / 16#40# ); -- 11 1111
			r(bytecount + 1):=Character'Val(16#80# + i mod 16#40# );
			bytecount:=bytecount + 2;
		elsif i in C32_3_LOW .. C32_3_HIGH or
				i in C32_4_LOW .. C32_4_HIGH or
				i in C32_5_LOW .. C32_5_HIGH or
				i in C32_6_LOW .. C32_6_HIGH then
			r(bytecount):=    Character'Val(16#E0# + i / 16#1000# );  -- 1111 1111 1111
			r(bytecount + 1):=Character'Val(16#80# + (i mod 16#1000#) / 16#40# ); -- 11 1111 
			r(bytecount + 2):=Character'Val(16#80# + i mod 16#40# ); 
			bytecount:=bytecount + 3;
		elsif i in C32_7_LOW .. C32_7_HIGH or
				i in C32_8_LOW .. C32_8_HIGH or
				i in C32_9_LOW .. C32_9_HIGH then
			r(bytecount):=    Character'Val(16#F0# + i / 16#40000# );  -- 11 1111 1111 1111 1111
			r(bytecount + 1):=Character'Val(16#80# + (i mod 16#4000#) / 16#1000# ); -- 1111 1111 1111 
			r(bytecount + 2):=Character'Val(16#80# + (i mod 16#1000#) / 16#40# ); -- 11 1111 
			r(bytecount + 3):=Character'Val(16#80# + i mod 16#40# ); 
			bytecount:=bytecount + 4;
		else
			--raise Ada.Strings.UTF_Encoding.Encoding_Error with "E57 Out of range";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(57,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
		end if;	
	end loop;
	return r.all;
end To8;

function To32 (s : Unbounded_String) return Unbounded_Wide_Wide_String is
begin
	return To_Unbounded_Wide_Wide_String(Ada.Strings.UTF_Encoding.Wide_Wide_Strings.Decode(Ada.Strings.UTF_Encoding.UTF_8_String(To_String(s))));
end To32;

function To8 (s : Unbounded_Wide_Wide_String) return Unbounded_String is
begin
	return To_Unbounded_String(Ada.Strings.UTF_Encoding.Wide_Wide_Strings.Encode(Item => To_Wide_Wide_String(s),Output_Scheme =>  Ada.Strings.UTF_Encoding.UTF_8));
end To8;

end Y2018.Text.Core.UTF;
