-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- ############################## MatchPack.adb ##############################
--
with Ada.Strings.Wide_Wide_Unbounded; --use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Jets.MatchPack;
with Y2018.Text.Jets.RegexTool;
with Y2018.Text.Core.Tool;
package body Y2018.Text.Regex.MatchPack is

	function new_Match(jAC:Y2018.Text.Jets.MatchPack.Match_AC;us : Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String) return Match_AC is
		m:Match_AC;
	begin
		m:=new Match;
		m.jAC:=jAC;
		m.us:=us;
		return m;
	end new_Match;
	
	function getMatch(matchValue:Match_AC;mid:Integer) return Wide_Wide_String is
		jmid:Y2018.Text.Jets.RegexTool.MatchID:=mid;
		result:Y2018.Text.Jets.MatchPack.ValueOfMatch;
		us:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
		empty:Wide_Wide_String(1..0);
	begin
		result:=Y2018.Text.Jets.MatchPack.getMatch2(matchValue.jAC,jmid);
		if result.l >= result.f then
			return Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(Y2018.Text.Core.Tool.substr(matchvalue.us,result.f,result.l - result.f + 1));
		else
			return empty;
		end if;
	end getMatch;
	--
	function getMatch(matchValue:Match_AC) return Unbounded_Wide_Wide_String_AA is
		cnt:Integer:=Y2018.Text.Jets.MatchPack.count(matchValue.jAC);
		rA:Unbounded_Wide_Wide_String_AA(0 .. (cnt - 1));
		i:Integer:=0;
		empty:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
	begin
		while i < cnt loop
			rA(i):=new Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
			if Y2018.Text.Jets.MatchPack.hasMatch(matchValue.jAC,i) then
				rA(i).all:=Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(getMatch(matchValue,i));
			else
				rA(i).all:=empty;
			end if;
			i:=i+1;
		end loop;
		return rA;
	end getMatch;
	
	function hasMatch(matchValue:Match_AC;mid:Integer) return Boolean is
		jmid:Y2018.Text.Jets.RegexTool.MatchID:=mid;
	begin
		return Y2018.Text.Jets.MatchPack.hasMatch(matchValue.jAC,jmid);
	end hasMatch;
	function count(matchValue:Match_AC) return Integer is
	begin
		return Y2018.Text.Jets.MatchPack.count(matchValue.jAC);
	end count;
	
-- ############################## MatchPackTail.adb ##############################
end Y2018.Text.Regex.MatchPack;
