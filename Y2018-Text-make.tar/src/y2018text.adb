-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Command_Line; use Ada.Command_Line;
with Ada.Strings; use Ada.Strings;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers;use Ada.Containers;
with Ada.Containers.Ordered_Maps;
with Ada.Containers;
with Ada.Strings;
with Ada.Strings.Fixed;
with GNAT.Source_Info;
with Y2018.Text; use Y2018.Text;
with Y2018.Text.Core; use Y2018.Text.Core;
with Y2018.Text.Core.STR; --use Y2018.Text.Core.STR;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.Tool;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; --use Y2018.Text.Regex.PatternPack; 
with Y2018.Text.Regex.ToilPack; use Y2018.Text.Regex.ToilPack;
--with Y2018.Text.Jets.PatternPack;
with Y2018Text_DSECT; -- GENERATED CODE
procedure Y2018Text is
	--.............................--
	--  Global type definition     --
	--.............................--
	type CODE_TY is (CODE_UNDEF,CODE_PROCEDURE, CODE_PACKAGEHEAD, CODE_PACKAGEBODY);
	type STR9_TY is
		record
			s:Wide_Wide_String(1..9);
		end record;
-- *********** BDmap_TY.adb ************
	--.............................--
	--  Dmap_TY support            --
	--.............................--
	function Cmp(first:Wide_Wide_String;second:Wide_Wide_String) return Integer is
	begin
		if first'LENGTH(1) = 0 and second'LENGTH(1) = 0 then
			return 0;
		elsif first'LENGTH(1) < second'LENGTH(1) then
			return -1;
		elsif first'LENGTH(1) > second'LENGTH(1) then
			return 1;
		end if;
		for i in first'FIRST(1) .. first'LAST(1) loop
			if first(i) > second(i) then
				return 1;
			elsif first(i) < second(i) then
				return -1;
			end if;
		end loop;
		return 0;
	end Cmp;
	function Cmp(first:Unbounded_Wide_Wide_String;second:Unbounded_Wide_Wide_String) return Integer is
	begin
		return Cmp(to_Wide_Wide_String(first),to_Wide_Wide_String(second));
	end Cmp;
	function less (Left,Right:Unbounded_Wide_Wide_String) return Boolean is
	begin
		case Cmp(Left,Right) is
			when -1 =>
				return TRUE;
			when others =>
				null;
		end case;
		return FALSE;
	end less;
	function equal (Left,Right:STR9_TY) return Boolean is
	begin
		case Cmp(Left.s,Right.s) is
			when 0 =>
				return TRUE;
			when others =>
				null;
		end case;
		return FALSE;
	end equal;
	package Dmap_TY is new Ada.Containers.Ordered_Maps(Key_Type=> Unbounded_Wide_Wide_String,Element_Type=> STR9_TY,"<"=> less, "="=> equal);
-- *********** Cvariable.adb ************
	--.............................--
	-- Global variables            --
	--.............................--
	program_info:constant String:="Precompilation with Y2018Text V2";
	WWSmap: Dmap_TY.Map;
	SMap: Dmap_TY.Map;
	WWCmap: Dmap_TY.Map;
	CMap: Dmap_TY.Map;
	--cnt:Integer;
	cntCharacter:Integer;
	cntString:Integer;
	cntWWCharacter:Integer;
	cntWWString:Integer;
	cnt_Start: constant Integer:=1000;
	
	code:CODE_TY:=CODE_UNDEF;

	wide_wide_stringLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1000;
	stringLitS:constant Wide_Wide_String:=Y2018Text_DSECT.W1001;
	stringLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1002;
	--stringLitX:constant Wide_Wide_String:="""(?:[^""]|"""")*""[^WS]"W;
	wide_wide_characterLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1003;

	wide_wide_characterLitX:constant Wide_Wide_String:=Y2018Text_DSECT.W1004;
	wide_wide_characterLitU:constant Wide_Wide_String:=Y2018Text_DSECT.W1005;
	wide_wide_characterLitV:constant Wide_Wide_String:=Y2018Text_DSECT.W1006;
	wide_wide_characterLitY:constant Wide_Wide_String:=Y2018Text_DSECT.W1007;
	wide_wide_characterLitBFNRT:constant Wide_Wide_String:=Y2018Text_DSECT.W1008;

	characterLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1009;
	--characterLitX:constant Wide_Wide_String:="'(?:[^']|'')'[^W]"W;
	commentLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1010;         -- 1. [-] 2. [-]
	andLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1011; -- 2. [aA] 3. [nN]
	orLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1012;   -- 2. [oO]
	xorLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1013; -- 2. [xX]
	eqLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1014;    -- 2. [=]
	neLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1015;   -- 2. [/] 3. [=]
	ltLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1016;    -- 2. [<] 3. ["]
	leLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1017;   -- 2. [<] 3. [=]
	gtLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1018;    -- 2. [>] 3. ["]
	geLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1019;   -- 2. [>] 3. [=]
	plusLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1020;  -- 2. [+]
	minLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1021;   -- 2. [-]
	etLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1022;    -- 2. [&]
	multLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1023;  -- 2. [*] 3. ["]
	divLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1024;   -- 2. [/] 3. ["]
	modLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1025; -- 2. [mM]
	remLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1026; -- 2. [rR]
	expLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1027;  -- 2. [*] 3.[*]
	absLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1028; -- 2. [aA] 3. [bB]
	notLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1029; -- 2. [nN]

	apoLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1030;

	andLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1031; -- 2. [aA] 3. [nN]
	orLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1032;   -- 2. [oO]
	xorLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1033; -- 2. [xX]
	eqLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1034;    -- 2. [=]
	neLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1035;   -- 2. [/] 3. [=]
	ltLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1036;    -- 2. [<] 3. ["]
	leLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1037;   -- 2. [<] 3. [=]
	gtLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1038;    -- 2. [>] 3. ["]
	geLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1039;   -- 2. [>] 3. [=]
	plusLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1040;  -- 2. [+]
	minLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1041;   -- 2. [-]
	etLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1042;    -- 2. [&]
	multLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1043;  -- 2. [*] 3. ["]
	divLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1044;   -- 2. [/] 3. ["]
	modLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1045; -- 2. [mM]
	remLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1046; -- 2. [rR]
	expLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1047;  -- 2. [*] 3.[*]
	absLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1048; -- 2. [aA] 3. [bB]
	notLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1049; -- 2. [nN]
	
	patternLineSimple: Y2018.Text.Regex.PatternPack.Pattern_TY;
	patternEnd: Y2018.Text.Regex.PatternPack.Pattern_TY;
	patternProcedureName: Y2018.Text.Regex.PatternPack.Pattern_TY;
	patternPackageHeadName: Y2018.Text.Regex.PatternPack.Pattern_TY;
	patternPackageBodyName: Y2018.Text.Regex.PatternPack.Pattern_TY;
	patternDsect: Y2018.Text.Regex.PatternPack.Pattern_TY;
	source_from:Unbounded_String;
	csect_to:Unbounded_String;
	dsect_to:Unbounded_String;
	csect_toFrom:Unbounded_String;
	dsect_toFrom:Unbounded_String;
	j:Integer;
	sourceFile, csectFile, dsectFile, tmpAlfaOutFile, tmpAlfaInFile, tmpBetaOutFile, tmpBetaInFile : File_Type;
	nameus:Unbounded_Wide_Wide_String;
	dsectOK:Boolean:=FALSE;
	tailOK:Boolean:=FALSE;
	matchOK:Boolean:=FALSE;
	lineCntDSECT:Integer:=0;
	quote:constant Wide_Wide_String:=( 1 => Wide_Wide_Character'Val(16#22#));
	apo:constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#27#);
	patternData:Unbounded_Wide_Wide_String;
	lineCnt:Integer:=0;
	verbose:Integer:=0;
	pointus:constant Unbounded_Wide_Wide_String:=To_Unbounded_Wide_Wide_String(Y2018Text_DSECT.W1050);
	
-- *********** Dfunction.adb ************
	--.............................--
	--                             --
	--.............................--
	function To_Hex9(v :Integer) return String is
		r : String(1..8):="HHHHHHH0";
		k : Integer:=8;
		i : Long_Long_Integer;
	begin
		if  v>=0 then i:= Long_Long_Integer(v);
		else i:= 16#100000000# + Long_Long_Integer(v); end if;
		while i > 0 loop
			case i mod 16 is
				when 0 => r(k):='0';
				when 1 => r(k):='1';
				when 2 => r(k):='2';
				when 3 => r(k):='3';
				when 4 => r(k):='4';
				when 5 => r(k):='5';
				when 6 => r(k):='6';
				when 7 => r(k):='7';
				when 8 => r(k):='8';
				when 9 => r(k):='9';
				when 10 => r(k):='A';
				when 11 => r(k):='B';
				when 12 => r(k):='C';
				when 13 => r(k):='D';
				when 14 => r(k):='E';
				when others => r(k):='F';
			end case;
			i:=i / 16;
			k:=k - 1;
		end loop;
		return r;
	end To_Hex9;
	--.............................--
	--                             --
	--.............................--
	function blankadd(s:Wide_Wide_String) return Wide_Wide_String is
			r:Unbounded_Wide_Wide_String;
		begin
		if s'Length = 0 then
			return s;
		elsif s(s'Last) = '"' then
			r:=Null_Unbounded_Wide_Wide_String & s & Y2018Text_DSECT.W1051;
			return To_Wide_Wide_String(r);--""W & r;
		else
			return s;
		end if;
	end blankadd;
	--.............................--
	-- To_HexLit                   --
	--.............................--
	function To_HexLit(s:Wide_Wide_String) return Wide_Wide_String is
		r:Unbounded_Wide_Wide_String;
		i:Integer:=1;
		j:Integer:=0;
	begin
		if s'First(1) /= 1 then 
			raise Program_Error with E_TY'Image(Y2018.Text.E4208) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Index. Line" & ":" & Integer'Image(lineCnt);
		end if;
		while i <= s'Last(1) loop
			j:=J+1;
			if s(i) = Wide_Wide_Character'Val(16#5C#) and i = s'Last(1) then
				raise Program_Error with E_TY'Image(Y2018.Text.E4209) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
			elsif s(i) = Wide_Wide_Character'Val(16#5C#) then
				case s(i+1) is
					when Wide_Wide_Character'Val(16#62#) => --\b BS
						r := r & Y2018Text_DSECT.W1052;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#66#) => -- \f FF
						r := r & Y2018Text_DSECT.W1053;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#6E#) => -- \n LF 
						r := r & Y2018Text_DSECT.W1054;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#72#) => -- \r CR
						r := r & Y2018Text_DSECT.W1055;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#74#) => -- \t HT
						r := r & Y2018Text_DSECT.W1056;
						i:=i + 2;
						---
					when Wide_Wide_Character'Val(16#64#) => -- \d
						r := r & Y2018Text_DSECT.W1057;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#44#) => -- \D
						r := r & Y2018Text_DSECT.W1058;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#70#) => -- \p
						r := r & Y2018Text_DSECT.W1059;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#50#) => -- \P
						r := r & Y2018Text_DSECT.W1060;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#73#) => -- \s
						r := r & Y2018Text_DSECT.W1061;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#53#) => -- \S
						r := r & Y2018Text_DSECT.W1062;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#77#) => -- \w
						r := r & Y2018Text_DSECT.W1063;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#57#) => -- \W
						r := r & Y2018Text_DSECT.W1064;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#5C#) => -- \\
						--r := r & "Wide_Wide_Character'Val(16#5C#),Wide_Wide_Character'Val(16#5C#)"W; -- removed 20190520
						r := r & Y2018Text_DSECT.W1065; -- inserted 20190520
						i:=i + 2;
					when Wide_Wide_Character'Val(16#78#) => -- \x
						if i + 3 > s'Last(1) then
							raise Program_Error with E_TY'Image(Y2018.Text.E4210) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
						end if;
						r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,2) & Y2018Text_DSECT.W1067;
						i:=i + 4;
					when Wide_Wide_Character'Val(16#75#) => -- \u
						if i + 5 > s'Last(1) then
							raise Program_Error with E_TY'Image(Y2018.Text.E4211) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
						end if;
						r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,4) & Y2018Text_DSECT.W1067;
						i:=i + 6;
					when Wide_Wide_Character'Val(16#76#) => -- \v
						if i + 7 > s'Last(1) then
							raise Program_Error with E_TY'Image(Y2018.Text.E4212) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
						end if;
						r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,6) & Y2018Text_DSECT.W1067;
						i:=i + 8;
					when Wide_Wide_Character'Val(16#79#) => -- \y
						if i + 9 > s'Last(1) then
							raise Program_Error with E_TY'Image(Y2018.Text.E4213) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
						end if;
						r := r & "Wide_Wide_Character'Val(16#W" & Tool.Substr(s,i + 2,8) & Y2018Text_DSECT.W1067;
						i:=i + 10;
					when others =>
						raise Program_Error with E_TY'Image(Y2018.Text.E4214) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
				end case;
			elsif s(i) = Wide_Wide_Character'Val(16#22#) then
				if i+1 > s'Last(1) then
					raise Program_Error with E_TY'Image(Y2018.Text.E4215) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Missing quote. Line" & ":" & Integer'Image(lineCnt);
				elsif s(i+1) = Wide_Wide_Character'Val(16#22#) then
					r := r & Y2018Text_DSECT.W1068;
					i:=i+2;
				else
					raise Program_Error with E_TY'Image(Y2018.Text.E4216) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Missing quote. Line" & ":" & Integer'Image(lineCnt);
				end if;
			else
				r:=r & Y2018Text_DSECT.W1066 & Tool.LeftStrip(Tool.To_Hex8W(s(i)),Y2018Text_DSECT.W1069(1)) & Y2018Text_DSECT.W1067;
				i:=i+1;
			end if;
			if i> s'Last(1) then
				null;
			else
				r:=r & Y2018Text_DSECT.W1070;
			end if;
		end loop;
		case j is
			when 0 =>
				raise Program_Error with E_TY'Image(Y2018.Text.E4217) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Empty. Line" & ":" & Integer'Image(lineCnt);
			when 1 =>
				return Y2018Text_DSECT.W1071 & To_Wide_Wide_String(r) & Y2018Text_DSECT.W1072;
			when others =>
				return Y2018Text_DSECT.W1073 & To_Wide_Wide_String(r) & Y2018Text_DSECT.W1072;
		end case;
	end To_HexLit;
	--.............................--
	--  To_HexLitC                 --
	--.............................--
	function To_HexLitC(s:Wide_Wide_String) return Wide_Wide_String is
		r:Unbounded_Wide_Wide_String;
		i:Integer:=1;
	begin
		if s'First(1) /= 1 then
			raise Program_Error with E_TY'Image(Y2018.Text.E4218) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Index. Line" & ":" & Integer'Image(lineCnt);
		end if;
		if s(i) = Wide_Wide_Character'Val(16#5C#) and i = s'Last(1) then
			raise Program_Error with E_TY'Image(Y2018.Text.E4219) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
		elsif s(i) = Wide_Wide_Character'Val(16#5C#) then
			case s(i+1) is
				when Wide_Wide_Character'Val(16#62#) => --\b BS
					r := r & Y2018Text_DSECT.W1052;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#66#) => -- \f FF
					r := r & Y2018Text_DSECT.W1053;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#6E#) => -- \n LF 
					r := r & Y2018Text_DSECT.W1054;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#72#) => -- \r CR
					r := r & Y2018Text_DSECT.W1055;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#74#) => -- \t HT
					r := r & Y2018Text_DSECT.W1056;
					i:=i + 2;
					---
				when Wide_Wide_Character'Val(16#64#) => -- \d
					r := r & Y2018Text_DSECT.W1057;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#44#) => -- \D
					r := r & Y2018Text_DSECT.W1058;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#70#) => -- \p
					r := r & Y2018Text_DSECT.W1059;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#50#) => -- \P
					r := r & Y2018Text_DSECT.W1060;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#73#) => -- \s
					r := r & Y2018Text_DSECT.W1061;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#53#) => -- \S
					r := r & Y2018Text_DSECT.W1062;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#77#) => -- \w
					r := r & Y2018Text_DSECT.W1063;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#57#) => -- \W
					r := r & Y2018Text_DSECT.W1064;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#5C#) => -- \\
					r := r & Y2018Text_DSECT.W1074;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#78#) => -- \x
					if i + 3 > s'Last(1) then
						raise Program_Error with E_TY'Image(Y2018.Text.E4220) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
					end if;
					r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,2) & Y2018Text_DSECT.W1067;
					i:=i + 4;
				when Wide_Wide_Character'Val(16#75#) => -- \u
					if i + 5 > s'Last(1) then
						raise Program_Error with E_TY'Image(Y2018.Text.E4221) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
					end if;
					r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,4) & Y2018Text_DSECT.W1067;
					i:=i + 6;
				when Wide_Wide_Character'Val(16#76#) => -- \v
					if i + 7 > s'Last(1) then
						raise Program_Error with E_TY'Image(Y2018.Text.E4222) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
					end if;
					r := r & Y2018Text_DSECT.W1066 & Tool.Substr(s,i + 2,6) & Y2018Text_DSECT.W1067;
					i:=i + 8;
				when Wide_Wide_Character'Val(16#79#) => -- \y
					if i + 9 > s'Last(1) then
						raise Program_Error with E_TY'Image(Y2018.Text.E4223) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
					end if;
					r := r & "Wide_Wide_Character'Val(16#W" & Tool.Substr(s,i + 2,8) & Y2018Text_DSECT.W1067;
					i:=i + 10;
				when others =>
					raise Program_Error with E_TY'Image(Y2018.Text.E4224) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Illegal Backslash. Line" & ":" & Integer'Image(lineCnt);
			end case;
		elsif s(i) = Wide_Wide_Character'Val(16#27# ) then
			if i+1 > s'Last(1) then
				raise Program_Error with E_TY'Image(Y2018.Text.E4225) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Missing apostrophe. Line" & ":" & Integer'Image(lineCnt);
			elsif s(i+1) = Wide_Wide_Character'Val(16#27#) then
				r := r & Y2018Text_DSECT.W1075;
				i:=i+2;
			else
				raise Program_Error with E_TY'Image(Y2018.Text.E4226) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Missing apostrophe. Line" & ":" & Integer'Image(lineCnt);
			end if;
		else
			r:=r & Y2018Text_DSECT.W1066 & Tool.LeftStrip(Tool.To_Hex8W(s(i)),Y2018Text_DSECT.W1069(1)) & Y2018Text_DSECT.W1067;
			i:=i+1;
		end if;
		if i < s'Last(1) then
			raise Program_Error with E_TY'Image(Y2018.Text.E4227) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " More than one character. Line" & ":" & Integer'Image(lineCnt);
		end if;
		return To_Wide_Wide_String(r);
	end To_HexLitC;
	--.............................--
	--  PutLineCount               --
	--.............................--
	procedure PutLineCount(v:Integer) is
		BS:constant Character:=Character'Val(16#08#);
	begin
		--Put (Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(v),Ada.Strings.Left),6,'0') & Ada.Strings.Fixed."*"(6,BS));
		Put (
			Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(v),Ada.Strings.Left),6,' ') & ':' &
			Ada.Strings.Fixed."*"(7*1,BS));
	end PutLineCount;
	
	--.............................--
	--  DsectCharacter             --
	--.............................--
function DsectCharacter(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding '-characters
	key: Unbounded_Wide_Wide_String:= To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(CMap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntCharacter:=cntCharacter+1;
	v.s:=Y2018Text_DSECT.W1076 & UTF.To32(To_Hex9(cntCharacter));
	Dmap_TY.Insert(CMap,key,v);
	Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1077 & q & Y2018Text_DSECT.W1078));
	return UTF.To8(v.s);
end DsectCharacter;
	--.............................--
	--  DsectString                --
	--.............................--
function DsectString(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Unbounded_Wide_Wide_String:= To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(Smap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntString:=cntString+1;
	v.s:=Y2018Text_DSECT.W1079 & UTF.To32(To_Hex9(cntString));
	Dmap_TY.Insert(Smap,key,v);
	if q'Last(1) < q'First(1) then
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1080));
	else
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1081 & q & Y2018Text_DSECT.W1082));
	end if;
	return UTF.To8(v.s);
end DsectString;
	--.............................--
	--  DsectWWCharacter           --
	--.............................--
function DsectWWCharacter(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Unbounded_Wide_Wide_String:= To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(WWCmap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntWWCharacter:=cntWWCharacter+1;
	v.s:=Y2018Text_DSECT.W1083 & UTF.To32(To_Hex9(cntWWCharacter));
	Dmap_TY.Insert(WWCmap,key,v);
	Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1084 & To_HexLitC(q) & Y2018Text_DSECT.W1085));
	return UTF.To8(v.s);
end DsectWWCharacter;
	--.............................--
	--  DsectWWString              --
	--.............................--
function DsectWWString(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Unbounded_Wide_Wide_String:= To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(WWSmap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntWWString:=cntWWString+1;
	v.s:=Y2018Text_DSECT.W1086 & UTF.To32(To_Hex9(cntWWString));
	Dmap_TY.Insert(WWSmap,key,v);
	if q'Last(1) < q'First(1) then
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1087));
	else
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1088 & To_HexLit(q) & Y2018Text_DSECT.W1085));
	end if;
	return UTF.To8(v.s);
end DsectWWString;
-- *********** EouterHead.adb ************
	--.............................--
	--                             --
	--.............................--
begin
	Put_Line (program_info);
	j:=1;
	while j<= Ada.Command_Line.Argument_Count loop
		declare
			s:String:=Ada.Command_Line.Argument(j);
		begin
			if s'Length(1) = 0 then
				null;
			elsif s(1) = '-' then
				if s = "-v" then
					verbose:=100;
				elsif s = "-v1" then
					verbose:=1;
				elsif s = "-v10" then
					verbose:=10;
				elsif s = "-v100" then
					verbose:=100;
				elsif s = "-v1000" then
					verbose:=1000;
				else
					null;
				end if;
			elsif Length(source_from) = 0 then
				source_from:=To_Unbounded_String(s);
			elsif Length(csect_to) = 0 then
				csect_to:=To_Unbounded_String(s);
				dsect_to:=To_Unbounded_String(s);
				csect_toFrom:=To_Unbounded_String(s & "csect.lst");
				dsect_toFrom:=To_Unbounded_String(s & "dsect.lst");
			else
				null;
			end if;
		end;
		j:=j+1;
	end loop;
	cntCharacter:=cnt_Start;
	cntString:=cnt_Start;
	cntWWCharacter:=cnt_Start;
	cntWWString:=cnt_Start;
	begin
		Open (File => sourceFile,Mode => In_File,Name => To_String(source_from));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not open the file '" & To_String(source_from) & "'. Does it exist?");
			Set_Exit_Status (Failure);
			return;
	end;
	begin
		Create (File => tmpBetaOutFile,Mode => Out_File,Name => To_String(dsect_toFrom));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not create a file named '" & To_String(dsect_toFrom) & "'.");
			Set_Exit_Status (Failure);
			return;
	end;
	begin
		Create (File => tmpAlfaOutFile,Mode => Out_File,Name => To_String(csect_toFrom));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not create a file named '" & To_String(csect_toFrom) & "'.");
			Set_Exit_Status (Failure);
			return;
	end;
	patternData:=To_Unbounded_Wide_Wide_String(
		Y2018Text_DSECT.W1089 & 
		commentLit &  Y2018Text_DSECT.W1090 &
		andLit & Y2018Text_DSECT.W1090 &
		orLit & Y2018Text_DSECT.W1090 &
		xorLit & Y2018Text_DSECT.W1090 &
		eqLit & Y2018Text_DSECT.W1090 &
		neLit & Y2018Text_DSECT.W1090 &
		ltLit & Y2018Text_DSECT.W1090 &
		leLit & Y2018Text_DSECT.W1090 &
		gtLit & Y2018Text_DSECT.W1090 &
		geLit & Y2018Text_DSECT.W1090 &
		plusLit & Y2018Text_DSECT.W1090 &
		minLit & Y2018Text_DSECT.W1090 &
		etLit & Y2018Text_DSECT.W1090 &
		multLit & Y2018Text_DSECT.W1090 &
		divLit & Y2018Text_DSECT.W1090 &
		modLit & Y2018Text_DSECT.W1090 &
		remLit & Y2018Text_DSECT.W1090 &
		expLit & Y2018Text_DSECT.W1090 &
		absLit & Y2018Text_DSECT.W1090 &
		notLit & Y2018Text_DSECT.W1090 &
		apoLit & Y2018Text_DSECT.W1090 &
		wide_wide_stringLit & Y2018Text_DSECT.W1090 & 
		wide_wide_characterLit &  Y2018Text_DSECT.W1090 &
		stringLitS & Y2018Text_DSECT.W1090 &
		stringLit & Y2018Text_DSECT.W1090 &
		characterLit & "|" &
		wide_wide_characterLitX & "|" &
		wide_wide_characterLitU & "|" &
		wide_wide_characterLitV & "|" &
		wide_wide_characterLitY & "|" &
		wide_wide_characterLitBFNRT &
		Y2018Text_DSECT.W1072); 
	Y2018.Text.Regex.PatternPack.Pattern(patternLineSimple,To_Wide_Wide_String(patternData),G_UPPERCASE);
	patternData:=To_Unbounded_Wide_Wide_String(
		Y2018Text_DSECT.W1091 & 
		andLitE & Y2018Text_DSECT.W1090 &
		orLitE & Y2018Text_DSECT.W1090 &
		xorLitE & Y2018Text_DSECT.W1090 &
		eqLitE & Y2018Text_DSECT.W1090 &
		neLitE & Y2018Text_DSECT.W1090 &
		ltLitE & Y2018Text_DSECT.W1090 &
		leLitE & Y2018Text_DSECT.W1090 &
		gtLitE & Y2018Text_DSECT.W1090 &
		geLitE & Y2018Text_DSECT.W1090 &
		plusLitE & Y2018Text_DSECT.W1090 &
		minLitE & Y2018Text_DSECT.W1090 &
		etLitE & Y2018Text_DSECT.W1090 &
		multLitE & Y2018Text_DSECT.W1090 &
		divLitE & Y2018Text_DSECT.W1090 &
		modLitE & Y2018Text_DSECT.W1090 &
		remLitE & Y2018Text_DSECT.W1090 &
		expLitE & Y2018Text_DSECT.W1090 &
		absLitE & Y2018Text_DSECT.W1090 &
		notLitE &
		Y2018Text_DSECT.W1072);
	Y2018.Text.Regex.PatternPack.Pattern(patternEnd,To_Wide_Wide_String(patternData),G_UPPERCASE);

	Y2018.Text.Regex.PatternPack.Pattern(patternProcedureName,Y2018Text_DSECT.W1092,G_UPPERCASE);
	Y2018.Text.Regex.PatternPack.Pattern(patternPackageHeadName,Y2018Text_DSECT.W1093,G_UPPERCASE);
	Y2018.Text.Regex.PatternPack.Pattern(patternPackageBodyName,Y2018Text_DSECT.W1094,G_UPPERCASE);
	Patternpack.Pattern(patternDsect,Y2018Text_DSECT.W1095,G_UPPERCASE); -- -- with DSECT;
	
	-----------------------
	-- Sourcefile loop   --
	-----------------------
	while not End_Of_File(sourceFile) loop
		declare -- SourceFile Block
			s:Wide_Wide_String:=blankadd(UTF.To32(Get_Line(sourceFile)));
			q1us: Unbounded_Wide_Wide_String;
			qus_tail: Unbounded_Wide_Wide_String;
			rus:Unbounded_Wide_Wide_String; -- new 's'
			end0us:Unbounded_Wide_Wide_String;
			end1us:Unbounded_Wide_Wide_String;
			found:Boolean:=FALSE;
			t_end:Toil_TY;
			v_end:Y2018.Text.Regex.G_Vector.Vector;
			--c_end:Y2018.Text.Regex.G_Vector.Cursor;

			t_s:Toil_TY;
			v_s:Y2018.Text.Regex.G_Vector.Vector;
		begin
			lineCnt:=lineCnt + 1;
			if verbose = 0 then
				null;
			elsif lineCnt mod verbose = 0 then
				PutLineCount(lineCnt);
			end if;
			if code = CODE_UNDEF then -- patternProcedureName
				declare
					t:Toil_TY;
					v:Y2018.Text.Regex.G_Vector.Vector;
					j:Y2018.Text.Regex.G_Element;
				begin
					Y2018.Text.Regex.PatternPack.Toil(t,patternProcedureName,s);
					v:=Y2018.Text.Regex.ToilPack.Match(t);
					if Y2018.Text.Regex.G_Vector.Length(v) >=2 then
						j:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v)));
						code:=CODE_PROCEDURE;
						nameus:=j.v;
						csect_to:=csect_to & Tool.To_LC(UTF.To8(nameus)) & ":adb";
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(nameus)) & "_psect:ads";
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & To_String(UTF.To8(nameus & Y2018Text_DSECT.W1096)) & " is");
						nameus:=nameus & Y2018Text_DSECT.W1096;
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					end if;
				end;
			end if; -- patternProcedureName
			if code = CODE_UNDEF then -- patternPackageBodyName
				declare
					t:Toil_TY;
					v:Y2018.Text.Regex.G_Vector.Vector;
					j:Y2018.Text.Regex.G_Element;
				begin
					Y2018.Text.Regex.PatternPack.Toil(t,patternPackageBodyName,s);
					v:=Y2018.Text.Regex.ToilPack.Match(t);
					if Y2018.Text.Regex.G_Vector.Length(v) >=2 then
						j:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v)));
						code:=CODE_PACKAGEBODY;
						nameus:=j.v;
						csect_to:=csect_to & Tool.To_LC(UTF.To8(nameus)) & ":adb";
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(nameus)) & "_bsect:ads";
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & To_String(UTF.To8(nameus & Y2018Text_DSECT.W1097)) & " is");
						nameus:=nameus & Y2018Text_DSECT.W1097;
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					end if;
				end;
			end if; -- patternPackageBodyName
			if code = CODE_UNDEF then -- patternPackageHeadName
				declare
					t:Toil_TY;
					v:Y2018.Text.Regex.G_Vector.Vector;
					j:Y2018.Text.Regex.G_Element;
				begin
					Y2018.Text.Regex.PatternPack.Toil(t,patternPackageHeadName,s);
					v:=Y2018.Text.Regex.ToilPack.Match(t);
					if Y2018.Text.Regex.G_Vector.Length(v) >=2 then
						j:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v)));
						code:=CODE_PACKAGEHEAD;
						nameus:=j.v;
						csect_to:=csect_to & Tool.To_LC(UTF.To8(nameus)) & ":ads"; -- ***************
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(nameus)) & "_hsect:ads";
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & To_String(UTF.To8(nameus & Y2018Text_DSECT.W1098)) & " is");
						nameus:=nameus & Y2018Text_DSECT.W1098;
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					end if;
				end;
			end if; -- patternPackageHeadName
			if lineCntDSECT = 0 then -- patternDsect
				declare
					t:Toil_TY;
					v:Y2018.Text.Regex.G_Vector.Vector;
				begin
					Y2018.Text.Regex.PatternPack.Toil(t,patternDsect,s);
					v:=Y2018.Text.Regex.ToilPack.Match(t);
					if Y2018.Text.Regex.G_Vector.Length(v) >=1 then
						lineCntDSECT:=lineCnt;
						dsectOK:=TRUE;
					end if;
				end;
			end if; -- patternDsect
			Y2018.Text.Regex.PatternPack.Toil(t_end,patternEnd,s);
			v_end:=Y2018.Text.Regex.ToilPack.Match(t_end);
			if Y2018.Text.Regex.G_Vector.Length(v_end) >=2 then
				end0us:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.First(v_end)).v;
				end1us:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v_end))).v;
				Y2018.Text.Regex.PatternPack.Toil(t_s,patternLineSimple,To_Wide_Wide_String(end1us));
				end0us:=Y2018.Text.Core.Tool.substr(end0us,1,Integer(Length(end0us))-Integer(Length(end1us)));
				-- Get anything after "END"
			else
				end0us:=Null_Unbounded_Wide_Wide_String;
				end1us:=Null_Unbounded_Wide_Wide_String;
				Y2018.Text.Regex.PatternPack.Toil(t_s,patternLineSimple,s);
				-- Get all from line
			end if;
-- *********** Fcenter.adb ************
			-----------------
			-- line loop   --
			-----------------
			qus_tail:=To_Unbounded_Wide_Wide_String(s);
			found:=Y2018.Text.Regex.ToilPack.has_Toil(t_s);
			while found loop
				v_s:=Y2018.Text.Regex.ToilPack.Match(t_s);
				-----------------------
				-- vector processing --
				-----------------------
				-- 0 > all
				-- 1 > (.*?) element
				-- 2 > (<element>)
				declare -- Vector Block
					q2us:Unbounded_Wide_Wide_String:=
						Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v_s)))).v; -- element 2 v-value
					q2fs:Wide_Wide_String:=To_Wide_Wide_String(q2us); -- element 2 v-value
				begin
					q1us:=Y2018.Text.Regex.G_Vector.Element(Y2018.Text.Regex.G_Vector.Next(Y2018.Text.Regex.G_Vector.First(v_s))).v; -- element 1 v-value
					qus_tail:=To_Unbounded_Wide_Wide_String(tail(t_s));
					if q2fs(1) = Y2018Text_DSECT.W1099(1) and q2fs(2) = Y2018Text_DSECT.W1099(1) then
						rus:=rus & q1us & Y2018Text_DSECT.W1010 ; 
						--qus_tail:=To_Unbounded_Wide_Wide_String(tail(t_s));
						exit;
					elsif (q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1100(1) or q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1101(1)) and q2fs(q2fs'First(1)) = '"' then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4201) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & nameus & pointus & UTF.To32(To_Unbounded_String(DsectWWString(Y2018.Text.Core.Tool.substr(q2fs,2,q2fs'Last(1)-q2fs'First(1)-2))));
					elsif (q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1100(1) or q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1101(1)) and q2fs(q2fs'First(1)) = apo then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4202) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & nameus & pointus & UTF.To32(To_Unbounded_String(DsectWWCharacter(Y2018.Text.Core.Tool.substr(q2fs,2,q2fs'Last(1)-q2fs'First(1)-2))));
					elsif q2fs(q2fs'Last(1)) = apo then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4204) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & nameus & pointus & UTF.To32(To_Unbounded_String(DsectCharacter(Y2018.Text.Core.Tool.substr(q2fs,2,q2fs'Last(1)-q2fs'First(1)-1))));
					elsif q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1073(1) and q2fs(q2fs'First(1)) = '"' then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4205) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & q2us;
					elsif q2fs(q2fs'First(1)) = apo then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4206) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & q2us;
					elsif (q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1102(1) or q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1103(1)) and q2fs(q2fs'First(1)) = '"' then
						rus:=rus & q1us & Y2018.Text.Core.Tool.substr(q2fs,1,q2fs'Last(1)-q2fs'First(1));
					elsif q2fs(q2fs'Last(1)) = Y2018Text_DSECT.W1104(1)  and q2fs(q2fs'First(1)) = '"' then
						if code = CODE_UNDEF then
							raise Program_Error with E_TY'Image(Y2018.Text.E4203) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No code type. Line" & ":" & Integer'Image(lineCnt);
						end if;
						rus:=rus & q1us & nameus & pointus & UTF.To32(To_Unbounded_String(DsectString(Y2018.Text.Core.Tool.substr(q2fs,2,q2fs'Last(1)-q2fs'First(1)-1))));
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E4228) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Unknown pattern. Line" & ":" & Integer'Image(lineCnt);
					end if;
				end; -- Vector Block
				next(t_s);
				found:=Y2018.Text.Regex.ToilPack.has_Toil(t_s);
			end loop; -- while found loop
			Put_Line(tmpAlfaOutFile,UTF.To8(To_Wide_Wide_String(end0us & rus & qus_tail)));
-- *********** GouterTail.adb ************
		end; -- SourceFile Block
	end loop; -- while not End_Of_File(sourceFile) loop
	Put_line(tmpBetaOutFile,"end " & To_String(UTF.To8(nameus)) & ";" );
	Close(tmpAlfaOutFile);
	Close(sourceFile);
	Close(tmpBetaOutFile);
	if Length(nameus) = 0 then
		raise Program_Error with E_TY'Image(Y2018.Text.E4207) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " No procedure or package statement found. Line" & ":" & Integer'Image(lineCnt);
	end if;
	declare
		fname:String:=To_String(csect_to);
	begin
		j:=1;
		while j<=fname'Last(1) loop
			if fname(j) = '.' then
				fname(j) := '-';
			elsif fname(j) = ':' then
				fname(j) := '.'; 
			end if;
			j:=j+1;
		end loop;
		begin
			Open (File => tmpAlfaInFile,Mode => In_File,Name => To_String(csect_toFrom));
		exception
			when others =>
				Put_Line (Standard_Error,"Can not open the file '" & To_String(source_from) & "'. Does it exist?");
				Set_Exit_Status (Failure);
				return;
		end;
		begin
			Create (File => csectFile,Mode => Out_File,Name => fname);
		exception
			when others =>
				Put_Line (Standard_Error,"Can not create a file named '" & fname & "'.");
				Set_Exit_Status (Failure);
				return;
		end;
		lineCnt:=0;
		while not End_Of_File(tmpAlfaInFile) loop
			declare
				s:Wide_Wide_String:=UTF.To32(Get_Line(tmpAlfaInFile));
			begin
				lineCnt:=lineCnt + 1;
				if dsectOK then
					if lineCntDSECT=lineCnt and (cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start) then
						Put_line(csectFile,"with " & To_String(UTF.To8(nameus)) & ";");
					else
						Put_Line(csectFile,UTF.To8(s));
					end if;
				else
					if lineCntDSECT=lineCnt and (cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start) then
						Put_line(csectFile,"with " & To_String(UTF.To8(nameus)) & ";");
					end if;
					Put_Line(csectFile,UTF.To8(s));
				end if;
			end;
		end loop;
		Close(csectFile);
		Close(tmpAlfaInFile);
	end;
	-----------------------
	--                   --
	-----------------------
	if cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start then
		declare
			fname:String:=To_String(dsect_to);
		begin
			j:=1;
			while j<=fname'Last(1) loop
				if fname(j) = '.' then
					fname(j) := '-';
				elsif fname(j) = ':' then
					fname(j) := '.'; 
				end if;
				j:=j+1;
			end loop;
			
			begin
				Open (File => tmpBetaInFile,Mode => In_File,Name => To_String(dsect_toFrom));
			exception
				when others =>
					Put_Line (Standard_Error,"Can not open the file '" & To_String(source_from) & "'. Does it exist?");
					Set_Exit_Status (Failure);
					return;
			end;
			begin
				Create (File => dsectFile,Mode => Out_File,Name => fname);
			exception
				when others =>
					Put_Line (Standard_Error,"Can not create a file named '" & fname & "'.");
					Set_Exit_Status (Failure);
					return;
			end;
			lineCnt:=0;
			while not End_Of_File(tmpBetaInFile) loop
				declare
					s:Wide_Wide_String:=UTF.To32(Get_Line(tmpBetaInFile));
				begin
					lineCnt:=lineCnt + 1;
					Put_Line(dsectFile,UTF.To8(s));
				end;
			end loop;
			Close(dsectFile);
			Close(tmpBetaInFile);
		end;
	end if;
exception
	when End_Error =>
		Close(sourceFile);
		Close(csectFile);
		Close(dsectFile);
		Close(tmpAlfaOutFile);
		Close(tmpAlfaInFile);
		Close(tmpBetaOutFile);
		Close(tmpBetaInFile);
end Y2018Text;
