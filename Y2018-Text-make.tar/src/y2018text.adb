-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Command_Line; use Ada.Command_Line;
with Ada.Strings; use Ada.Strings;
with Ada.Strings.Unbounded; --use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; --use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers.Ordered_Maps;
with Ada.Strings;
with Ada.Strings.Fixed;
with Y2018.Text.Core; use Y2018.Text.Core;
with Y2018.Text.Core.STR; use Y2018.Text.Core.STR;
with Y2018.Text.Core.Msg;
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.Tool;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack; 
with Y2018.Text.Regex.MatchPack; use Y2018.Text.Regex.MatchPack;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018Text_DSECT; -- GENERATED CODE
procedure Y2018Text is
	--.............................--
	--  Global type definition     --
	--.............................--
	type CODE_TY is (CODE_UNDEF,CODE_PROCEDURE, CODE_PACKAGEHEAD, CODE_PACKAGEBODY);
	type STR9_TY is
		record
			s:Wide_Wide_String(1..9);
		end record;
	--.............................--
	--  Dmap_TY support            --
	--.............................--
	function Cmp(first:Wide_Wide_String;second:Wide_Wide_String) return Integer is
	begin
		if first'LENGTH(1) = 0 and second'LENGTH(1) = 0 then
			return 0;
		elsif first'LENGTH(1) < second'LENGTH(1) then
			return -1;
		elsif first'LENGTH(1) > second'LENGTH(1) then
			return 1;
		end if;
		for i in first'FIRST(1) .. first'LAST(1) loop
			if first(i) > second(i) then
				return 1;
			elsif first(i) < second(i) then
				return -1;
			end if;
		end loop;
		return 0;
	end Cmp;
	function Cmp(first:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;second:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String) return Integer is
	begin
		return Cmp(Ada.Strings.Wide_Wide_Unbounded.to_Wide_Wide_String(first),Ada.Strings.Wide_Wide_Unbounded.to_Wide_Wide_String(second));
	end Cmp;
	function less (Left,Right:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String) return Boolean is
	begin
		case Cmp(Left,Right) is
			when -1 =>
				return TRUE;
			when others =>
				null;
		end case;
		return FALSE;
	end less;
	function equal (Left,Right:STR9_TY) return Boolean is
	begin
		case Cmp(Left.s,Right.s) is
			when 0 =>
				return TRUE;
			when others =>
				null;
		end case;
		return FALSE;
	end equal;
	package Dmap_TY is new Ada.Containers.Ordered_Maps(Key_Type=> Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String,Element_Type=> STR9_TY,"<"=> less, "="=> equal);
	--.............................--
	--                             --
	--.............................--
	function To_Hex9(v :Integer) return String is
		r : String(1..8):="HHHHHHH0";
		k : Integer:=8;
		i : Long_Long_Integer;
	begin
		if  v>=0 then i:= Long_Long_Integer(v);
		else i:= 16#100000000# + Long_Long_Integer(v); end if;
		while i > 0 loop
			case i mod 16 is
				when 0 => r(k):='0';
				when 1 => r(k):='1';
				when 2 => r(k):='2';
				when 3 => r(k):='3';
				when 4 => r(k):='4';
				when 5 => r(k):='5';
				when 6 => r(k):='6';
				when 7 => r(k):='7';
				when 8 => r(k):='8';
				when 9 => r(k):='9';
				when 10 => r(k):='A';
				when 11 => r(k):='B';
				when 12 => r(k):='C';
				when 13 => r(k):='D';
				when 14 => r(k):='E';
				when others => r(k):='F';
			end case;
			i:=i / 16;
			k:=k - 1;
		end loop;
		return r;
	end To_Hex9;
	--.............................--
	--                             --
	--.............................--
	function blankadd(s:Wide_Wide_String) return Wide_Wide_String is
			r:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
		begin
		if s'Length = 0 then
			return s;
		elsif s(s'Last) = '"' then
			r:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String & s & Y2018Text_DSECT.W1000;
			return "" & r;
		else
			return s;
		end if;
	end blankadd;
	--.............................--
	-- Global variables            --
	--.............................--
	WWSmap: Dmap_TY.Map;
	SMap: Dmap_TY.Map;
	WWCmap: Dmap_TY.Map;
	CMap: Dmap_TY.Map;
	--cnt:Integer;
	cntCharacter:Integer;
	cntString:Integer;
	cntWWCharacter:Integer;
	cntWWString:Integer;
	cnt_Start: constant Integer:=1000;
	
	code:CODE_TY:=CODE_UNDEF;

	wide_wide_stringLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1001;
	stringLitS:constant Wide_Wide_String:=Y2018Text_DSECT.W1002;
	stringLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1003;
	--stringLitX:constant Wide_Wide_String:="""(?:[^""]|"""")*""[^WS]"W;
	wide_wide_characterLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1004;

	wide_wide_characterLitX:constant Wide_Wide_String:=Y2018Text_DSECT.W1005;
	wide_wide_characterLitU:constant Wide_Wide_String:=Y2018Text_DSECT.W1006;
	wide_wide_characterLitV:constant Wide_Wide_String:=Y2018Text_DSECT.W1007;
	wide_wide_characterLitY:constant Wide_Wide_String:=Y2018Text_DSECT.W1008;

	characterLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1009;
	--characterLitX:constant Wide_Wide_String:="'(?:[^']|'')'[^W]"W;
	commentLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1010;         -- 1. [-] 2. [-]
	andLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1011; -- 2. [aA] 3. [nN]
	orLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1012;   -- 2. [oO]
	xorLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1013; -- 2. [xX]
	eqLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1014;    -- 2. [=]
	neLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1015;   -- 2. [/] 3. [=]
	ltLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1016;    -- 2. [<] 3. ["]
	leLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1017;   -- 2. [<] 3. [=]
	gtLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1018;    -- 2. [>] 3. ["]
	geLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1019;   -- 2. [>] 3. [=]
	plusLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1020;  -- 2. [+]
	minLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1021;   -- 2. [-]
	etLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1022;    -- 2. [&]
	multLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1023;  -- 2. [*] 3. ["]
	divLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1024;   -- 2. [/] 3. ["]
	modLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1025; -- 2. [mM]
	remLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1026; -- 2. [rR]
	expLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1027;  -- 2. [*] 3.[*]
	absLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1028; -- 2. [aA] 3. [bB]
	notLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1029; -- 2. [nN]

	apoLit:constant Wide_Wide_String:=Y2018Text_DSECT.W1030;

	andLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1031; -- 2. [aA] 3. [nN]
	orLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1032;   -- 2. [oO]
	xorLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1033; -- 2. [xX]
	eqLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1034;    -- 2. [=]
	neLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1035;   -- 2. [/] 3. [=]
	ltLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1036;    -- 2. [<] 3. ["]
	leLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1037;   -- 2. [<] 3. [=]
	gtLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1038;    -- 2. [>] 3. ["]
	geLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1039;   -- 2. [>] 3. [=]
	plusLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1040;  -- 2. [+]
	minLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1041;   -- 2. [-]
	etLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1042;    -- 2. [&]
	multLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1043;  -- 2. [*] 3. ["]
	divLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1044;   -- 2. [/] 3. ["]
	modLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1045; -- 2. [mM]
	remLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1046; -- 2. [rR]
	expLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1047;  -- 2. [*] 3.[*]
	absLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1048; -- 2. [aA] 3. [bB]
	notLitE:constant Wide_Wide_String:=Y2018Text_DSECT.W1049; -- 2. [nN]
	
	ptcLineSimple: PatternPack.Pattern_AC;
	ptcEnd: PatternPack.Pattern_AC;
	ptcProcedureName: PatternPack.Pattern_AC;
	ptcPackageHeadName: PatternPack.Pattern_AC;
	ptcPackageBodyName: PatternPack.Pattern_AC;
	ptcDsect: PatternPack.Pattern_AC;
	m:MatchPack.Match_AC;
	source_from:Ada.Strings.Unbounded.Unbounded_String;
	csect_to:Ada.Strings.Unbounded.Unbounded_String;
	dsect_to:Ada.Strings.Unbounded.Unbounded_String;
	csect_toFrom:Ada.Strings.Unbounded.Unbounded_String;
	dsect_toFrom:Ada.Strings.Unbounded.Unbounded_String;
	j:Integer;
	sourceFile, csectFile, dsectFile, tmpAlfaOutFile, tmpAlfaInFile, tmpBetaOutFile, tmpBetaInFile : File_Type;
	name:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String;
	cursorLine: PatternPack.G_Cursor;
	cursorEnd: PatternPack.G_Cursor;
	--cursorOLD: PatternPack.G_Cursor;
	cursorDsect: PatternPack.G_Cursor;
	dsectOK:Boolean:=FALSE;
	tailOK:Boolean:=FALSE;
	matchOK:Boolean:=FALSE;
	lineCntDSECT:Integer:=0;
	quote:constant Wide_Wide_String:=( 1 => Wide_Wide_Character'Val(16#22#));
	apo:constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#27#);
	ps:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
	lineCnt:Integer:=0;
	--.............................--
	-- To_HexLit                   --
	--.............................--
	function To_HexLit(s:Wide_Wide_String) return Wide_Wide_String is
		r:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String;
		i:Integer:=1;
		j:Integer:=0;
	begin
		if s'First(1) /= 1 then 
			--raise Program_Error with "E13 Index";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(4208,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
		end if;
		while i <= s'Last(1) loop
			j:=J+1;
			if s(i) = Wide_Wide_Character'Val(16#5C#) and i = s'Last(1) then
				--raise Program_Error with "E01 Illegal Backslash";
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4209,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
			elsif s(i) = Wide_Wide_Character'Val(16#5C#) then
				case s(i+1) is
					when Wide_Wide_Character'Val(16#62#) => --\b BS
						r := r & Y2018Text_DSECT.W1050;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#66#) => -- \f FF
						r := r & Y2018Text_DSECT.W1051;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#6E#) => -- \n LF 
						r := r & Y2018Text_DSECT.W1052;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#72#) => -- \r CR
						r := r & Y2018Text_DSECT.W1053;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#74#) => -- \t HT
						r := r & Y2018Text_DSECT.W1054;
						i:=i + 2;
						---
					when Wide_Wide_Character'Val(16#64#) => -- \d
						r := r & Y2018Text_DSECT.W1055;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#44#) => -- \D
						r := r & Y2018Text_DSECT.W1056;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#70#) => -- \p
						r := r & Y2018Text_DSECT.W1057;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#50#) => -- \P
						r := r & Y2018Text_DSECT.W1058;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#73#) => -- \s
						r := r & Y2018Text_DSECT.W1059;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#53#) => -- \S
						r := r & Y2018Text_DSECT.W1060;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#77#) => -- \w
						r := r & Y2018Text_DSECT.W1061;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#57#) => -- \W
						r := r & Y2018Text_DSECT.W1062;
						i:=i + 2;
					when Wide_Wide_Character'Val(16#5C#) => -- \\
						--r := r & "Wide_Wide_Character'Val(16#5C#),Wide_Wide_Character'Val(16#5C#)"W; -- removed 20190520
						r := r & Y2018Text_DSECT.W1063; -- inserted 20190520
						i:=i + 2;
					when Wide_Wide_Character'Val(16#78#) => -- \x
						if i + 3 > s'Last(1) then
							--raise Program_Error with "E06 Illegal Backslash";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4210,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,2) & Y2018Text_DSECT.W1065;
						i:=i + 4;
					when Wide_Wide_Character'Val(16#75#) => -- \u
						if i + 5 > s'Last(1) then
							--raise Program_Error with "E07 Illegal Backslash";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4211,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,4) & Y2018Text_DSECT.W1065;
						i:=i + 6;
					when Wide_Wide_Character'Val(16#76#) => -- \v
						if i + 7 > s'Last(1) then
							--raise Program_Error with "E08 Illegal Backslash";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4212,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,6) & Y2018Text_DSECT.W1065;
						i:=i + 8;
					when Wide_Wide_Character'Val(16#79#) => -- \y
						if i + 9 > s'Last(1) then
							--raise Program_Error with "E09 Illegal Backslash";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4213,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						r := r & "Wide_Wide_Character'Val(16#W" & Tool.Substr(s,i + 2,8) & Y2018Text_DSECT.W1065;
						i:=i + 10;
					when others =>
						--raise Program_Error with "E02 Illegal Backslash";
						raise Program_Error with Y2018.Text.Core.Tool.getMsg(4214,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
				end case;
			elsif s(i) = Wide_Wide_Character'Val(16#22#) then
				if i+1 > s'Last(1) then
					--raise Program_Error with "E10 Missing quote";
					raise Program_Error with Y2018.Text.Core.Tool.getMsg(4215,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
				elsif s(i+1) = Wide_Wide_Character'Val(16#22#) then
					r := r & Y2018Text_DSECT.W1066;
					i:=i+2;
				else
					--raise Program_Error with "E11 Missing quote";
					raise Program_Error with Y2018.Text.Core.Tool.getMsg(4216,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
				end if;
			else
				r:=r & Y2018Text_DSECT.W1064 & Tool.LeftStrip(Tool.To_Hex8W(s(i)),Y2018Text_DSECT.W1067(1)) & Y2018Text_DSECT.W1065;
				i:=i+1;
			end if;
			if i> s'Last(1) then
				null;
			else
				r:=r & Y2018Text_DSECT.W1068;
			end if;
		end loop;
		case j is
			when 0 =>
				--raise Program_Error with "E12 Empty";
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4217,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
			when 1 =>
				return Y2018Text_DSECT.W1069 & r & Y2018Text_DSECT.W1070;
			when others =>
				return Y2018Text_DSECT.W1071 & r & Y2018Text_DSECT.W1070;
		end case;
	end To_HexLit;
	--.............................--
	--  To_HexLitC                 --
	--.............................--
	function To_HexLitC(s:Wide_Wide_String) return Wide_Wide_String is
		r:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String;
		i:Integer:=1;
	begin
		if s'First(1) /= 1 then
			--raise Program_Error with "E93 Index";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(4218,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
		end if;
		if s(i) = Wide_Wide_Character'Val(16#5C#) and i = s'Last(1) then
			--raise Program_Error with "E81 Illegal Backslash";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(4219,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
		elsif s(i) = Wide_Wide_Character'Val(16#5C#) then
			case s(i+1) is
				when Wide_Wide_Character'Val(16#62#) => --\b BS
					r := r & Y2018Text_DSECT.W1050;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#66#) => -- \f FF
					r := r & Y2018Text_DSECT.W1051;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#6E#) => -- \n LF 
					r := r & Y2018Text_DSECT.W1052;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#72#) => -- \r CR
					r := r & Y2018Text_DSECT.W1053;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#74#) => -- \t HT
					r := r & Y2018Text_DSECT.W1054;
					i:=i + 2;
					---
				when Wide_Wide_Character'Val(16#64#) => -- \d
					r := r & Y2018Text_DSECT.W1055;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#44#) => -- \D
					r := r & Y2018Text_DSECT.W1056;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#70#) => -- \p
					r := r & Y2018Text_DSECT.W1057;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#50#) => -- \P
					r := r & Y2018Text_DSECT.W1058;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#73#) => -- \s
					r := r & Y2018Text_DSECT.W1059;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#53#) => -- \S
					r := r & Y2018Text_DSECT.W1060;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#77#) => -- \w
					r := r & Y2018Text_DSECT.W1061;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#57#) => -- \W
					r := r & Y2018Text_DSECT.W1062;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#5C#) => -- \\
					r := r & Y2018Text_DSECT.W1072;
					i:=i + 2;
				when Wide_Wide_Character'Val(16#78#) => -- \x
					if i + 3 > s'Last(1) then
						--raise Program_Error with "E86 Illegal Backslash";
						raise Program_Error with Y2018.Text.Core.Tool.getMsg(4220,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
					end if;
					r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,2) & Y2018Text_DSECT.W1065;
					i:=i + 4;
				when Wide_Wide_Character'Val(16#75#) => -- \u
					if i + 5 > s'Last(1) then
						--raise Program_Error with "E87 Illegal Backslash";
						raise Program_Error with Y2018.Text.Core.Tool.getMsg(4221,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
					end if;
					r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,4) & Y2018Text_DSECT.W1065;
					i:=i + 6;
				when Wide_Wide_Character'Val(16#76#) => -- \v
					if i + 7 > s'Last(1) then
						--raise Program_Error with "E88 Illegal Backslash";
						raise Program_Error with Y2018.Text.Core.Tool.getMsg(4222,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
					end if;
					r := r & Y2018Text_DSECT.W1064 & Tool.Substr(s,i + 2,6) & Y2018Text_DSECT.W1065;
					i:=i + 8;
				when Wide_Wide_Character'Val(16#79#) => -- \y
					if i + 9 > s'Last(1) then
						--raise Program_Error with "E89 Illegal Backslash";
						raise Program_Error with Y2018.Text.Core.Tool.getMsg(4223,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
					end if;
					r := r & "Wide_Wide_Character'Val(16#W" & Tool.Substr(s,i + 2,8) & Y2018Text_DSECT.W1065;
					i:=i + 10;
				when others =>
					--raise Program_Error with "E82 Illegal Backslash";
					raise Program_Error with Y2018.Text.Core.Tool.getMsg(4224,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
			end case;
		elsif s(i) = Wide_Wide_Character'Val(16#27# ) then
			if i+1 > s'Last(1) then
				--raise Program_Error with "E90 Missing apostrophe";
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4225,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
			elsif s(i+1) = Wide_Wide_Character'Val(16#27#) then
				r := r & Y2018Text_DSECT.W1073;
				i:=i+2;
			else
				--raise Program_Error with "E91 Missing apostrophe";
				raise Program_Error with Y2018.Text.Core.Tool.getMsg(4226,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
			end if;
		else
			r:=r & Y2018Text_DSECT.W1064 & Tool.LeftStrip(Tool.To_Hex8W(s(i)),Y2018Text_DSECT.W1067(1)) & Y2018Text_DSECT.W1065;
			i:=i+1;
		end if;
		if i < s'Last(1) then
			--raise Program_Error with "E92 More than one character";
			raise Program_Error with Y2018.Text.Core.Tool.getMsg(4227,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
		end if;
		return Y2018Text_DSECT.W0000 & r;
	end To_HexLitC;
	--.............................--
	--  PutLineCount               --
	--.............................--
	procedure PutLineCount(v:Integer) is
		BS:constant Character:=Character'Val(16#08#);
	begin
		--Put (Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(v),Ada.Strings.Left),6,'0') & Ada.Strings.Fixed."*"(6,BS));
		Put (
			Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(v),Ada.Strings.Left),6,' ') & ':' &
			--Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(cntCharacter - cnt_Start),Ada.Strings.Left),6,' ') & ':' &
			--Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(cntString - cnt_Start),Ada.Strings.Left),6,' ') & ':' &
			--Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(cntWWCharacter - cnt_Start),Ada.Strings.Left),6,' ') & ':' &
			--Ada.Strings.Fixed.Tail(Ada.Strings.Fixed.Trim(Integer'Image(cntWWString - cnt_Start),Ada.Strings.Left),6,' ') & '<' &
			Ada.Strings.Fixed."*"(7*1,BS));
	end PutLineCount;
	
-- *********** DsectString.adb ************
	--.............................--
	--  DsectCharacter             --
	--.............................--
function DsectCharacter(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding '-characters
	key: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:= Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(CMap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntCharacter:=cntCharacter+1;
	v.s:=Y2018Text_DSECT.W1074 & UTF.To32(To_Hex9(cntCharacter));
	Dmap_TY.Insert(CMap,key,v);
	Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1075 & q & Y2018Text_DSECT.W1076));
	return UTF.To8(v.s);
end DsectCharacter;
	--.............................--
	--  DsectString                --
	--.............................--
function DsectString(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:= Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(Smap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntString:=cntString+1;
	v.s:=Y2018Text_DSECT.W1077 & UTF.To32(To_Hex9(cntString));
	Dmap_TY.Insert(Smap,key,v);
	if q'Last(1) < q'First(1) then
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1078));
	else
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1079 & q & Y2018Text_DSECT.W1080));
	end if;
	return UTF.To8(v.s);
end DsectString;
	--.............................--
	--  DsectWWCharacter           --
	--.............................--
function DsectWWCharacter(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:= Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(WWCmap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntWWCharacter:=cntWWCharacter+1;
	v.s:=Y2018Text_DSECT.W1081 & UTF.To32(To_Hex9(cntWWCharacter));
	Dmap_TY.Insert(WWCmap,key,v);
	Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1082 & To_HexLitC(q) & Y2018Text_DSECT.W1083));
	return UTF.To8(v.s);
end DsectWWCharacter;
	--.............................--
	--  DsectWWString              --
	--.............................--
function DsectWWString(q:Wide_Wide_String) return String is
	-- Note q is only the content not any surronding "-characters
	key: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:= Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(q);
	this:Dmap_TY.cursor;
	v:STR9_TY;
begin
	this:=Dmap_TY.Find(WWSmap,key);
	if Dmap_TY.has_Element(this) then
		v:=Dmap_TY.Element(this);
		return UTF.To8(v.s);
	end if;
	cntWWString:=cntWWString+1;
	v.s:=Y2018Text_DSECT.W1084 & UTF.To32(To_Hex9(cntWWString));
	Dmap_TY.Insert(WWSmap,key,v);
	if q'Last(1) < q'First(1) then
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1085));
	else
		Put_Line(tmpBetaOutFile,UTF.To8(v.s & Y2018Text_DSECT.W1086 & To_HexLit(q) & Y2018Text_DSECT.W1083));
	end if;
	return UTF.To8(v.s);
end DsectWWString;
-- *********** main.adb ************
	--.............................--
	--                             --
	--.............................--
begin
	--QBlock(" ");
	j:=1;
	while j<= Ada.Command_Line.Argument_Count loop
		case j is
			when 1 =>
				source_from:=Ada.Strings.Unbounded.To_Unbounded_String(Ada.Command_Line.Argument(1));
			when 2 =>
				csect_to:=Ada.Strings.Unbounded.To_Unbounded_String(Ada.Command_Line.Argument(2));
				dsect_to:=Ada.Strings.Unbounded.To_Unbounded_String(Ada.Command_Line.Argument(2));
				csect_toFrom:=Ada.Strings.Unbounded.To_Unbounded_String(Ada.Command_Line.Argument(2) & "csect.lst");
				dsect_toFrom:=Ada.Strings.Unbounded.To_Unbounded_String(Ada.Command_Line.Argument(2) & "dsect.lst");
			when others =>
				null;
		end case;
		j:=j+1;
	end loop;
	--cnt:=cnt_Start;
	cntCharacter:=cnt_Start;
	cntString:=cnt_Start;
	cntWWCharacter:=cnt_Start;
	cntWWString:=cnt_Start;
	begin
		Open (File => sourceFile,Mode => In_File,Name => Ada.Strings.Unbounded.To_String(source_from));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not open the file '" & Ada.Strings.Unbounded.To_String(source_from) & "'. Does it exist?");
			Set_Exit_Status (Failure);
			return;
	end;
	begin
		Create (File => tmpBetaOutFile,Mode => Out_File,Name => Ada.Strings.Unbounded.To_String(dsect_toFrom));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not create a file named '" & Ada.Strings.Unbounded.To_String(dsect_toFrom) & "'.");
			Set_Exit_Status (Failure);
			return;
	end;
	begin
		Create (File => tmpAlfaOutFile,Mode => Out_File,Name => Ada.Strings.Unbounded.To_String(csect_toFrom));
	exception
		when others =>
			Put_Line (Standard_Error,"Can not create a file named '" & Ada.Strings.Unbounded.To_String(csect_toFrom) & "'.");
			Set_Exit_Status (Failure);
			return;
	end;
-- *********** stepOne.adb ************
	ps:=Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(
		Y2018Text_DSECT.W1087 & 
		commentLit &  Y2018Text_DSECT.W1088 &
		andLit & Y2018Text_DSECT.W1088 &
		orLit & Y2018Text_DSECT.W1088 &
		xorLit & Y2018Text_DSECT.W1088 &
		eqLit & Y2018Text_DSECT.W1088 &
		neLit & Y2018Text_DSECT.W1088 &
		ltLit & Y2018Text_DSECT.W1088 &
		leLit & Y2018Text_DSECT.W1088 &
		gtLit & Y2018Text_DSECT.W1088 &
		geLit & Y2018Text_DSECT.W1088 &
		plusLit & Y2018Text_DSECT.W1088 &
		minLit & Y2018Text_DSECT.W1088 &
		etLit & Y2018Text_DSECT.W1088 &
		multLit & Y2018Text_DSECT.W1088 &
		divLit & Y2018Text_DSECT.W1088 &
		modLit & Y2018Text_DSECT.W1088 &
		remLit & Y2018Text_DSECT.W1088 &
		expLit & Y2018Text_DSECT.W1088 &
		absLit & Y2018Text_DSECT.W1088 &
		notLit & Y2018Text_DSECT.W1088 &
		apoLit & Y2018Text_DSECT.W1088 &
		wide_wide_stringLit & Y2018Text_DSECT.W1088 & 
		wide_wide_characterLit &  Y2018Text_DSECT.W1088 &
		stringLitS & Y2018Text_DSECT.W1088 &
		stringLit & Y2018Text_DSECT.W1088 &
		--stringLitX & "|"W &
		characterLit & "|" &
		wide_wide_characterLitX & "|" &
		wide_wide_characterLitU & "|" &
		wide_wide_characterLitV & "|" &
		wide_wide_characterLitY &
		
		Y2018Text_DSECT.W1070); 
	ptcLineSimple:=PatternPack.compile(Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(ps),PatternPack.G_UPPERCASE);
	ps:=Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(
		Y2018Text_DSECT.W1089 & 
		andLitE & Y2018Text_DSECT.W1088 &
		orLitE & Y2018Text_DSECT.W1088 &
		xorLitE & Y2018Text_DSECT.W1088 &
		eqLitE & Y2018Text_DSECT.W1088 &
		neLitE & Y2018Text_DSECT.W1088 &
		ltLitE & Y2018Text_DSECT.W1088 &
		leLitE & Y2018Text_DSECT.W1088 &
		gtLitE & Y2018Text_DSECT.W1088 &
		geLitE & Y2018Text_DSECT.W1088 &
		plusLitE & Y2018Text_DSECT.W1088 &
		minLitE & Y2018Text_DSECT.W1088 &
		etLitE & Y2018Text_DSECT.W1088 &
		multLitE & Y2018Text_DSECT.W1088 &
		divLitE & Y2018Text_DSECT.W1088 &
		modLitE & Y2018Text_DSECT.W1088 &
		remLitE & Y2018Text_DSECT.W1088 &
		expLitE & Y2018Text_DSECT.W1088 &
		absLitE & Y2018Text_DSECT.W1088 &
		notLitE &
		Y2018Text_DSECT.W1070);
	ptcEnd:=PatternPack.compile(Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(ps),PatternPack.G_UPPERCASE);

	ptcProcedureName  :=PatternPack.compile(Y2018Text_DSECT.W1090,PatternPack.G_UPPERCASE);
	ptcPackageHeadName:=PatternPack.compile(Y2018Text_DSECT.W1091,PatternPack.G_UPPERCASE);
	ptcPackageBodyName:=PatternPack.compile(Y2018Text_DSECT.W1092,PatternPack.G_UPPERCASE);
	ptcDsect:=Patternpack.compile(Y2018Text_DSECT.W1093,PatternPack.G_UPPERCASE); -- -- with DSECT;
	while not End_Of_File(sourceFile) loop
		declare
			s:Wide_Wide_String:=blankadd(UTF.To32(Get_Line(sourceFile)));
			t: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String;
			t_tail: Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Null_Unbounded_Wide_Wide_String;
		begin
			lineCnt:=lineCnt + 1;
			--if lineCnt mod 10 = 0 then
				PutLineCount(lineCnt);
			--end if;
			if code = CODE_UNDEF then
				declare
					cursorProcedure: PatternPack.G_Cursor:=PatternPack.matches(ptcProcedureName,s);
					cursorBody: PatternPack.G_Cursor:=PatternPack.matches(ptcPackageBodyName,s);
					cursorHead: PatternPack.G_Cursor:=PatternPack.matches(ptcPackageHeadName,s);
				begin
					if PatternPack.has_Element(cursorProcedure) then
						m:=PatternPack.element(cursorProcedure);
						code:=CODE_PROCEDURE;
						name:=name & MatchPack.getMatch(m,2);
						csect_to:=csect_to & Tool.To_LC(UTF.To8(name)) & ":adb";
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(name)) & "_psect:ads";
						name:=name & Y2018Text_DSECT.W1094;
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & " is");
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					elsif PatternPack.has_Element(cursorBody) then
						m:=PatternPack.element(cursorBody);
						code:=CODE_PACKAGEBODY;
						name:=name & MatchPack.getMatch(m,2);
						csect_to:=csect_to & Tool.To_LC(UTF.To8(name)) & ":adb";
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(name)) & "_bsect:ads";
						name:=name & Y2018Text_DSECT.W1095;
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & " is");
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					elsif PatternPack.has_Element(cursorHead) then
						m:=PatternPack.element(cursorHead);
						code:=CODE_PACKAGEHEAD;
						name:=name & MatchPack.getMatch(m,2);	
						csect_to:=csect_to & Tool.To_LC(UTF.To8(name)) & ":ads";
						dsect_to:=dsect_to & Tool.To_LC(UTF.To8(name)) & "_hsect:ads";
						name:=name & Y2018Text_DSECT.W1096;
						Put_line(tmpBetaOutFile,"-- GENERATED CODE --");
						Put_line(tmpBetaOutFile,"package " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & " is");
						if lineCntDSECT = 0 then
							lineCntDSECT:=lineCnt;
						end if;
					else
						null;
					end if;
				end;
			end if;
			if lineCntDSECT = 0 then
				cursorDsect:=PatternPack.matches(ptcDsect,s);
				if PatternPack.has_Element(cursorDsect) then
					lineCntDSECT:=lineCnt;
					dsectOK:=TRUE;
				end if;
			end if;
			cursorEnd:=PatternPack.matches(ptcEnd,s);
			if PatternPack.has_Element(cursorEnd) then
				m:=PatternPack.element(cursorEnd);
				t:=t & MatchPack.getMatch(m,0);
				cursorLine:=PatternPack.matches(ptcLineSimple,PatternPack.source(cursorEnd));
			else
				cursorLine:=PatternPack.matches(ptcLineSimple,s);
			end if;
			tailOK:=FALSE;
			matchOK:=FALSE;
			while PatternPack.has_Element(cursorLine) loop
				matchOK:=TRUE;
				m:=PatternPack.element(cursorLine);
				declare
					q:Wide_Wide_String:=MatchPack.getMatch(m,2);
				begin
					t:=t & MatchPack.getMatch(m,1);
					if q(1) = Y2018Text_DSECT.W1097(1) and q(2) = Y2018Text_DSECT.W1097(1) then
						t:=t & Y2018Text_DSECT.W1010 & PatternPack.source(cursorLine);
						tailOK:=TRUE;
						exit;
					elsif (q(q'Last(1)) = Y2018Text_DSECT.W1098(1) or q(q'Last(1)) = Y2018Text_DSECT.W1099(1)) and q(q'First(1)) = '"' then
						if code = CODE_UNDEF then
							--raise Program_Error with "E38 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4201,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & name & Y2018Text_DSECT.W1100 & Ada.Strings.Unbounded.To_Unbounded_String(DsectWWString(Tool.substr(q,2,q'Last(1)-q'First(1)-2)));
					elsif (q(q'Last(1)) = Y2018Text_DSECT.W1098(1) or q(q'Last(1)) = Y2018Text_DSECT.W1099(1)) and q(q'First(1)) = apo then
						if code = CODE_UNDEF then
							--raise Program_Error with "E38 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4202,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & name & Y2018Text_DSECT.W1100 & Ada.Strings.Unbounded.To_Unbounded_String(DsectWWCharacter(Tool.substr(q,2,q'Last(1)-q'First(1)-2)));
					elsif q(q'Last(1)) = apo then
						if code = CODE_UNDEF then
							--raise Program_Error with "E37 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4204,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & name & Y2018Text_DSECT.W1100 & Ada.Strings.Unbounded.To_Unbounded_String(DsectCharacter(Tool.substr(q,2,q'Last(1)-q'First(1)-1)));
					elsif q(q'Last(1)) = Y2018Text_DSECT.W1071(1) and q(q'First(1)) = '"' then
						if code = CODE_UNDEF then
							--raise Program_Error with "E38 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4205,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & MatchPack.getMatch(m,2);
					elsif q(q'First(1)) = apo then
						if code = CODE_UNDEF then
							--raise Program_Error with "E38 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4206,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & MatchPack.getMatch(m,2);
					elsif (q(q'Last(1)) = Y2018Text_DSECT.W1101(1) or q(q'Last(1)) = Y2018Text_DSECT.W1102(1)) and q(q'First(1)) = '"' then
						t:=t & Tool.substr(q,1,q'Last(1)-q'First(1));
					elsif q(q'Last(1)) = Y2018Text_DSECT.W1103(1)  and q(q'First(1)) = '"' then
						if code = CODE_UNDEF then
							--raise Program_Error with "E37 No code type";
							raise Program_Error with Y2018.Text.Core.Tool.getMsg(4203,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
						end if;
						t:=t & name & Y2018Text_DSECT.W1100 & Ada.Strings.Unbounded.To_Unbounded_String(DsectString(Tool.substr(q,2,q'Last(1)-q'First(1)-1)));
					else
						null;
					end if;
				end; --BEGIN
				--cursorOLD:=cursorLine;
				t_tail:=Ada.Strings.Wide_Wide_Unbounded.To_Unbounded_Wide_Wide_String(PatternPack.source(cursorLine));
				cursorLine:=PatternPack.next(cursorLine);
			end loop; -- while PatternPack.has_Element(cursorLine) loop
			if matchOK then
				if tailOK then
					null;
				else
					--t:=t & PatternPack.source(cursorOLD);
					t:=t & t_tail;
				end if;
			else
				if PatternPack.has_Element(cursorEnd) then
					t:=t & PatternPack.source(cursorEnd);
				else
					t:=t & s;
				end if;
				t:=t & PatternPack.source(cursorLine);
			end if;
			Put_Line(tmpAlfaOutFile,UTF.To8(Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(t)));
		end;
	end loop; -- while not End_Of_File(sourceFile) loop
	Put_line(tmpBetaOutFile,"end " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & ";" );
	Close(tmpAlfaOutFile);
	Close(sourceFile);
	Close(tmpBetaOutFile);
	if Ada.Strings.Wide_Wide_Unbounded.Length(name) = 0 then
		--raise Program_Error with "E0001 No procedure or package statement found"; -- exception; 
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(4207,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E,Integer'Image(lineCnt));
	end if;
-- *********** stepTwo.adb ************
	declare
		fname:String:=Ada.Strings.Unbounded.To_String(csect_to);
	begin
		j:=1;
		while j<=fname'Last(1) loop
			if fname(j) = '.' then
				fname(j) := '-';
			elsif fname(j) = ':' then
				fname(j) := '.'; 
			end if;
			j:=j+1;
		end loop;
		begin
			Open (File => tmpAlfaInFile,Mode => In_File,Name => Ada.Strings.Unbounded.To_String(csect_toFrom));
		exception
			when others =>
				Put_Line (Standard_Error,"Can not open the file '" & Ada.Strings.Unbounded.To_String(source_from) & "'. Does it exist?");
				Set_Exit_Status (Failure);
				return;
		end;
		begin
			Create (File => csectFile,Mode => Out_File,Name => fname);
		exception
			when others =>
				Put_Line (Standard_Error,"Can not create a file named '" & fname & "'.");
				Set_Exit_Status (Failure);
				return;
		end;
		lineCnt:=0;
		while not End_Of_File(tmpAlfaInFile) loop
			declare
				s:Wide_Wide_String:=UTF.To32(Get_Line(tmpAlfaInFile));
			begin
				lineCnt:=lineCnt + 1;
				if dsectOK then
					if lineCntDSECT=lineCnt and (cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start) then
						Put_line(csectFile,"with " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & ";");
					else
						Put_Line(csectFile,UTF.To8(s));
					end if;
				else
					if lineCntDSECT=lineCnt and (cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start) then
						Put_line(csectFile,"with " & Ada.Strings.Unbounded.To_String(UTF.To8(name)) & ";");
					end if;
					Put_Line(csectFile,UTF.To8(s));
				end if;
			end;
		end loop;
		Close(csectFile);
		Close(tmpAlfaInFile);
	end;
	-----------------------
	--                   --
	-----------------------
	if cntCharacter > cnt_Start or cntString > cnt_Start or cntWWCharacter > cnt_Start or cntWWString > cnt_Start then
		declare
			fname:String:=Ada.Strings.Unbounded.To_String(dsect_to);
		begin
			j:=1;
			while j<=fname'Last(1) loop
				if fname(j) = '.' then
					fname(j) := '-';
				elsif fname(j) = ':' then
					fname(j) := '.'; 
				end if;
				j:=j+1;
			end loop;
			
			begin
				Open (File => tmpBetaInFile,Mode => In_File,Name => Ada.Strings.Unbounded.To_String(dsect_toFrom));
			exception
				when others =>
					Put_Line (Standard_Error,"Can not open the file '" & Ada.Strings.Unbounded.To_String(source_from) & "'. Does it exist?");
					Set_Exit_Status (Failure);
					return;
			end;
			begin
				Create (File => dsectFile,Mode => Out_File,Name => fname);
			exception
				when others =>
					Put_Line (Standard_Error,"Can not create a file named '" & fname & "'.");
					Set_Exit_Status (Failure);
					return;
			end;
			lineCnt:=0;
			while not End_Of_File(tmpBetaInFile) loop
				declare
					s:Wide_Wide_String:=UTF.To32(Get_Line(tmpBetaInFile));
				begin
					lineCnt:=lineCnt + 1;
					Put_Line(dsectFile,UTF.To8(s));
				end;
			end loop;
			Close(dsectFile);
			Close(tmpBetaInFile);
		end;
	end if;
-- *********** tail.adb ************
exception
	when End_Error =>
		Close(sourceFile);
		Close(csectFile);
		Close(dsectFile);
		Close(tmpAlfaOutFile);
		Close(tmpAlfaInFile);
		Close(tmpBetaOutFile);
		Close(tmpBetaInFile);
end Y2018Text;
