-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
-- ############################## MatchPack.ads ##############################
with Ada.Strings.Wide_Wide_Unbounded; --use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Jets.MatchPack;
package Y2018.Text.Regex.MatchPack is
	type Match is tagged private;
	type Match_AC is access Match;
	type Unbounded_Wide_Wide_String_AC is access all Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
	type Unbounded_Wide_Wide_String_AA is array (Integer range <>) of Unbounded_Wide_Wide_String_AC;
	function new_Match(jAC:Y2018.Text.Jets.MatchPack.Match_AC;us : Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String) return Match_AC;
	function getMatch(matchValue:Match_AC;mid:Integer) return Wide_Wide_String;
	function getMatch(matchValue:Match_AC) return Unbounded_Wide_Wide_String_AA;
	function hasMatch(matchValue:Match_AC;mid:Integer) return Boolean;
	function count(matchValue:Match_AC) return Integer;
-- ############################## MatchPackMatch.ads ##############################
	private type Match is tagged
	record
		jAC: Y2018.Text.Jets.MatchPack.Match_AC;
		us : Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
	end record;
-- ############################## MatchPackTail.adb ##############################
end Y2018.Text.Regex.MatchPack;
