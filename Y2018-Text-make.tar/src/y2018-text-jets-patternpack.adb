-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## PatternPack.adb ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers.Vectors;
with Y2018.Text.Core; use Y2018.Text.Core; 
with Y2018.Text.Core.GC;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Ada.Containers.Ordered_Maps;
with Ada.Unchecked_Deallocation;
with Y2018.Text.Jets.RangeVectorPack; --use Y2018.Text.Jets.RangeVectorPack;
with Y2018.Text.Jets.RegexTool; use Y2018.Text.Jets.RegexTool;
with Y2018.Text.Jets.MatchPack; --use Y2018.Text.Jets.MatchPack;
with Ada.Task_Identification; use Ada.Task_Identification;
with Ada.Finalization; use Ada.Finalization;
with GNAT.Source_Info;
package body Y2018.Text.Jets.PatternPack is
-- ############################## free.adb ##############################
	procedure RE_ELEM_Free is new Ada.Unchecked_Deallocation(RE_Elem, RE_Elem_AC);
	procedure RE_ELEM_FreeNode(y:in out RE_Elem_AC) is
	begin
		if y.right /=null then
			y.right.left:=null;
		end if;
		if y.left /=null then
			y.left.right:=null;
		end if;
		case y.V is
			when REQ_BEGIN =>
				if y.begin_up /= null then
					case y.begin_up.V is
						when REQ_UPDOWN =>
							y.begin_up.updown_down:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3001) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.begin_up.V);
					end case;
				end if;
				if y.begin_down /=null then
					case y.begin_down.V is
						when REQ_UPDOWN =>
							y.begin_down.updown_up:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3002) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.begin_down.V); 
					end case;
				end if;
			when REQ_PALCAP => -- ( )
				if y.palcap_up /= null then
					case y.palcap_up.V is
						when REQ_UPDOWN =>
							y.palcap_up.updown_down:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3003) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.palcap_up.V); 
					end case;
				end if;
				if y.palcap_down /=null then
					case y.palcap_down.V is
						when REQ_UPDOWN =>
							y.palcap_down.updown_up:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3004) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.palcap_down.V); 
					end case;
				end if;
			when REQ_PAL => -- (?: )
				if y.pal_up /= null then
					case y.pal_up.V is
						when REQ_UPDOWN =>
							y.pal_up.updown_down:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3005) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.pal_up.V);
					end case;
				end if;
				if y.pal_down /=null then
					case y.pal_down.V is
						when REQ_UPDOWN =>
							y.pal_down.updown_up:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3006) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.pal_down.V); 
					end case;
				end if;
			when REQ_UPDOWN =>
				if y.updown_up /= null then
					case y.updown_up.V is
						when REQ_UPDOWN =>
							y.updown_up.updown_down:=null;
						when REQ_BEGIN =>
							y.updown_up.begin_down:=null;
						when REQ_PALCAP =>
							y.updown_up.palcap_down:=null;
						when REQ_PAL =>
							y.updown_up.pal_down:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3007) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.updown_up.V); 
					end case;
				end if;
				if y.updown_down /=null then
					case y.updown_down.V is
						when REQ_UPDOWN =>
							y.updown_down.updown_up:=null;
						when REQ_BEGIN =>
							y.updown_down.begin_up:=null;
						when REQ_PALCAP =>
							y.updown_down.palcap_up:=null;
						when REQ_PAL =>
							y.updown_down.pal_up:=null;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3008) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Node % link" & ":" & REQ_TY'Image(y.V) & ":" & REQ_TY'Image(y.updown_down.V); 
					end case;
				end if;
			when others => null;
		end case;
		RE_ELEM_Free(y);
	end RE_ELEM_FreeNode;
	
-- ############################## compileHead.adb ##############################

function compileM(s : Wide_Wide_String) return Pattern_AC is
	type ST_TY is (ST_A, ST_B, ST_C, ST_D, ST_E, ST_F, ST_G, ST_H, ST_I, ST_J,
					ST_K, ST_L, ST_M, ST_N, ST_O, ST_P,
					ST_Q,
					ST_R,
					--ST_S, 
					ST_T, ST_U, ST_V, ST_W, ST_X, ST_Y, ST_Z);
-- ############################## compile.adb ##############################
	--
	package STACK_TY is new Ada.Containers.Vectors(Natural,RE_Elem_AC);
	package RVSET_TY is new Ada.Containers.Ordered_Sets(
		Element_Type=> RangeVectorPack.RangeVector,
		"<"=> RangeVectorPack.less,
		"="=> RangeVectorPack.equal);
	actual : RE_Elem_AC;
	posActual : RE_Elem_AC;
	negActual : RE_Elem_AC;
	tmp : RE_Elem_AC;
	p1 : RE_Elem_AC;
	p2 : RE_Elem_AC;
	top : RE_Elem_AC;
	stack : STACK_TY.Vector;
	state : ST_TY := ST_A;
	J : Integer:=1;
	JDELTA : Integer:=1;
	capture_string: Unbounded_Wide_Wide_String;
	capture_string2: Unbounded_Wide_Wide_String;
	capture_integer: Integer;
	capture_integer2: Integer;
	pv:Boolean:=true;
	cv:Boolean:=true;
	id: RE_ID:=FIRST_RE_ID;
	mid: MatchID:=0;
	pnoCnt:Integer:=0; -- number of "|" (or's)
	rootBegin: RE_Elem_AC;
	emptyStk:RE_ARR(1 .. 0);
	rvset: RVSET_TY.Set;
	rvsetCursor: RVSET_TY.Cursor;
	rvCandidate:RangeVectorPack.RangeVector;
 
	gc_L: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#4C#)); --L
	gc_M: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#4D#)); --M
	gc_N: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#4E#)); --N
	gc_P: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#50#)); --P
	gc_S: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#53#)); --S
	gc_Z: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#5A#)); --Z
	gc_C: constant Wide_Wide_String:=(1=> Wide_Wide_Character'Val(16#43#)); --C
	gc_Lu: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4C#),Wide_Wide_Character'Val(16#75#)); --Lu
	gc_Ll: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4C#),Wide_Wide_Character'Val(16#6C#)); --Ll
	gc_Lt: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4C#),Wide_Wide_Character'Val(16#74#)); --Lt
	gc_Lm: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4C#),Wide_Wide_Character'Val(16#6D#)); --Lm
	gc_Lo: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4C#),Wide_Wide_Character'Val(16#6F#)); --Lo
	gc_Mn: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4D#),Wide_Wide_Character'Val(16#6E#)); --Mn
	gc_Mc: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4D#),Wide_Wide_Character'Val(16#63#)); --Mc
	gc_Me: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4D#),Wide_Wide_Character'Val(16#65#)); --Me
	gc_Nd: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4E#),Wide_Wide_Character'Val(16#64#)); --Nd
	gc_Nl: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4E#),Wide_Wide_Character'Val(16#6C#)); --Nl
	gc_No: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#4E#),Wide_Wide_Character'Val(16#6F#)); --No
	gc_Pc: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#63#)); --Pc
	gc_Pd: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#64#)); --Pd
	gc_Ps: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#73#)); --Ps
	gc_Pe: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#65#)); --Pe
	gc_Pi: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#69#)); --Pi
	gc_Pf: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#66#)); --Pf
	gc_Po: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#50#),Wide_Wide_Character'Val(16#6F#)); --Po
	gc_Sm: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#53#),Wide_Wide_Character'Val(16#6D#)); --Sm
	gc_Sc: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#53#),Wide_Wide_Character'Val(16#63#)); --Sc
	gc_Sk: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#53#),Wide_Wide_Character'Val(16#6B#)); --Sk
	gc_So: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#53#),Wide_Wide_Character'Val(16#6F#)); --So
	gc_Zs: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#5A#),Wide_Wide_Character'Val(16#73#)); --Zs
	gc_Zl: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#5A#),Wide_Wide_Character'Val(16#6C#)); --Zl
	gc_Zp: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#5A#),Wide_Wide_Character'Val(16#70#)); --Zp
	gc_Cc: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#43#),Wide_Wide_Character'Val(16#63#)); --Cc
	gc_Cf: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#43#),Wide_Wide_Character'Val(16#66#)); --Cf
	gc_Cs: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#43#),Wide_Wide_Character'Val(16#73#)); --Cs
	gc_Co: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#43#),Wide_Wide_Character'Val(16#6F#)); --Co
	gc_Cn: constant Wide_Wide_String:=(Wide_Wide_Character'Val(16#43#),Wide_Wide_Character'Val(16#6E#)); --Cn
	
	ptc: Pattern_AC;
	map:MatchPack.MatchID2RE_ID_TY.Map;
begin
-- ############################## compileState.adb ##############################
	while state /= ST_P loop
		case state is -- STATE AUTOMATE
			when ST_A => -- start
				if J > s'Last(1) then state:=ST_P;
				else
					actual:=CREATE_RE(id,REQ_BEGIN);
					--pool.root:=actual;
					rootBegin:=actual;
					rootBegin.begin_trackcount:=0;
					STACK_TY.Append(stack,actual);
					top:=actual;
					actual:=CREATE_RE(id,REQ_UPDOWN);
					top.begin_down:=actual;
					actual.updown_up:=top;
					
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MleftSquare => state:= ST_E;
						when Mcircumflex => state:= ST_I;
						when Mdollar => state:= ST_J;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3101) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
					-- ==============================
					if state /= ST_I then
						actual:=CREATE_RE(id,REQ_PERIOD,actual);
						actual.period_min:=0;
						actual.period_max:=Integer'Last;
						actual.period_greedy:=FALSE;
						actual:=CREATE_RE(id,REQ_PALCAP,actual);
						actual.palcap_min:=1;
						actual.palcap_max:=1;
						actual.palcap_greedy:=TRUE;
						actual.palcap_trackcount:=rootBegin.begin_trackcount;
						rootBegin.begin_trackcount:=rootBegin.begin_trackcount + 1;
						actual.palcap_begin:=rootBegin;
						top:=actual;
						actual:=CREATE_RE(id,REQ_UPDOWN);
						top.palcap_down:=actual;
						actual.updown_up:=top;
					end if;
					-- ==============================
				end if;
			when ST_B => -- | 
				actual:=STACK_TY.Last_Element(stack);
				tmp:=CREATE_RE(id,REQ_UPDOWN);
				pnoCnt:=pnoCnt + 1; -- counting number of "|" (or's)
				while actual/=null loop
					case actual.V is
						when REQ_BEGIN =>
							if actual.begin_down = null then
								tmp.updown_up:=actual;
								actual.begin_down:=tmp;
								exit;
							else
								actual:=actual.begin_down;
							end if;
						when REQ_PAL =>
							if actual.pal_down = null then
								tmp.updown_up:=actual;
								actual.pal_down:=tmp;
								exit;
							else
								actual:=actual.pal_down;
							end if;
						when REQ_PALCAP =>
							if actual.palcap_down = null then
								tmp.updown_up:=actual;
								actual.palcap_down:=tmp;
								exit;
							else
								actual:=actual.palcap_down;
							end if;
						when REQ_UPDOWN =>
							if actual.updown_down = null then
								tmp.updown_up:=actual;
								actual.updown_down:=tmp;
								exit;
							else
								actual:=actual.updown_down;
							end if;
						when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3105) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
					end case;
				end loop;
				actual:=tmp;

				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when Mdollar => state:=ST_J;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3102) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_C => -- (
				JDELTA:=1;
				if J + 2 <s'Last(1) then
					if s(J+1) = Mquestion and s(J+2) = Wide_Wide_Character'Val(16#3A#) then -- ":"W
						actual:=CREATE_RE(id,REQ_PAL,actual);
						actual.pal_min:=1;
						actual.pal_max:=1;
						actual.pal_greedy:=TRUE;
						JDELTA:=3;
					else
						actual:=CREATE_RE(id,REQ_PALCAP,actual);
						actual.palcap_min:=1;
						actual.palcap_max:=1;
						actual.palcap_greedy:=TRUE;
						actual.palcap_trackcount:=rootBegin.begin_trackcount;
						rootBegin.begin_trackcount:=rootBegin.begin_trackcount + 1;
						actual.palcap_begin:=rootBegin;
					end if;
				else
					actual:=CREATE_RE(id,REQ_PALCAP,actual);
					actual.palcap_min:=1;
					actual.palcap_max:=1;
					actual.palcap_greedy:=TRUE;
					actual.palcap_trackcount:=rootBegin.begin_trackcount;
					rootBegin.begin_trackcount:=rootBegin.begin_trackcount + 1;
					actual.palcap_begin:=rootBegin;
				end if;
				STACK_TY.Append(stack,actual);
				top:=actual;
				actual:=CREATE_RE(id,REQ_UPDOWN);
				if top.V = REQ_PAL then
					top.pal_down:=actual;
				else
					top.palcap_down:=actual;
				end if;
				actual.updown_up:=top;

				J:=J + JDELTA;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3103) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				else
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MleftSquare => state:= ST_E;
						when Mdollar => state:= ST_J;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3104) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1));
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_D => -- )
				actual:=STACK_TY.Last_Element(stack);
				STACK_TY.Delete_Last(stack);
				
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MrightPal => state:= ST_D;
						when MleftSquare => state:= ST_E;
						when MleftCurly => state:= ST_G;
						when Mdollar => state:= ST_J;
						when Masterix => state:= ST_K;
						when Mplus => state:= ST_L;
						when Mquestion => state:= ST_M;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3106) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_E => -- [
				actual:=CREATE_RE(id,REQ_CLASS_ELEM,actual);
				actual.class_elem_min:=1;
				actual.class_elem_max:=1;
				actual.class_elem_greedy:=TRUE;
				STACK_TY.Append(stack,actual);
				top:=actual;
				
				J:=J + 1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3107) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
				negActual :=CREATE_RE(id,REQ_NEG);
				top.class_elem_neg:=negActual;
				negActual.neg_up:=top;
				posActual :=CREATE_RE(id,REQ_POS);
				posActual.pos_up:=top;
				top.class_elem_pos:=posActual;
				if s(J) = Mcircumflex then
					cv:=false;
					J:=J + 1;
					if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3108) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
					end if;
				else
					cv:=true;
				end if;

				case s(J) is
					when backSlash => state:=ST_Q;
					when others =>
						if isInMCHAR(s(J))
						then
raise Program_Error with E_TY'Image(Y2018.Text.E3109) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
						else state:=ST_W;
						end if;
				end case;
			when ST_F => -- ]
				actual:=STACK_TY.Last_Element(stack);
				STACK_TY.Delete_Last(stack);
				if actual.V = REQ_CLASS_ELEM then
					null;
				else
raise Program_Error with E_TY'Image(Y2018.Text.E3110) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when MleftCurly => state:=ST_G;
						when Mdollar => state:=ST_J;
						when Masterix => state:=ST_K;
						when Mplus => state:=ST_L;
						when Mquestion => state:=ST_M;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
								declare 
									qss2:Wide_Wide_String(1..1):=(1=>s(J));
								begin 
raise Program_Error with E_TY'Image(Y2018.Text.E3111) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & UTF.to8(qss2); 
								end;
							else
								state:=ST_O;
							end if;
					end case;
				end if;
			when ST_G => -- {
				capture_string:=Null_Unbounded_Wide_Wide_String;  -- low value 
				capture_string2:=Null_Unbounded_Wide_Wide_String; -- high value
				J:=J+1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3112) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				if s(J) in Wide_Wide_Character'Val(16#30#) .. Wide_Wide_Character'Val(16#39#) then
					state:=ST_Y;
				elsif s(J) = Wide_Wide_Character'Val(16#3A#) then
					J:=J+1;
					if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3113) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
					end if;
					state:=ST_Z;
				else
raise Program_Error with E_TY'Image(Y2018.Text.E3114) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
			when ST_H => -- }
				if Length(capture_string)=0 and Length(capture_string2)=0 then
					capture_integer:=1;
					capture_integer2:=1;
				elsif Length(capture_string)>0 and Length(capture_string2)=0 then
					capture_integer:=Integer'Value(UTF.To8(To_Wide_Wide_String(capture_string)));
					capture_integer2:=capture_integer;
				elsif Length(capture_string)=0 and Length(capture_string2)>0 then
					capture_integer:=0;
					capture_integer2:=Integer'Value(UTF.To8(To_Wide_Wide_String(capture_string2)));
				else
					capture_integer:=Integer'Value(UTF.To8(To_Wide_Wide_String(capture_string)));
					capture_integer2:=Integer'Value(UTF.To8(To_Wide_Wide_String(capture_string2)));
				end if;
				case actual.V is
					when REQ_CHAR =>
						actual.char_min:=capture_integer;
						actual.char_max:=capture_integer2;
					when REQ_PERIOD =>
						actual.period_min:=capture_integer;
						actual.period_max:=capture_integer2;
					when REQ_CLASS_ELEM =>
						actual.class_elem_min:=capture_integer;
						actual.class_elem_max:=capture_integer2;
					when REQ_PALCAP =>
						actual.palcap_min:=capture_integer;
						actual.palcap_max:=capture_integer2;
					when REQ_PAL =>
						actual.pal_min:=capture_integer;
						actual.pal_max:=capture_integer2;
					when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3115) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end case;
				J:=J+1;
				if J > s'Last(1) then
					state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when Mdollar => state:=ST_J;
						when Masterix => state:=ST_K;
						when Mplus => state:=ST_L;
						when Mquestion => state:=ST_M;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3116) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_I => -- ^
				J:=J+1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3117) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				else
					top.begin_circumflex:=TRUE; -- can be used because of ST_A
					actual:=CREATE_RE(id,REQ_PALCAP,actual);
					actual.palcap_min:=1;
					actual.palcap_max:=1;
					actual.palcap_greedy:=TRUE;
					actual.palcap_trackcount:=rootBegin.begin_trackcount;
					rootBegin.begin_trackcount:=rootBegin.begin_trackcount + 1;
					actual.palcap_begin:=rootBegin;
					top:=actual;
					actual:=CREATE_RE(id,REQ_UPDOWN);
					top.palcap_down:=actual;
					actual.updown_up:=top;
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MleftSquare => state:= ST_E;
						when Mdollar => state:= ST_J;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3118) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_J => -- $
				actual:=STACK_TY.Last_Element(stack);
				actual.begin_dollar:=TRUE;
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
raise Program_Error with E_TY'Image(Y2018.Text.E3119) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
			when ST_K => -- *
				case actual.V is
					when REQ_CHAR => actual.char_min:=0; actual.char_max:=Integer'Last;
					when REQ_PERIOD => actual.period_min:=0; actual.period_max:=Integer'Last;
					when REQ_CLASS_ELEM => actual.class_elem_min:=0; actual.class_elem_max:=Integer'Last;
					when REQ_PALCAP => actual.palcap_min:=0; actual.palcap_max:=Integer'Last;
					when REQ_PAL => actual.pal_min:=0; actual.pal_max:=Integer'Last;
					when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3120) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end case;
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when Mdollar => state:=ST_J;
						when Mquestion => state:=ST_M;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3121) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_L => -- +
				case actual.V is
					when REQ_CHAR => actual.char_min:=1; actual.char_max:=Integer'Last;
					when REQ_PERIOD => actual.period_min:=1; actual.period_max:=Integer'Last;
					when REQ_CLASS_ELEM => actual.class_elem_min:=1; actual.class_elem_max:=Integer'Last;
					when REQ_PALCAP => actual.palcap_min:=1; actual.palcap_max:=Integer'Last;
					when REQ_PAL => actual.pal_min:=1; actual.pal_max:=Integer'Last;
					when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3122) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end case;
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when Mdollar => state:=ST_J;
						when Mquestion => state:=ST_M;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3123) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_M => -- ?
				case actual.V is
					when REQ_CHAR =>
						if actual.char_min=1 and actual.char_max=1 then
							actual.char_min:=0;
							actual.char_greedy:=FALSE;
						elsif actual.char_min /= actual.char_max then
							actual.char_greedy:=FALSE;
						end if;
					when REQ_PERIOD =>
						if actual.period_min=1 and actual.period_max=1 then
							actual.period_min:=0;
							actual.period_greedy:=FALSE;
						elsif actual.period_min /= actual.period_max then
							actual.period_greedy:=FALSE;
						end if;
					when REQ_CLASS_ELEM =>
						if actual.class_elem_min=1 and actual.class_elem_max=1 then
							actual.class_elem_min:=0;
							actual.class_elem_greedy:=FALSE;
						elsif actual.class_elem_min /= actual.class_elem_max then
							actual.class_elem_greedy:=FALSE;
						end if;
					when REQ_PALCAP =>
						if actual.palcap_min=1 and actual.palcap_max=1 then
							actual.palcap_min:=0;
							actual.palcap_greedy:=FALSE;
						elsif actual.palcap_min /= actual.palcap_max then
							actual.palcap_greedy:=FALSE;
						end if;
					when REQ_PAL =>
						if actual.pal_min=1 and actual.pal_max=1 then
							actual.pal_min:=0;
							actual.pal_greedy:=FALSE;
						elsif actual.pal_min /= actual.pal_max then
							actual.pal_greedy:=FALSE;
						end if;
					when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3124) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end case;
				J:=J+1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:=ST_B;
						when MleftPal => state:=ST_C;
						when MrightPal => state:=ST_D;
						when MleftSquare => state:=ST_E;
						when Mdollar => state:=ST_J;
						when Mperiod => state:=ST_N;
						when others => 
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3125) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_N => -- .
				actual:=CREATE_RE(id,REQ_PERIOD,actual);
				actual.period_min:=1;
				actual.period_max:=1;
				actual.period_greedy:=TRUE;
				J:=J + 1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MrightPal => state:= ST_D;
						when MleftSquare => state:= ST_E;
						when MleftCurly => state:= ST_G;
						when Mdollar => state:= ST_J;
						when Masterix => state:= ST_K;
						when Mplus => state:= ST_L;
						when Mquestion => state:= ST_M;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3126) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_O => -- other
				if s(J) = backSlash then
					if J + 1 > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3150) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
					else
						case s(J + 1) is
							when MvertLine => null;
							when MleftPal => null;
							when MrightPal => null;
							when MleftSquare => null;
							when MrightSquare => null;
							when MleftCurly => null;
							when MrightCurly => null;
							when Mcircumflex => null;
							when Mdollar => null;
							when Masterix => null;
							when Mplus => null;
							when Mquestion => null;
							when Mperiod => null;
							when backSlash => null;
							when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3151) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % back-slash must be doubbled, index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
						end case;
						J := J + 1;
					end if;
				end if;
				actual:=CREATE_RE(id,REQ_CHAR,actual);
				actual.char_min:=1;
				actual.char_max:=1;
				actual.char_greedy:=TRUE;
				actual.char_value:=s(J);
				J:=J + 1;
				if J > s'Last(1) then state:=ST_P;
				else
					case s(J) is
						when MvertLine => state:= ST_B;
						when MleftPal => state:= ST_C;
						when MrightPal => state:= ST_D;
						when MleftSquare => state:= ST_E;
						when MleftCurly => state:= ST_G;
						when Mdollar => state:= ST_J;
						when Masterix => state:= ST_K;
						when Mplus => state:= ST_L;
						when Mquestion => state:= ST_M;
						when Mperiod => state:= ST_N;
						when others =>
							if isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3127) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_O;
							end if;
					end case;
				end if;
			when ST_P => null; -- "LAST"
			when ST_Q => -- \
				if J + 1 > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3148) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
				J:=J + 1;
				case s(J) is
					when Mlc_d => state:= ST_V; -- d
					when Muc_d => state:= ST_V; -- D
					when Mlc_s => state:= ST_V; -- s
					when Muc_s => state:= ST_V; -- S
					when Mlc_w => state:= ST_V; -- w
					when Muc_w => state:= ST_V; -- W
					when Mlc_p => state:= ST_U; -- p
					when Muc_p => state:= ST_U; -- P
					when backSlash => state:= ST_W; -- 
					when MvertLine => state:= ST_W; -- 
					when MleftPal => state:= ST_W; -- 
					when MrightPal => state:= ST_W; -- 
					when MleftSquare => state:= ST_W; -- 
					when MrightSquare => state:= ST_W; -- 
					when MleftCurly => state:= ST_W; -- 
					when MrightCurly => state:= ST_W; -- 
					when Mcircumflex => state:= ST_W; -- 
					when Mdollar => state:= ST_W; -- 
					when Masterix => state:= ST_W; -- 
					when Mplus => state:= ST_W; -- 
					when Mquestion => state:= ST_W; -- 
					when Mperiod => state:= ST_W; -- 
					when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3149) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end case;
			when ST_R => 
				JDELTA:=J + 2;
				if JDELTA > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3154) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				if s(JDELTA) = backSlash then
					JDELTA:=J + 3;
					if JDELTA > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3155) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
					end if;
					case s(JDELTA) is
						when backSlash => null; 
						when MvertLine => null; 
						when MleftPal => null; 
						when MrightPal => null; 
						when MleftSquare => null; 
						when MrightSquare => null; 
						when MleftCurly => null; 
						when MrightCurly => null; 
						when Mcircumflex => null; 
						when Mdollar => null; 
						when Masterix => null; 
						when Mplus => null; 
						when Mquestion => null; 
						when Mperiod => null; 
						when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3156) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
					end case;
				end if;
				if s(J) > s(JDELTA) then
raise Program_Error with E_TY'Image(Y2018.Text.E3157) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
				if cv then
					posActual:=CREATE_RE(id,REQ_CLASS_RANGE,posActual);
					posActual.class_range_first:=s(J);
					posActual.class_range_last:=s(JDELTA);
				else
					negActual:=CREATE_RE(id,REQ_CLASS_RANGE,negActual);
					negActual.class_range_first:=s(J);
					negActual.class_range_last:=s(JDELTA);
				end if;
				J:=JDELTA + 1;
				case s(J) is
					when backSlash =>
						state:=ST_Q;
					when MrightSquare => state:=ST_F;
					when others =>
						if isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3158) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
						else
							state:=ST_W;
						end if;
				end case;
			--when ST_S => -- -L
			when ST_T => -- [}
				declare
					CAPSTR:Wide_Wide_String:=To_Wide_Wide_String(capture_string);
				begin
					if CAPSTR'Length = 0 then 
raise Program_Error with E_TY'Image(Y2018.Text.E3128) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
					elsif CAPSTR'Length = 1 then
						if pv then
							posActual:=CREATE_RE(id,REQ_CLASS_GCU,posActual);
							posActual.class_gcu_value:=CAPSTR(1);
							posActual.class_gcu_negative:=false;
						else
							negActual:=CREATE_RE(id,REQ_CLASS_GCU,negActual);
							negActual.class_gcu_value:=CAPSTR(1);
							negActual.class_gcu_negative:=true;
						end if;
					elsif CAPSTR'Length = 2 then
						if pv then
							posActual:=CREATE_RE(id,REQ_CLASS_GC,posActual);
							posActual.class_gc_value:=CAPSTR;
							posActual.class_gc_negative:=false;
						else
							negActual:=CREATE_RE(id,REQ_CLASS_GC,negActual);
							negActual.class_gc_value:=CAPSTR;
							negActual.class_gc_negative:=true;
						end if;
					end if;
				end;
				J:=J + 1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3131) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				else
					case s(J) is
						when backSlash => state:= ST_Q;
						when MrightSquare => state:=ST_F;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3132) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_W;
							end if;
					end case;
				end if;
			when ST_U => -- [P{
				if s(J) = Mlc_p then
					pv:=true;
				else
					pv:=false;
				end if;
				capture_string:=Null_Unbounded_Wide_Wide_String;
				J:= J + 2;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3133) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				elsif s(J-1) /= MleftCurly then
raise Program_Error with E_TY'Image(Y2018.Text.E3134) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				elsif isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3135) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
				else
					state:=ST_X;
				end if;
			when ST_V => -- [DSW
				if s(J) = Mlc_d or 
					s(J) = Mlc_s or 
					s(J) = Mlc_w then
					posActual:=CREATE_RE(id,REQ_CLASS_OTHER,posActual);
					posActual.class_other_value:=s(J);
				else
					negActual:=CREATE_RE(id,REQ_CLASS_OTHER,negActual);
					negActual.class_other_value:=s(J);
				end if;
				
				J:=J + 1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3136) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				else
					case s(J) is
						when backSlash => state:=ST_Q;
						when MrightSquare => state:=ST_F;
						when others =>
							if isInMCHAR(s(J))
							then
raise Program_Error with E_TY'Image(Y2018.Text.E3137) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
							else state:=ST_W;
							end if;
					end case;
				end if;
			when ST_W => -- [other2
				if J + 2 <= s'Last(1) then
					if s(J + 1) =Wide_Wide_Character'Val(16#2D#) then
						state:=ST_R;
					end if;
				end if;
				if state = ST_W then
					if cv then 
						posActual:=CREATE_RE(id,REQ_CLASS_CHAR,posActual);
						posActual.class_char_value:=s(J);
					else
						negActual:=CREATE_RE(id,REQ_CLASS_CHAR,negActual);
						negActual.class_char_value:=s(J);
					end if;
					J:=J + 1;
					if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3138) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
					else
						case s(J) is
							when backSlash =>
								state:=ST_Q;
							when MrightSquare => state:=ST_F;
							when others =>
								if isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3139) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % .Backslash or ']' expected. index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
								else
									state:=ST_W;
								end if;
						end case;
					end if;
				end if;
			when ST_X => -- [other3
				Append(capture_string,s(J));
				J:=J+1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3140) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				if s(J) = MrightCurly then
					state:=ST_T;
				elsif isInMCHAR(s(J)) then
raise Program_Error with E_TY'Image(Y2018.Text.E3141) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J) & ":" & Y2018.Text.Core.UTF.To8(Y2018.Text.Core.Tool.Substr(s,J,1)); 
				else
					state:=ST_X;
				end if;
			when ST_Y => --{99 
				Append(capture_string,s(J));
				J:=J+1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3142) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				if s(J) in Wide_Wide_Character'Val(16#30#) .. Wide_Wide_Character'Val(16#39#) then
					state:=ST_Y;
				elsif s(J) = Wide_Wide_Character'Val(16#3A#) then
					J:=J+1;
					if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3143) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
					end if;
					state:=ST_Z;
				elsif s(J) = MrightCurly then
					state:=ST_H;
				else
raise Program_Error with E_TY'Image(Y2018.Text.E3144) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
			when ST_Z => --:99} 
				Append(capture_string2,s(J));
				J:=J+1;
				if J > s'Last(1) then
raise Program_Error with E_TY'Image(Y2018.Text.E3145) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J); 
				end if;
				if s(J) in Wide_Wide_Character'Val(16#30#) .. Wide_Wide_Character'Val(16#39#) then
					state:=ST_Z;
				elsif s(J) = MrightCurly then
					state:=ST_H;
				else
raise Program_Error with E_TY'Image(Y2018.Text.E3146) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " syntax at state % index" & ":" & ST_TY'Image(state) & ":" & Integer'Image(J);
				end if;
		end case; -- STATE AUTOMATE
	end loop;

	ptc:=new Pattern;
	ptc.map:=map;
	JDELTA:=Integer(STACK_TY.Length(stack));
	if JDELTA = 1 then
		ptc.top:=STACK_TY.Last_Element(stack);
		ptc.state:=PST_NONE;
		ptc.current:=0;
		MatchPack.MatchID2RE_ID_TY.Clear(ptc.map);
		ptc.pool.root:=rootBegin;
		
		STACK_TY.Delete_Last(stack);
	elsif JDELTA > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E3152) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Too few palenteses or brackets";
	else
raise Program_Error with E_TY'Image(Y2018.Text.E3153) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Too many palenteses or brackets";
	end if;
-- ############################## compileZwei.adb ##############################
	actual:=ptc.top;
	while actual /= null loop
 		case actual.V is
			when REQ_BEGIN =>
				MatchPack.MatchID2RE_ID_TY.Insert(ptc.map,mid,actual.id);
				if actual.right /= null then
					STACK_TY.Append(stack,actual.right);
				end if;
				actual:=actual.begin_down;
				mid:=mid + 1;
			when REQ_PALCAP =>
				MatchPack.MatchID2RE_ID_TY.Insert(ptc.map,mid,actual.id);
				if actual.right /= null then
					STACK_TY.Append(stack,actual.right);
				end if;
				actual:=actual.palcap_down;
				mid:=mid + 1;
			when REQ_PAL =>
				if actual.right /=null then
					STACK_TY.Append(stack,actual.right);
				end if;
				actual:=actual.pal_down;
			when REQ_UPDOWN =>
				if actual.right /=null then
					STACK_TY.Append(stack,actual.right);
				end if;
				actual:=actual.updown_down;
			when REQ_CLASS_ELEM => -- pos & neg chains
				top:=CREATE_RE(id,REQ_CLASS);
				top.class_min :=actual.class_elem_min;
				top.class_max :=actual.class_elem_max;
				top.class_greedy :=actual.class_elem_greedy;

				rvCandidate:=New_RangeVector(actual.class_elem_pos); --<<POS
				if RVSET_TY.Is_Empty(rvset) then
					top.class_pos:=rvCandidate;
					RVSET_TY.Insert(rvset,rvCandidate);
				else
					rvsetCursor:=RVSET_TY.Find(rvset,rvCandidate);
					if RVSET_TY.Has_Element(rvsetCursor) then
						top.class_pos:=RVSET_TY.Element(rvsetCursor);
					else
						top.class_pos:=rvCandidate;
						RVSET_TY.Insert(rvset,rvCandidate);
					end if;
				end if;

				rvCandidate:=New_RangeVector(actual.class_elem_neg); --<<NEG
				if RVSET_TY.Is_Empty(rvset) then
					top.class_neg:=rvCandidate;
					RVSET_TY.Insert(rvset,rvCandidate);
				else
					rvsetCursor:=RVSET_TY.Find(rvset,rvCandidate);
					if RVSET_TY.Has_Element(rvsetCursor) then
						top.class_neg:=RVSET_TY.Element(rvsetCursor);
					else
						top.class_neg:=rvCandidate;
						RVSET_TY.Insert(rvset,rvCandidate);
					end if;
				end if;
				
				top.left:=actual.left;
				top.right:=actual.right;
				if top.left /=null then
					top.left.right:=top;
				end if;
				if top.right /= null then
					top.right.left:=top;
				end if;
				tmp:=actual;
				actual:=top; -- TOP inserted in the binary three. TMP is garbage
				p1:=tmp.class_elem_pos;
				while p1/=null loop
					p2:=p1.right;
					RE_ELEM_FreeNode(p1);
					p1:=p2;
				end loop;
				tmp.class_elem_pos:=null;
				p1:=tmp.class_elem_neg;
				while p1/=null loop
					p2:=p1.right;
					RE_ELEM_FreeNode(p1);
					p1:=p2;
				end loop;
				tmp.class_elem_neg:=null;
				tmp.left:=null;
				tmp.right:=null;
				RE_ELEM_FreeNode(tmp);
				actual:=actual.right;
			when others =>
				actual:=actual.right;
		end case;
		if actual = null then
			if Integer(STACK_TY.Length(stack)) > 0 then
				actual:=STACK_TY.Last_Element(stack);
				STACK_TY.Delete_Last(stack);
			end if;
		end if;
	end loop;--	while actual /= null loop
-- ############################## compileTail.adb ##############################
	return ptc;
end compileM;
-- ############################## matches.adb ##############################
function matches(ptc:Pattern_AC;startPos:Integer;nextPos:out Integer;s : Wide_Wide_String;m: out MatchPack.Match_TY) return Boolean is
	currRE:RE_Elem_AC:=ptc.top; -- 
	mP:MatchPack.Match_TY;
	pia: I_A;
	qia: I_A:=(1,0);
	r:Boolean:=FALSE;
	LCI:constant Integer:=s'Last(1);
	GDOLLAR:constant Boolean:=ptc.top.begin_dollar;
	depth:constant Integer:=0;
	endy:RE_Elem_AC:=null;

	function matchesPal(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY;
	function matchesPalSub(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY;

	function matchesLeftRight(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;leftRight:out RE_Elem_AC;trackcount:Integer;depth:Integer) return TRINITY;
	function matchesElem(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;depth:Integer) return TRINITY;
	function matchesOne(currRE:RE_Elem_AC;in_ia:I_A) return TRINITY;
	function matchesNext(currRE:RE_Elem_AC;in_ia:I_A) return BOOLEAN;
	function navLeftDownRight(currRE:RE_Elem_AC) return RE_Elem_AC;
	function navLeftTopRight(currRE:RE_Elem_AC) return RE_Elem_AC;
	function navSec(currRE:RE_Elem_AC;down:Boolean) return RE_Elem_AC;
	function isEnd(currRE:RE_Elem_AC;basecall:Boolean) return Boolean;
	--function deepClone(currRE:RE_Elem_AC) return RE_Elem_AC;
	function internalMatch(this:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY;
	function daisy(this:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY;
	--[OPTIMIZE]--
	o_matchesNext_currRE:RE_Elem_AC;
	o_matchesNext_in_ia:I_A;
	o_matchesNext_return:BOOLEAN;
	
-- ############################## matchesPalSub.adb ##############################
		--=====================--
		-- ** MATCHESPALSUB ** --
		--=====================--
	function matchesPalSub(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY is
		that:RE_Elem_AC;
		matched_ia:I_A:=(in_ia(1),-2);
		t:TRINITY;
	begin
		case currRE.V is
			when REQ_PAL =>
				that:=currRE.pal_down;
			when REQ_PALCAP =>
				that:=currRE.palcap_down;
			when REQ_BEGIN =>
				that:=currRE.begin_down;
			when REQ_UPDOWN =>
				that:=currRE.updown_down;
			when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3204) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " wrong RE" & ":" & REQ_TY'Image(currRE.V) & ":" & Integer'Image(in_ia(1));
		end case;
		if that.updown_down = null then
			--checkRE("matchesPalSub S",endy);
			t:=internalMatch(that,in_ia,out_ia,m,trackcount,endy,depth);
		else
			--checkRE("matchesPalSub D",endy);
			t:=daisy(that,in_ia,out_ia,m,trackcount,endy,depth);
			--checkRE("matchesPalSub T",endy);
		end if; -- if that.updown_down = null then
		return t;
	end matchesPalSub;
	--======================--
	-- ** INTERNAL MATCH ** --
	--======================--
	function internalMatch(this:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY is
		r:TRINITY:=BAD;
	begin
		out_ia:=(in_ia(1),in_ia(2));
		endy:=null;
		r:=matchesLeftRight(this.right,in_ia,out_ia,m,endy,trackcount,depth);
		--checkRE("matchesPalSub I",endy);
		return r; 
	end internalMatch;
	
-- ############################## matchesPal.adb ##############################
function matchesPal(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY is
		tmp_ia:I_A;
		result: TRINITY:=GOOD;
		r:TRINITY:=GOOD;
		cnt:Integer:=0;
		max:Integer;
		min:Integer;
		greedy:Boolean:=TRUE;
		wtrackcount:Integer:=trackcount;
		matched_ia:I_A:=(in_ia(1),-1);
		save_out_ia:I_A:=(-1,-1);
		save_tmp_ia:I_A:=(-1,-1);
		save_endy:RE_Elem_AC:=null;
		save_matched_ia:I_A:=(-1,-1);
		save_r:TRINITY:=BAD;
		save_cnt:Integer:=0;
	begin
		
		case currRE.V is
			when REQ_PAL =>
				max:=currRE.pal_max;
				min:=currRE.pal_min;
				greedy:=currRE.pal_greedy;
			when REQ_PALCAP =>
				max:=currRE.palcap_max;
				min:=currRE.palcap_min;
				greedy:=currRE.palcap_greedy;
				wtrackcount:=currRE.palcap_trackcount;
			when REQ_BEGIN =>
				max:=1;
				min:=1;
			when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3205) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " wrong RE" & ":" & REQ_TY'Image(currRE.V);
		end case;
		out_ia:=in_ia; -- tail of string not yet scanned
		endy:=null;
		cnt:=1;
		while cnt<=max loop
			result:=matchesPalSub(currRE,out_ia,tmp_ia,m,trackcount,endy,depth);
			if cnt=1 and min = 0 and result = BAD then
				r:=UGLY;
				exit;
			elsif cnt < min and result = BAD then
				r:=BAD;
				exit;
			end if;
			case result is
				when GOOD =>
					if tmp_ia(1) = out_ia(1) then
						null;
					else
						matched_ia(2):=tmp_ia(1)-1;
						out_ia(1):=tmp_ia(1);
					end if;
				when UGLY =>
					if tmp_ia(1) = out_ia(1) then
						null;
					else
						matched_ia(2):=tmp_ia(1)-1;
						out_ia(1):=tmp_ia(1);
					end if;
					r:=UGLY;
					exit;
				when others =>
					if cnt > 1 then
						cnt:=cnt -1;
						r:=GOOD;
					else
						r:=BAD;
					end if;
					exit;
			end case;
			if cnt = max then
				exit;
			end if;
			if cnt < min then
				cnt:=cnt + 1;
			elsif greedy then
				cnt:=cnt + 1;
			elsif (greedy = FALSE) and (matchesNext(currRE,out_ia) = FALSE) then
				save_out_ia:=out_ia;
				save_tmp_ia:=tmp_ia;
				save_endy:=endy;
				save_matched_ia:=matched_ia;
				save_r:=r;
				save_cnt:=cnt;
				cnt:=cnt + 1;
			else
				exit;
			end if;
		end loop; -- while cnt<=max
		if save_r /= BAD and r = BAD then
			out_ia:=save_out_ia;
			tmp_ia:=save_tmp_ia;
			endy:=save_endy;
			matched_ia:=save_matched_ia;
			r:=save_r;
			cnt:=save_cnt;
		end if;
		if endy /= null then
			null;
		end if;
		if endy /= null then
			null;
		end if;
		if endy /= null then
			null;
		end if;
		if r = BAD then
			out_ia:=in_ia;
			if wtrackcount=trackcount then
				MatchPack.delete(m,trackcount + 1);
			else
				MatchPack.delete(m,trackcount);
			end if;
			return r;
		else
			--checkRE("matchesPal KNO 1.4",endy,TRUE);
			--checkRE("matchesPal KNO2",endy,TRUE);
			case currRE.V is
				when REQ_PALCAP =>
					if matched_ia(2) < matched_ia(1) then
						MatchPack.insert(m,Null_Unbounded_Wide_Wide_String,matched_ia(1),matched_ia(2),currRE);
					elsif matched_ia(2) > LCI then
raise Program_Error with E_TY'Image(Y2018.Text.E3206) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " index outside input string";
					else
						MatchPack.insert(m,To_Unbounded_Wide_Wide_String(s,matched_ia(1),matched_ia(2)),matched_ia(1),matched_ia(2),currRE);
					end if;
				when others =>
					null;
			end case;
			--checkRE("matchesPal KNO3",endy);
			if out_ia(1) > LCI then
				r:=UGLY;
			else
				r:=GOOD;
			end if;
		end if;
		--checkRE("matchesPal Last",endy);
		return r;
	end matchesPal;
-- ############################## matchesElem.adb ##############################
	function matchesElem(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;depth:Integer) return TRINITY is -- CHAR,PERIOD,CLASS_P
		cnt:Integer:=0;
		notYet_ia:I_A; -- tail of string not yet scanned
		result:TRINITY:=GOOD;
		updOK: Boolean:=FALSE;
		max:Integer;
		min:Integer;
		greedy:Boolean;
	begin
		out_ia(1):=in_ia(1); out_ia(2):=in_ia(2);
		notYet_ia(1):=in_ia(1); notYet_ia(2):=in_ia(2);	
		case currRE.V is
			when REQ_CHAR =>
				max:=currRE.char_max;
				min:=currRE.char_min;
				greedy:=currRE.char_greedy;
			when REQ_PERIOD =>
				max:=currRE.period_max;
				min:=currRE.period_min;
				greedy:=currRE.period_greedy;
			when REQ_CLASS =>
				max:=currRE.class_max;
				min:=currRE.class_min;
				greedy:=currRE.class_greedy;
			when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3301) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Not a CHAR,PERIOD or CLASS" & ":" & REQ_TY'Image(currRE.V) & ":" & Integer'Image(in_ia(1));
		end case;
		if min = 0 and greedy = FALSE then
			updOK:=TRUE;
			result:=UGLY;
			if matchesNext(currRE,notYet_ia) then
				return GOOD;--
			end if;
		end if;
		cnt:=0;
		loop
			if notYet_ia(1) > LCI then
				result:=UGLY;
				updOK:=TRUE;
				exit;
			end if;
			if cnt +1 > max then
				exit;
			end if;
			if cnt +1 > min and cnt +1 <=max and greedy=FALSE then
				if matchesNext(currRE,notYet_ia) then
					exit;
				end if;
			end if;
			cnt:=cnt+1;
			result:=matchesOne(currRE,notYet_ia);
			case result is
				when GOOD =>
					updOK:=TRUE;
					notYet_ia(1):=notYet_ia(1) + 1;
				when UGLY =>
					updOK:=TRUE;
					notYet_ia(1):=notYet_ia(1) + 1;
					exit;
				when others =>
					if updOK then
						result:=GOOD;
					elsif greedy = TRUE and min = 0 then
						result:=GOOD;
					end if;
					exit;
			end case;
		end loop;
		if cnt < min then
			return BAD;
		end if;
		case result is
			when GOOD =>
				out_ia:=notYet_ia;
				return result;
			when UGLY =>
				out_ia:=notYet_ia;
				return result;
			when others =>
				return BAD;
		end case;
	end matchesElem;
-- ############################## matchesLeftRight.adb ##############################
	function matchesLeftRight(currRE:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;leftRight:out RE_Elem_AC;trackcount:Integer;depth:Integer) return TRINITY is
		notYet_ia:I_A; -- tail of string not yet scanned
		found_ia:I_A:=(1,0); -- result of scan 
		tia:I_A; -- temporary range of string
		qia:I_A; -- temporary range of string
		result: TRINITY:=GOOD;
		endy:RE_Elem_AC:=null;
	begin
		notYet_ia(1):=in_ia(1); notYet_ia(2):=in_ia(2);
		leftRight:=currRE;
		while leftRight /= null loop -- Inner
			result:=GOOD;
			tia(1):=notYet_ia(1); tia(2):=notYet_ia(2);
			case leftRight.V is
				when REQ_PAL =>
					result:=matchesPal(leftRight,tia,qia,m,trackcount,endy,depth + 1);
					case result is
						when GOOD =>
							if notYet_ia(1) < qia(1)  then
								found_ia(2):=qia(1) - 1;
								notYet_ia(1):=qia(1);
							end if;
						when UGLY =>
							if notYet_ia(1) < qia(1)  then
								found_ia(2):=qia(1) - 1;
								notYet_ia(1):=qia(1);
							end if;
							result:=GOOD;
							exit;
						when others =>
								exit;
					end case;
				when REQ_PALCAP =>
					result:=matchesPal(leftRight,tia,qia,m,trackcount,endy,depth + 1);
					case result is
						when GOOD =>
							if notYet_ia(1) < qia(1)  then
								found_ia(2):=qia(1) - 1;
								notYet_ia(1):=qia(1);
							end if;
						when UGLY =>
							if notYet_ia(1) < qia(1)  then
								found_ia(2):=qia(1) - 1;
								notYet_ia(1):=qia(1);
							end if;
							result:=GOOD;
							exit;
						when others =>
								exit;
					end case;
				when others =>
					result:=matchesElem(leftRight,tia,qia,depth);
					case result is
						when GOOD =>
							found_ia(2):=qia(1) - 1;
							notYet_ia(1):=qia(1);
						when UGLY =>
							found_ia(2):=qia(1) - 1; 
							notYet_ia(1):=qia(1); 
							exit;
						when others =>
								exit;
					end case;
			end case;
			leftRight:=leftRight.right;
		end loop; -- Inner
		if result = UGLY then
			if leftRight = null then
				null;
			elsif isEnd(leftRight,TRUE) then
				null;
			else
				result:=BAD;
			end if;
		end if;
		if result =  BAD then
			return BAD; 
		end if;
		out_ia(1):=notYet_ia(1); out_ia(2):=notYet_ia(2);
		return result;
	end matchesLeftRight;
-- ############################## matchesOne.adb ##############################
	function matchesOne(currRE:RE_Elem_AC;in_ia:I_A) return TRINITY is -- CHAR,PERIOD,CLASS_P
	begin
		if in_ia(1) > in_ia(2) then
			return BAD;
		end if;
		case currRE.V is
			when REQ_CHAR =>
				if currRE.char_negative then
					if currRE.char_value = s(in_ia(1)) then 
						return BAD; 
					end if;
				else
					if currRE.char_value /= s(in_ia(1)) then
						return BAD; 
					end if;
				end if;
			when REQ_PERIOD =>
				null;
			when REQ_CLASS =>
				if RangeVectorPack.length(currRE.class_pos)>0 then
					if not RangeVectorPack.exists(currRE.class_pos,s(in_ia(1))) then
						return BAD;
					end if;
				end if;
				if RangeVectorPack.length(currRE.class_neg)>0 then
					if RangeVectorPack.exists(currRE.class_neg,s(in_ia(1))) then
						return BAD;
					end if;
				end if;
when others => raise Program_Error with E_TY'Image(Y2018.Text.E3401) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Not a CHAR,PERIOD or CLASS" & ":" & REQ_TY'Image(currRE.V) & ":" & Integer'Image(in_ia(1));
		end case;
		if in_ia(1) + 1 > in_ia(2) then
			return UGLY;
		end if;
		return GOOD;
	end matchesOne;
-- ############################## matchesNext.adb ##############################
function matchesNext(currRE:RE_Elem_AC;in_ia:I_A) return BOOLEAN is
	thisRE:RE_Elem_AC:=null;
	r:TRINITY;
	rb:Boolean;
	function qVerify(currRE:RE_Elem_AC) return TRINITY;
	function qHandle(currRE:RE_Elem_AC;i:Integer) return TRINITY;
	
	function qHandle(currRE:RE_Elem_AC;i:Integer) return TRINITY is
		j:Integer:=i;
		result:TRINITY:=BAD;
		min:Integer:=RegexTool.getMin(currRE);
		goRE:RE_Elem_AC;
	begin
		while j-i<min loop
			case currRE.V is
				when REQ_CHAR =>
					if in_ia(1)+j > LCI then
						result:=BAD;
						exit;
					elsif currRE.char_negative then
						if currRE.char_value /= s(in_ia(1)+j) then
							result:=GOOD;
						else
							result:=BAD;
							exit;
						end if;
					else
						if currRE.char_value = s(in_ia(1)+j) then
							result:=GOOD;
						else
							result:=BAD;
							exit;
						end if;
					end if;
				when REQ_PERIOD =>
					if in_ia(1)+j > LCI then
						result:=BAD;
						exit;
					end if;
					result:=GOOD;
				when REQ_CLASS =>
					if in_ia(1)+j > LCI then
						result:=BAD;
						exit;
					elsif RangeVectorPack.exists(currRE.class_pos,s(in_ia(1)+j)) then
						if RangeVectorPack.exists(currRE.class_neg,s(in_ia(1)+j)) then
							result:=BAD;
							exit;
						else
							result:=GOOD;
						end if;
					else
						if RangeVectorPack.exists(currRE.class_neg,s(in_ia(1)+j)) then
							result:=BAD;
							exit;
						else
							result:=GOOD;
						end if;
					end if;
				when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3505) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " qHandle" & ":" & REQ_TY'Image(currRE.V) & ":" & Integer'Image(in_ia(1));
			end case;
			j:=j+1;
		end loop;
		if result=GOOD and currRE.right /= null and RegexTool.getMax(currRE) = min and j<10 then
			goRE:=currRE.right;
			case goRE.V is
				when REQ_CHAR =>
					if getMin(goRE) > 0 then
						result:=qHandle(goRE,j);
					end if;
				when REQ_PERIOD =>
					if getMin(goRE) > 0 then
						result:=qHandle(goRE,j);
					end if;
				when REQ_CLASS =>
					if getMin(goRE) > 0 then
						result:=qHandle(goRE,j);
					end if;
				when others =>
					null;
			end case;
		end if;
		return result;
	end qHandle;
	
	function qVerify(currRE:RE_Elem_AC) return TRINITY is
		r:TRINITY;
	begin
		case currRE.V is
			when REQ_CHAR =>
				if currRE.char_min > 0 then
					if currRE.char_negative then
						if currRE.char_value /= s(in_ia(1)) then
							r:=qHandle(currRE,0);
							return r;
						end if;
					else
						if currRE.char_value = s(in_ia(1)) then
							r:=qHandle(currRE,0);
							return r;
						end if;
					end if;
					return BAD;
				end if;
			when REQ_PERIOD =>
				if currRE.period_min > 0 then
					r:=qHandle(currRE,0);
					return r;
				end if;
			when REQ_CLASS =>
				if currRE.class_min > 0 then
					if RangeVectorPack.exists(currRE.class_pos,s(in_ia(1))) then
						if RangeVectorPack.exists(currRE.class_neg,s(in_ia(1))) then
							null;
						else
							r:=qHandle(currRE,0);
							return r;
						end if;
					elsif RangeVectorPack.length(currRE.class_neg)>0 then
						if RangeVectorPack.exists(currRE.class_neg,s(in_ia(1))) then
							null;
						else
							r:=qHandle(currRE,0);
							return r;
						end if;
					end if;
					return BAD;
				end if;
			when others =>
				return UGLY;
		end case;
		return UGLY;
	end qVerify;
	-- -------------------- --
	--  MATCHES NEXT BODY   --
	-- -------------------- --
begin
	if currRE = o_matchesNext_currRE and
		in_ia = o_matchesNext_in_ia then
		rb:=o_matchesNext_return;
		return rb;
	end if;
	o_matchesNext_currRE:=currRE;
	o_matchesNext_in_ia:=in_ia;
	if in_ia(1) > LCI then
		o_matchesNext_return:=FALSE;
		return FALSE;
	end if;
	if in_ia(2) < in_ia(1) then
		o_matchesNext_return:=FALSE;
		return FALSE;
	end if;
	thisRE:=navSec(currRE,FALSE);
	while thisRE /= null loop
		r:=qVerify(thisRE);
		case r is
			when UGLY =>
				exit;
			when GOOD =>
				o_matchesNext_return:=TRUE;
				return TRUE;
			when others =>
				null;
		end case;
		thisRE:=navLeftDownRight(thisRE);
	end loop;
	o_matchesNext_return:=FALSE;
	return FALSE;
end matchesNext;
-- ############################## daisy.adb ##############################
	--=============--
	-- ** DAISY ** --
	--=============--
	function daisy(this:RE_Elem_AC;in_ia:I_A;out_ia:out I_A;m:in out MatchPack.Match_TY;trackcount:Integer;endy:out RE_Elem_AC;depth:Integer) return TRINITY is
		matched_ia:I_A:=(in_ia(1),-2);
		Gout_ia:I_A;
		Gm:MatchPack.Match_TY;
		Gendy:RE_Elem_AC;
		Gr:TRINITY;
		Hout_ia:I_A;
		Hm:MatchPack.Match_TY;
		Hendy:RE_Elem_AC;
		Hr:TRINITY;
		choose_G:Boolean;
		--===============--
		-- ## Task NX ## --
		--===============--
		task NX is
			entry Valuate(
								 Qthat:in RE_Elem_AC;
								 Qin_ia:in I_A;
								 Qtrackcount:in Integer;
								 Qdepth:in Integer);
			entry Result(
								Qout_ia:out I_A;
								Qnx_m:out MatchPack.Match_TY;
								Qendy:out RE_Elem_AC;
								Qnx_r:out TRINITY);
		end NX;
		task body NX is
			NXthat:RE_Elem_AC;
			NXin_ia:I_A;
			NXtrackcount:Integer;
			NXdepth:Integer;
			NXout_ia:I_A;
			NXm:MatchPack.Match_TY;
			NXendy:RE_Elem_AC;
			NXr:TRINITY;
			--pool:RegexTool.Pool_TY;
		begin
			accept Valuate(Qthat:in RE_Elem_AC;Qin_ia:in I_A;Qtrackcount:in Integer;Qdepth:in Integer) do
				NXthat:=Qthat;--deepClone(Qthat);
				NXin_ia:=Qin_ia;
				NXtrackcount:=Qtrackcount;
				NXdepth:=Qdepth;
			end Valuate;
			--pool.root:=NXthat;
			NXr:=matchesPalSub(NXthat,NXin_ia,NXout_ia,NXm,NXtrackcount,NXendy,NXdepth);
			accept Result(Qout_ia:out I_A;Qnx_m:out MatchPack.Match_TY;Qendy:out RE_Elem_AC;Qnx_r:out TRINITY) do
				Qout_ia:=NXout_ia;
				Qnx_m:=NXm;
				Qendy:=NXendy;
				Qnx_r:=NXr;
			end Result;
			NXthat:=null;
			--pool.root:=null;
		end NX;
	begin
		NX.Valuate(this,in_ia,trackcount,depth);
		Gr:=internalMatch(this,in_ia,Gout_ia,Gm,trackcount,Gendy,depth);
		NX.Result(Hout_ia,Hm,Hendy,Hr);
		-- Evaluate & compare results
		if Gr = BAD and Hr = BAD then
			return BAD;
		elsif Gr = BAD then
			choose_G:=FALSE;
		elsif Hr = BAD then
				choose_G:=TRUE;
		elsif Hout_ia(1) > Gout_ia(1) then
			choose_G:=FALSE;
		else
			choose_G:=TRUE;
		end if;
		if choose_G then -- G is this thread --
			if Gr = GOOD then
				if Gout_ia(1) -1 > matched_ia(2) then
					matched_ia(2):= Gout_ia(1) -1;
				end if;
				endy:=Gendy;
				Y2018.Text.Jets.MatchPack.merge(m,Gm);
				out_ia:=Gout_ia;
				return GOOD;
			else
				if Gout_ia(1) -1 > matched_ia(2) then
					matched_ia(2):= Gout_ia(1) -1;
				end if;
				endy:=Gendy;
				Y2018.Text.Jets.MatchPack.merge(m,Gm);
				out_ia:=Gout_ia;
				return UGLY;
			end if;
		else -- H, values from the other/child thread 
			if Hr = GOOD then
				if Hout_ia(1) -1 > matched_ia(2) then
					matched_ia(2):= Hout_ia(1) -1;
				end if;
				endy:=Hendy;
				Y2018.Text.Jets.MatchPack.merge(m,Hm);
				out_ia:=Hout_ia;
				return GOOD;
			else
				if Hout_ia(1) -1 > matched_ia(2) then
					matched_ia(2):= Hout_ia(1) -1;
				end if;
				endy:=Hendy;
				Y2018.Text.Jets.MatchPack.merge(m,Hm);
				out_ia:=Hout_ia;
				return UGLY;
			end if;
		end if;
	end daisy;	
-- ############################## matchesBody.adb ##############################
	-- ==================== --
	--  navLeftDownRight    --
	-- ==================== --
	function navLeftDownRight(currRE:RE_Elem_AC) return RE_Elem_AC is
		that:RE_Elem_AC;
	begin
		if currRE = null then
			return null;
		end if;
		that:=currRE;
		while that.left /= null loop -- LEFT
			that:=that.left;
		end loop;
		if that.V /= REQ_UPDOWN then
			return null;
		end if;
		while that.updown_down /= null loop -- DOWN
			that:=that.updown_down;
			if that.right /=null then -- first RIGHT found
				return that.right;
			end if;
		end loop;
		return null;
	end navLeftDownRight;
	-- ==================== --
	--   navLeftTopRight    --
	-- ==================== --
	function navLeftTopRight(currRE:RE_Elem_AC) return RE_Elem_AC is
		that:RE_Elem_AC;
	begin
		if currRE = null then
			return null;
		end if;
		that:=currRE;
		while that.left /= null loop -- LEFT
			that:=that.left;
		end loop;
		if that.V /= REQ_UPDOWN then
			return null;
		end if;
		while that.V = REQ_UPDOWN loop -- UP
			that:=that.updown_up;
		end loop;
		case that.V is -- TOP
			when REQ_BEGIN =>
				return that.right;
			when REQ_PALCAP =>
				return that.right;
			when REQ_PAL =>
				return that.right;
			when others =>
raise Program_Error with E_TY'Image(Y2018.Text.E3602) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Not BEGIN,PALCAP or PAL" & ":" & REQ_TY'Image(that.V);
		end case;
	end navLeftTopRight;
	-- ==================== --
	--   navSec             --
	-- ==================== --
	function navSec(currRE:RE_Elem_AC;down:Boolean) return RE_Elem_AC is
		-- get next node of type REQ_CHAR, REQ_PERIOD, REQ_CLASS
		-- down=TRUE, if node is REQ_PALCAP or REQ_PAL then search first from down-link before search from right-link 
		thatRE:RE_Elem_AC;
		thisRE:RE_Elem_AC:=null;
	begin
		if down and (currRE.V = REQ_PALCAP or currRE.V = REQ_PAL) then
			if currRE.V = REQ_PALCAP then
				thisRE:=currRE.palcap_down;
			else
				thisRE:=currRE.pal_down;
			end if;
			while thisRE/=null loop -- retreive from up-down first node with a right-link
				if thisRE.right/=null then
					exit;
				end if;
				thisRE:=thisRE.updown_down;
			end loop;
			if thisRE = null then
				thatRE:=currRE.right;
			else
				thatRE:=thisRE.right;
			end if;
		else
			thatRE:=currRE.right;
		end if;
		if thatRE/=null then
			case thatRE.V is
				when REQ_CHAR =>
					return thatRE;
				when REQ_PERIOD =>
					return thatRE;
				when REQ_CLASS =>
					return thatRE;
				when others =>
					thisRE:=navSec(thatRE,TRUE);
					if thisRE /=null then
						return thisRE;
					end if;
			end case;
		end if;
		thatRE:=navLeftDownRight(currRE);
		if thatRE/=null then
			case thatRE.V is
				when REQ_CHAR =>
					return thatRE;
				when REQ_PERIOD =>
					return thatRE;
				when REQ_CLASS =>
					return thatRE;
				when others =>
					thisRE:=navSec(thatRE,TRUE);
					if thisRE /=null then
						return thisRE;
					end if;
			end case;
		end if;
		thatRE:=navLeftTopRight(currRE);
		if thatRE/=null then
			case thatRE.V is
				when REQ_CHAR =>
					return thatRE;
				when REQ_PERIOD =>
					return thatRE;
				when REQ_CLASS =>
					return thatRE;
				when others =>
					thisRE:=navSec(thatRE,TRUE);
					if thisRE /=null then
						return thisRE;
					end if;
			end case;
		end if;
		return null;
	end navSec;
	-- ==================== --
	--   isEnd              --
	-- ==================== --
	function isEnd(currRE:RE_Elem_AC;basecall:Boolean) return Boolean is
		-- TRUE if end of syntax and no manadatory characters
		-- FALSE if a mandatory character according to syntax exists
		-- ................ --
		--   orEnd          --
		-- ................ --
		function orEnd(currRE:RE_Elem_AC) return Boolean is
			cnt:Integer:=0;
			yeah:Boolean:=TRUE;
			updown:RE_Elem_AC;
		begin
			updown:=currRE;
			while updown /= null loop
				if isEnd(updown,FALSE) then
					cnt:=cnt + 1;
				else
					yeah:=FALSE;
				end if;
				updown:=updown.updown_down;
			end loop;
			if yeah then
				null;
			elsif cnt>0 then
				yeah:=TRUE;
			end if;
			--return (if cnt > 0 then TRUE else FALSE);
			return yeah;
		end orEnd;
		-- ................ --
		--   right          --
		-- ................ --
		function right(currRE:RE_Elem_AC) return Boolean is
			that:RE_Elem_AC; --:=currRE.right; 20190530
		begin
			that:=currRE; -- 20190530
			while that /= null loop
				case that.V is
					when REQ_BEGIN =>
						if isEnd(that,FALSE) = FALSE then
							return FALSE;
						end if;
					when REQ_PAL =>
						if isEnd(that,FALSE) = FALSE then
							return FALSE;
						end if;
					when REQ_PALCAP =>
						if isEnd(that,FALSE) = FALSE then
							return FALSE;
						end if;
					when REQ_UPDOWN =>
						null;
					when others =>
						if getMin(that) > 0 then
							return FALSE;
						end if;
				end case;
				that:=that.right;
			end loop;
			return TRUE;
		end right;
		-- ................ --
		--   (Main)         --
		-- ................ --

		that:RE_Elem_AC;
		this:RE_Elem_AC;
	begin
		if currRE = null then
			return TRUE;
		else
			if basecall then
				that:=currRE.right;
			else
				that:=currRE;
			end if;
			while that /= null loop
				if getMin(that) = 0 then
					null;
				else
					case that.V is
						when REQ_BEGIN =>
							if orEnd(that.begin_down) then
								null;
							else
								return FALSE;
							end if;
						when REQ_PAL =>
							if orEnd(that.pal_down) then
								null;
							else
								return FALSE;
							end if;
						when REQ_PALCAP =>
							if orEnd(that.palcap_down) then
								null;
							else
								return FALSE;
							end if;
						when others =>
							return right(that);
					end case;
				end if;
				that:=that.right;
			end loop;
		end if;
		if basecall then
			this:=navLeftTopRight(currRE);
			if this = null then
				return TRUE;
			end if;
			if isEnd(this,FALSE) then
				return TRUE;
			else
				return FALSE;
			end if;
		end if;
		return TRUE;
	end isEnd;
	
	-- ==================== --
	--   MATCHES BODY       --
	-- ==================== --
begin
	if startPos > s'Last(1) or startPos < 1 then
		return FALSE;
	end if;
	pia:=(startPos,s'Last(1) + 1);
	case matchesPal(currRE,pia,qia,mP,-1,endy,depth + 1) is
		when GOOD =>
			--checkRE("Matches G",endy);
			if GDOLLAR and qia(1) > LCI and isEnd(endy,TRUE) then
				m:=mP;
				nextPos:=qia(1);
				return TRUE;
			elsif GDOLLAR = FALSE then
				m:=mP;
				nextPos:=qia(1);
				return TRUE;
			end if;
		when UGLY =>
			--checkRE("Matches U",endy);
			if GDOLLAR and qia(1) > LCI and isEnd(endy,TRUE) then  
				m:=mP;
				nextPos:=qia(1);
				return TRUE;
			elsif GDOLLAR = FALSE then
				m:=mP;
				nextPos:=qia(1);
				return TRUE;
			end if;
		when others =>
			--checkRE("Matches O",endy);
			null;
	end case;
	nextPos:=startPos;
	return FALSE;
end matches;
-- ############################## pattern.adb ##############################
procedure Finalize(p : in out Pattern) is
begin
	RegexTool.Finalize(p.pool);
end Finalize;

function Pattern_Map_less(Left, Right : MatchID) return Boolean is
begin
	return Left < Right;
end Pattern_Map_less;
function Pattern_Map_equal(Left, Right : RE_ID) return Boolean is
begin
	return Left = Right;
end Pattern_Map_equal;
function get_begin_trackcount(ptc:Pattern_AC) return Integer is
begin
	if ptc = null then
		return 0;
	elsif ptc.top =null then
		return 0;
	elsif ptc.top.v = REQ_BEGIN then
		return ptc.top.begin_trackcount;
	else
		return 0;
	end if;
end get_begin_trackcount;
-- ############################## PatternPackTail.adb ##############################
end Y2018.Text.Jets.PatternPack;
