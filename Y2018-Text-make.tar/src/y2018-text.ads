-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
package Y2018.Text is
	Version:constant String:="1.4.2";
	type E_TY is (
E0001, -- Qappend Exception
E0002, -- Qappend-alt Exception
E0003, -- Qappend Exception
E0004, -- Qappend-alt Exception
E0021, -- Out of range
E0022, -- Out of range
E0023, -- Out of range
E0040, -- Length<0
E0041, -- Length<0
E0050, -- byte 2/
E0051, -- byte 3/
E0052, -- byte 4/
E0053, -- Illegal
E0054, -- % >LAST
E0055, -- Illegal
E0056, -- Out of range
E0057, -- Out of range
E1001, -- Not BEGIN, PALCAP, PAL or UPDOWN
E1002, -- Not supported RE-type
E1003, -- Insert fail REQ_CLASS_OTHER
E1020, -- Not publishable
E1031, -- REQ node has no 'min'
E1032, -- REQ node has no 'max'
E1033, -- REQ node has no 'greedy'
E2002, -- Cannot find [\p{ % }]
E2003, -- Cannot find [\p{ % }]
E3001, -- Node % link
E3002, -- Node % link
E3003, -- Node % link
E3004, -- Node % link
E3005, -- Node % link
E3006, -- Node % link
E3007, -- Node % link
E3008, -- Node % link
E3101, -- syntax at state % index
E3102, -- syntax at state % index
E3103, -- syntax at state % index
E3104, -- syntax at state % index
E3105, -- syntax at state % index
E3106, -- syntax at state % index
E3107, -- syntax at state % index
E3108, -- syntax at state % index
E3109, -- syntax at state % index
E3110, -- syntax at state % index
E3111, -- syntax at state % index
E3112, -- syntax at state % index
E3113, -- syntax at state % index
E3114, -- syntax at state % index
E3115, -- syntax at state % index
E3116, -- syntax at state % index
E3117, -- syntax at state % index
E3118, -- syntax at state % index
E3119, -- syntax at state % index
E3120, -- syntax at state % index
E3121, -- syntax at state % index
E3122, -- syntax at state % index
E3123, -- syntax at state % index
E3124, -- syntax at state % index
E3125, -- syntax at state % index
E3126, -- syntax at state % index
E3127, -- syntax at state % index
E3128, -- syntax at state % index
E3131, -- syntax at state % index
E3132, -- syntax at state % index
E3133, -- syntax at state % index
E3134, -- syntax at state % index
E3135, -- syntax at state % index
E3136, -- syntax at state % index
E3137, -- syntax at state % index
E3138, -- syntax at state % index
E3139, -- syntax at state % .Backslash or ']' expected. index
E3140, -- syntax at state % index
E3141, -- syntax at state % index
E3142, -- syntax at state % index
E3143, -- syntax at state % index
E3144, -- syntax at state % index
E3145, -- syntax at state % index
E3146, -- syntax at state % index
E3148, -- syntax at state % index
E3149, -- syntax at state % index
E3150, -- syntax at state % index
E3151, -- syntax at state % back-slash must be doubbled, index
E3152, -- Too few palenteses or brackets
E3153, -- Too many palenteses or brackets
E3154, -- syntax at state % index
E3155, -- syntax at state % index
E3156, -- syntax at state % index
E3157, -- syntax at state % index
E3158, -- syntax at state % index
E3204, -- wrong RE
E3205, -- wrong RE
E3206, -- index outside input string
E3301, -- Not a CHAR,PERIOD or CLASS
E3401, -- Not a CHAR,PERIOD or CLASS
E3505, -- qHandle
E3602, -- Not BEGIN,PALCAP or PAL
E4001, -- re=null
E4002, -- re.V/=REQ_PALCAP
E4004, -- ^RE_ID2KElem_TY.Has_Element(c)
E4005, -- ^RE_ID2KElem_TY.Has_Element(c)
E4006, -- ^RE_ID2KElem_TY.Has_Element(source_vcur)
E4007, -- RE_ID2KElem_TY.Has_Element(target_vcur)
E4101, -- Pattern string incompatible
E4201, -- No code type. Line
E4202, -- No code type. Line
E4203, -- No code type. Line
E4204, -- No code type. Line
E4205, -- No code type. Line
E4206, -- No code type. Line
E4207, -- No procedure or package statement found. Line
E4208, -- Index. Line
E4209, -- Illegal Backslash. Line
E4210, -- Illegal Backslash. Line
E4211, -- Illegal Backslash. Line
E4212, -- Illegal Backslash. Line
E4213, -- Illegal Backslash. Line
E4214, -- Illegal Backslash. Line
E4215, -- Missing quote. Line
E4216, -- Missing quote. Line
E4217, -- Empty. Line
E4218, -- Index. Line
E4219, -- Illegal Backslash. Line
E4220, -- Illegal Backslash. Line
E4221, -- Illegal Backslash. Line
E4222, -- Illegal Backslash. Line
E4223, -- Illegal Backslash. Line
E4224, -- Illegal Backslash. Line
E4225, -- Missing apostrophe. Line
E4226, -- Missing apostrophe. Line
E4227, -- More than one character. Line
E4228, -- Unknown pattern. Line 
E5001, -- length<0 # mid=70
E5002, -- length<0 # mid=71
E5003, -- length<0 # mid=72
E5004, -- too long pad # mid=73
E5005, -- length<0 # mid=74
E5006, -- too long pad # mid=75
E5007, -- too long pad # mid=76
E5008, -- too long pad # mid=77
E5009, -- too long pad # mid=78
E5010, -- too long pad # mid=79
E5011, -- byte 2/ # mid=60
E5012, -- byte 3/ # mid=61
E5013, -- byte 4/ # mid=62
E5014, -- Illegal # mid=63
E5015, -- % > 'LAST # mid=64
E5016, -- Illegal # mid=65
E5017, -- Out of range # mid=66
E5018, -- Out of range # mid=67
E5019, -- Out of range # mid=32
E5020, -- Out of range # mid=33
E5021, -- Out of range # mid=31
E5035, -- UTF8 alt. 2[bytes 2].2 eof at byte <bytecnt>
E5036, -- UTF8 alt. 2[bytes 2].2 illegal at byte <bytecnt>
E5037, -- UTF8 alt. 3[bytes 3].2 eof at byte <bytecnt>
E5038, -- UTF8 alt. 3[bytes 3].3 eof at byte <bytecnt>
E5039, -- UTF8 alt. 3[bytes 3].3 illegal at byte <bytecnt>
E5040, -- UTF8 alt. 3[bytes 3].2 illegal at byte <bytecnt>
E5041, -- UTF8 alt. 4[bytes 3].2 eof at byte <bytecnt>
E5042, -- UTF8 alt. 4[bytes 3].3 eof at byte <bytecnt>
E5043, -- UTF8 alt. 4[bytes 3].3 illegal at byte <bytecnt>
E5044, -- UTF8 alt. 4[bytes 3].2 illegal at byte <bytecnt>
E5045, -- UTF8 alt. 5[bytes 3].2 eof at byte <bytecnt>
E5046, -- UTF8 alt. 5[bytes 3].3 eof at byte <bytecnt>
E5047, -- UTF8 alt. 5[bytes 3].3 illegal at byte <bytecnt>
E5048, -- UTF8 alt. 5[bytes 3].2 illegal at byte <bytecnt>
E5049, -- UTF8 alt. 6[bytes 3].2 eof at byte <bytecnt>
E5050, -- UTF8 alt. 6[bytes 3].3 eof at byte <bytecnt>
E5051, -- UTF8 alt. 6[bytes 3].3 illegal at byte <bytecnt>
E5052, -- UTF8 alt. 6[bytes 3].2 illegal at byte <bytecnt>
E5053, -- UTF8 alt. 7[bytes 4].2 eof at byte <bytecnt>
E5054, -- UTF8 alt. 7[bytes 4].3 eof at byte <bytecnt>
E5055, -- UTF8 alt. 7[bytes 4].4 eof at byte <bytecnt>
E5056, -- UTF8 alt. 7[bytes 4].4 illegal at byte <bytecnt>
E5057, -- UTF8 alt. 7[bytes 4].3 illegal at byte <bytecnt>
E5058, -- UTF8 alt. 7[bytes 4].2 illegal at byte <bytecnt>
E5059, -- UTF8 alt. 8[bytes 4].2 eof at byte <bytecnt>
E5060, -- UTF8 alt. 8[bytes 4].3 eof at byte <bytecnt>
E5061, -- UTF8 alt. 8[bytes 4].4 eof at byte <bytecnt>
E5062, -- UTF8 alt. 8[bytes 4].4 illegal at byte <bytecnt>
E5063, -- UTF8 alt. 8[bytes 4].3 illegal at byte <bytecnt>
E5064, -- UTF8 alt. 8[bytes 4].2 illegal at byte <bytecnt>
E5065, -- UTF8 alt. 9[bytes 4].2 eof at byte <bytecnt>
E5066, -- UTF8 alt. 9[bytes 4].3 eof at byte <bytecnt>
E5067, -- UTF8 alt. 9[bytes 4].4 eof at byte <bytecnt>
E5068, -- UTF8 alt. 9[bytes 4].4 illegal at byte <bytecnt>
E5070, -- UTF8 alt. 9[bytes 4].2 illegal at byte <bytecnt>
E5071, -- UTF8 alt. 9[bytes 4].3 illegal at byte <bytecnt>
E5072, -- Illegal first byte at byte <bytecnt>
		E9999); -- Value not in use
end Y2018.Text;
