-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190407173029.
-- ############################## TestQ.adb ##############################
with Ada.Environment_Variables;
with Ada.Containers.Vectors;
with Ada.Strings.Unbounded;	use Ada.Strings.Unbounded;
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line;

with Y2018.Text.Core; use Y2018.Text.Core; 
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.Msg;
package body Y2018.Text.TestQ is
-- ############################## core.adb ##############################

-- ******* Internal constants ******* --
Border50 : constant String := "--------------------------------------------------";
Frame50 : constant String := "|                                                |";
Point50 : constant String := "..................................................";
Qmark: constant String := "Q>";
DefaultDebugFileName : constant String :="qdebug.lst";

-- ******* Internal definition for functions & procedures ******* --
function htr(s:String) return String;
function get(v:ANKA) return String;
procedure write(s:String);
function Quest(v:ANKA) return Boolean is
begin
	case v is
		when KALLE => return TRUE;
		when FNATTE => return TRUE;
		when KNATTE => return TRUE;
		when TJATTE => return TRUE;
		when KAJSA => return TRUE;
		when KNASE => return TRUE;
		when others => return FALSE;
	end case;
end Quest;
-- ******* Specification of functions & procedures ******* --
procedure write(s:String) is
	fileOut : File_type;
begin
   begin
      Open (File => fileOut,
              Mode => Append_File,
              Name => DefaultDebugFileName);
   exception
      when others =>
         Put_Line (Standard_Error,
                   "Can not append to file named '" & DefaultDebugFileName & "'.");
         Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
         return;
	end;
	Put_Line(fileOut,s);
	Close (fileOut);
end write;

procedure Qwrite(pool:in out Qpool_TY;a:ANKA) is
	fileOut : File_type;
	c: StringVector_TY.Cursor;
begin
	begin
		Open (File => fileOut,
				Mode => Append_File,
				Name => DefaultDebugFileName);
	exception
		when others =>
			Put_Line (Standard_Error,
						"Can not append to file named '" & DefaultDebugFileName & "'.");
			Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
			return;
	end;
	c:=StringVector_TY.First(pool.v);
	while StringVector_TY.has_Element(c) loop
		Put_Line(fileOut,get(a) & To_String(StringVector_TY.Element(c)));
		c:=StringVector_TY.next(c);
	end loop;
	StringVector_TY.Clear(pool.v);
	Close (fileOut);
end Qwrite;
procedure Qwrite(pool:in out Qpool_TY) is begin Qwrite(pool,KALLE); end Qwrite;
procedure Qinit(s:String) is
	fileOut : File_type;
begin
   begin
      Open (File => fileOut,
              Mode => Out_File,
              Name => DefaultDebugFileName);
   exception
      when others =>
         Put_Line (Standard_Error,
                   "Can not append to file named '" & DefaultDebugFileName & "'.");
         Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
         return;
	end;
	Put_Line(fileOut,Border50);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,"|  " & s);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,Border50);
	Close (fileOut);
end Qinit;
procedure QinitH(s:String) is
	fileOut : File_type;
begin
   begin
      Open (File => fileOut,
              Mode => Out_File,
              Name => DefaultDebugFileName);
   exception
      when others =>
         Put_Line (Standard_Error,
                   "Can not append to file named '" & DefaultDebugFileName & "'.");
         Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
         return;
	end;
	Put_Line(fileOut,Border50);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,"|  " & s);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,Border50);
	Ada.Text_IO.Put_Line (Qmark & s);
	Close (fileOut);
end QinitH;
procedure Qblock(s:String) is
begin
	write(Border50);
	write(Frame50);
	write("|  " & s);
	write(Frame50);
	write(Border50);
end Qblock;
procedure QblockH(s:String) is
begin
	write(Border50);
	write(Frame50);
	write("|  " & s);
	write(Frame50);
	write(Border50);
	Ada.Text_IO.Put_Line (Qmark & s);
end QblockH;

procedure Qappend(s:String) is begin write(s);end Qappend;
procedure Qappend(a:ANKA;s:String) is begin if Quest(a) then write(get(a) & s); end if;  end Qappend;

procedure Qappend(s:String;i1:Integer) is begin write(s & "=" & htr(Integer'Image(i1))); end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer) is begin if Quest(a) then write(get(a) & s & "=" & htr(Integer'Image(i1)));end if; end Qappend;

procedure Qappend(s:String;i1:Integer;i2:Integer) is begin write(s & " [" & htr(Integer'Image(i1)) & ":" & htr(Integer'Image(i2)) & "]");end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer) is begin if Quest(a) then write(get(a) & s & " [" & htr(Integer'Image(i1)) & ":" & htr(Integer'Image(i2)) & "]");end if;end Qappend;

procedure Qappend(s:String;b:Boolean) is begin write(s & "=" & Boolean'Image(b));end Qappend;
procedure Qappend(a:ANKA;s:String;b:Boolean) is begin if Quest(a) then write(get(a) & s & "=" & Boolean'Image(b));end if;end Qappend;

procedure Qappend(s:String;i1:Integer;s1:String) is begin write(s & " =" & htr(Integer'Image(i1)) & " :" & s1);end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;s1:String) is begin if Quest(a) then write(get(a) & s & " =" & htr(Integer'Image(i1)) & " :" & s1);end if;end Qappend;

procedure Qappend(s:String;i1:Integer;i2:Integer;s2:String) is begin write(s & " [" & htr(Integer'Image(i1)) & ":" & htr(Integer'Image(i2)) & "] " & s2);end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer;s2:String) is begin if Quest(a) then write(get(a) & s & " [" & htr(Integer'Image(i1)) & ":" & htr(Integer'Image(i2)) & "] " & s2);end if;end Qappend;

procedure Qappend(s:String;wws:Wide_Wide_String) is begin write(s & "=" & UTF.To8(wws));end Qappend;
procedure Qappend(a:ANKA;s:String;wws:Wide_Wide_String) is begin if Quest(a) then write(get(a) & s & "=" & UTF.To8(wws));end if;end Qappend;

procedure Qappend(s:String;c:Wide_Wide_Character) is 
	cs:Wide_Wide_String:=(1=>c);
begin 
	write(s & "=" & Y2018.Text.Core.UTF.to8(cs));
end Qappend;
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character) is 
	cs:Wide_Wide_String:=(1=>c);
begin 
	if Quest(a) then
		write(get(a) & s & "=" & Y2018.Text.Core.UTF.to8(cs));
	end if;
end Qappend;

procedure Qappend(s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer) is
	n:Wide_Wide_String(1..0);
begin
	if f>=wws'First(1) and l<=wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,l-f+1));
		begin
			write(s & "=" & t);
		end;
	elsif f>=wws'First(1) and l>wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,wws'Last(1)-f+1));
			suffix:String:=UTF.To8(Tool.Left(n,l - wws'Last(1),c));
		begin
			write(s & "=" & t & suffix);
		end;
	else
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(1,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
end Qappend;
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer) is begin if Quest(a) then Qappend(get(a) & s,c,wws,f,l);end if;end Qappend;

procedure QappendH(s:String) is begin write(s); Ada.Text_IO.Put_Line (Qmark & s);end QappendH;

procedure Qadd(pool:in out Qpool_TY;s:String) is
begin
	StringVector_TY.Append(pool.v, To_Unbounded_String(s));
end Qadd;

function htr(s:String) return String is
	i:Integer:=1;    
begin
	while i<s'Last loop
		if s(i) /= ' ' then
			exit;
		end if;
		i:=i + 1;
	end loop;
	return s(i..s'Last);
end htr;
function get(v:ANKA) return String is
	TAB: constant String:=(1=>Character'Val(16#9#));
	TABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#));
	TABTABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#),Character'Val(16#9#));
begin
	case v is
		when KALLE =>
			return "";
		when FNATTE =>
			return TAB;
		when KNATTE =>
			return TABTAB;
		when TJATTE =>
			return TABTABTAB;
		when KAJSA =>
			return "!]" & TAB;
		when KNASE =>
			return ".]" & TAB;
		when others => -- X...
			return "";
	end case;
end get;
-- ############################## TestTailQ.adb ##############################
end Y2018.Text.TestQ;
