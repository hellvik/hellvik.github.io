-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- ############################## TestQ.adb ##############################
with Ada.Environment_Variables;
with Ada.Containers.Vectors;
with Ada.Strings.Unbounded;	use Ada.Strings.Unbounded;
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line;
with Ada.Task_Identification; use Ada.Task_Identification;
with GNAT.Time_Stamp;
with Ada.Containers.Ordered_Sets;
with Ada.Strings;
with Ada.Strings.Fixed;
with Ada.Directories;

with Y2018.Text.Core; use Y2018.Text.Core; 
with Y2018.Text.Core.UTF;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.Msg;
package body Y2018.Text.TestQ is
-- ############################## core.adb ##############################

-- ******* Internal constants ******* --
Border50 : constant String := "--------------------------------------------------";
Frame50 : constant String := "|                                                |";
Point50 : constant String := "..................................................";
Qmark: constant String := "Q>";
Qid: constant String := "q";

procedure writeBLK(s:String);
procedure write(a:ANKA;s:String);

procedure openDebug(fileOut :out File_type) is
	DebugFileName: String :=Qid & Ada.Task_Identification.Image(Ada.Task_Identification.Current_Task) & ".lst";
begin
	if Ada.Directories.Exists(DebugFileName) then
		begin
			Open (File => fileOut,
					Mode => Append_File,
					Name => DebugFileName);
		exception
			when others =>
				Put_Line (Standard_Error,
							"2Can not append to file named '" & DebugFileName & "'.");
				Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
				raise;
		end;
	else
		begin
			Create (File => fileOut,
					Mode => Out_File,
					Name => DebugFileName);
		exception
			when others =>
				Put_Line (Standard_Error,
							"2Can not create file named '" & DebugFileName & "'.");
				Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
				raise;
		end;
		Put_Line(fileOut,"TIMESTAMP " & GNAT.Time_Stamp.Current_Time);
	end if;
end openDebug;

procedure clearDebug is
	pwd:String:=Ada.Directories.Current_Directory;
	vsearch:Ada.Directories.Search_Type;
	det:Ada.Directories.Directory_Entry_Type;
	p:String:=Qid & "*.lst";
	vfilter:Ada.Directories.Filter_Type:=(FALSE,TRUE,FALSE); -- Files only
	us:Unbounded_String;

	function less(Left,Right:Unbounded_String) return Boolean is
	begin
		return Left < Right;
	end less;
	function equal(Left,Right:Unbounded_String) return Boolean is
	begin
		return Left = Right;
	end equal;
	package OrderedSet_TY is new Ada.Containers.Ordered_Sets(
		Element_type => Unbounded_String,
		"<"=> less,
		"="=> equal);
	vset: OrderedSet_TY.Set;
	vcur: OrderedSet_TY.Cursor;
begin
	Ada.Directories.Start_Search(vsearch,pwd,p,vfilter);
	while Ada.Directories.More_Entries(vsearch) loop
		Ada.Directories.Get_Next_Entry(vsearch,det);
		case Ada.Directories.Kind(det) is
			when Ada.Directories.Directory => null;
			when Ada.Directories.Ordinary_File =>
				OrderedSet_TY.Insert(vset,Ada.Strings.Unbounded.To_Unbounded_String(Ada.Directories.Simple_Name(det)));
			when others => null;
		end case;
	end loop;
	Ada.Directories.End_Search(vsearch);
	if Integer(OrderedSet_TY.Length(vset)) > 0 then
		vcur:=OrderedSet_TY.First(vset);
		while OrderedSet_TY.Has_Element(vcur) loop
			us:=OrderedSet_TY.Element(vcur);
			if Ada.Directories.Exists(Ada.Strings.Unbounded.To_String(us)) then
				Ada.Directories.Delete_File(Ada.Strings.Unbounded.To_String(us));
			end if;
			OrderedSet_TY.Next(vcur);
		end loop;
	end if;
end clearDebug;

procedure writeBLK(s:String) is
	fileOut : File_type;
begin
	openDebug(fileOut);
	Put_Line(fileOut,Border50);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,"|  " & s);
	Put_Line(fileOut,Frame50);
	Put_Line(fileOut,Border50);
	Close (fileOut);
end writeBLK;

procedure write(a:ANKA;s:String) is
	v:Boolean:=FALSE;
	TAB: constant String:=(1=>Character'Val(16#9#));
	TABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#));
	TABTABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#),Character'Val(16#9#));
begin
	case a is
		when KALLE => v:=TRUE;
		when FNATTE => v:=TRUE;
		when KNATTE => v:=TRUE;
		when TJATTE => v:=TRUE;
		when KAJSA => v:=TRUE;
		when KNASE => v:=TRUE;
		when others => null; -- XKALLE, XFNATTE, XKNATTE, XTJATTE, XKAJSA, XKNASE
	end case;
	if v then
		declare
			fileOut : File_type;
		begin
			openDebug(fileOut);
			case a is
				when KALLE => Put_Line(fileOut,s);
				when FNATTE => Put_Line(fileOut,TAB & s);
				when KNATTE => Put_Line(fileOut,TABTAB & s);
				when TJATTE => Put_Line(fileOut,TABTABTAB & s);
				when KAJSA => Put_Line(fileOut,"!]" & TAB & s);
				when KNASE => Put_Line(fileOut,".]" & TAB & s);
				when XKALLE => Put_Line(fileOut,s);
				when XFNATTE => Put_Line(fileOut,TAB & s);
				when XKNATTE => Put_Line(fileOut,TABTAB & s);
				when XTJATTE => Put_Line(fileOut,TABTABTAB & s);
				when XKAJSA => Put_Line(fileOut,"!]" & TAB & s);
				when others => Put_Line(fileOut,".]" & TAB & s); -- XKNASE
			end case;
			Close (fileOut);
		end;
	end if;
end write;

-- ******* Specification of functions & procedures ******* --
procedure Qinit(s:String) is
begin
	clearDebug;
	writeBLK(s);
end Qinit;

procedure QinitH(s:String) is
begin
	clearDebug;
	writeBLK(s);
	Ada.Text_IO.Put_Line (Qmark & s);
end QinitH;

procedure Qblock(s:String) is
begin
	writeBLK(s);
end Qblock;

procedure QblockH(s:String) is
begin
	writeBLK(s);
	Ada.Text_IO.Put_Line (Qmark & s);
end QblockH;

procedure QappendH(s:String) is begin write(KALLE,s); Ada.Text_IO.Put_Line (Qmark & s);end QappendH;

procedure Qappend(s:String) is begin write(KALLE,s);end Qappend;
procedure Qappend(a:ANKA;s:String) is begin write(a,s); end Qappend;

procedure Qappend(s:String;i1:Integer) is begin write(KALLE,s & "=" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left)); end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer) is begin write(a,s & "=" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left)); end Qappend;

procedure Qappend(s:String;i1:Integer;i2:Integer) is begin write(KALLE,s & " [" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & ":" & Ada.Strings.Fixed.Trim(Integer'Image(i2),Ada.Strings.Left) & "]");end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer) is begin write(a,s & " [" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & ":" & Ada.Strings.Fixed.Trim(Integer'Image(i2),Ada.Strings.Left) & "]");end Qappend;

procedure Qappend(s:String;b:Boolean) is begin write(KALLE,s & "=" & Boolean'Image(b));end Qappend;
procedure Qappend(a:ANKA;s:String;b:Boolean) is begin write(a, s & "=" & Boolean'Image(b));end Qappend;

procedure Qappend(s:String;i1:Integer;s1:String) is begin write(KALLE,s & " =" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & " :" & s1);end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;s1:String) is begin write(a,s & " =" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & " :" & s1);end Qappend;

procedure Qappend(s:String;i1:Integer;i2:Integer;s2:String) is begin write(KALLE,s & " [" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & ":" & Ada.Strings.Fixed.Trim(Integer'Image(i2),Ada.Strings.Left) & "] " & s2);end Qappend;
procedure Qappend(a:ANKA;s:String;i1:Integer;i2:Integer;s2:String) is begin write(a,s & " [" & Ada.Strings.Fixed.Trim(Integer'Image(i1),Ada.Strings.Left) & ":" & Ada.Strings.Fixed.Trim(Integer'Image(i2),Ada.Strings.Left) & "] " & s2);end Qappend;

procedure Qappend(s:String;wws:Wide_Wide_String) is begin write(KALLE,s & "=" & UTF.To8(wws));end Qappend;
procedure Qappend(a:ANKA;s:String;wws:Wide_Wide_String) is begin write(a,s & "=" & UTF.To8(wws));end Qappend;

procedure Qappend(s:String;c:Wide_Wide_Character) is 
	cs:Wide_Wide_String:=(1=>c);
begin 
	write(KALLE,s & "=" & Y2018.Text.Core.UTF.to8(cs));
end Qappend;
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character) is 
	cs:Wide_Wide_String:=(1=>c);
begin 
		write(a,s & "=" & Y2018.Text.Core.UTF.to8(cs));
end Qappend;

procedure Qappend(s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer) is
	n:Wide_Wide_String(1..0);
begin
	if f>=wws'First(1) and l<=wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,l-f+1));
		begin
			write(KALLE,s & "=" & t);
		end;
	elsif f>=wws'First(1) and l>wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,wws'Last(1)-f+1));
			suffix:String:=UTF.To8(Tool.Left(n,l - wws'Last(1),c));
		begin
			write(KALLE,s & "=" & t & suffix);
		end;
	else
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(1,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
end Qappend;
procedure Qappend(a:ANKA;s:String;c:Wide_Wide_Character;wws:Wide_Wide_String;f:Integer;l:Integer) is
	n:Wide_Wide_String(1..0);
begin
	if f>=wws'First(1) and l<=wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,l-f+1));
		begin
			write(a,s & "=" & t);
		end;
	elsif f>=wws'First(1) and l>wws'Last(1) then
		declare
			t:String:=UTF.To8(Tool.Substr(wws,f,wws'Last(1)-f+1));
			suffix:String:=UTF.To8(Tool.Left(n,l - wws'Last(1),c));
		begin
			write(a,s & "=" & t & suffix);
		end;
	else
		raise Program_Error with Y2018.Text.Core.Tool.getMsg(1,Y2018.Text.Core.Msg.K,Y2018.Text.Core.Msg.E);
	end if;
end Qappend;

-- ############################## TestTailQ.adb ##############################
end Y2018.Text.TestQ;
