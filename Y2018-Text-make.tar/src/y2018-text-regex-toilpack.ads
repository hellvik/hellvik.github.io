-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## ToilPack.ads ##############################
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Jets.PatternPack; 
with Y2018.Text.Jets.MatchPack;
with Ada.Finalization; use Ada.Finalization;
package Y2018.Text.Regex.ToilPack is
	type Toil_TY is tagged limited private;
	procedure populateToil(
		t : in out Toil_TY; 
		jAC:Y2018.Text.Jets.PatternPack.Pattern_AC;
		m : Y2018.Text.Jets.MatchPack.Match_TY;
		us : Unbounded_Wide_Wide_String;
		ux : Unbounded_Wide_Wide_String;
		nextPos:Integer;
		option: Y2018.Text.Regex.G_Option);

	function Match (t :in out Toil_TY) return Y2018.Text.Regex.G_Vector.Vector;
	
	function has_Toil (t : Toil_TY) return Boolean;	
	procedure next (t : in out Toil_TY);
	function tail (t : Toil_TY) return Wide_Wide_String;

	procedure Finalize(t: in out Toil_TY);
	procedure Initialize(t: in out Toil_TY);

private
	
	type Toil_TY is new Limited_Controlled with
		record
		jAC: Y2018.Text.Jets.PatternPack.Pattern_AC; -- << FOREIGN
		m : Y2018.Text.Jets.MatchPack.Match_TY;
		us : Unbounded_Wide_Wide_String; -- Orginal string
		ux : Unbounded_Wide_Wide_String; -- String for match-operators
		nextPos : Integer;
		option : Y2018.Text.Regex.G_Option;
	end record;
end Y2018.Text.Regex.ToilPack;
	
