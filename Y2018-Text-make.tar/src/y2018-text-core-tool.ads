-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
with Ada.Strings.UTF_Encoding;
with Ada.Strings.UTF_Encoding.Conversions;
with Ada.Strings.UTF_Encoding.Wide_Wide_Strings; --use Ada.Strings.UTF_Encoding.Wide_Wide_Strings;
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;

with Y2018.Text.Core.GC;
with Y2018.Text.Core.ULTcase;
package Y2018.Text.Core.Tool is
	function To_Hex8(v:Wide_Wide_Character) return String;
	function To_Hex8(v:Character) return String;
	function To_Hex8(v:Integer) return String;
	function To_Hex8W(v:Wide_Wide_Character) return Wide_Wide_String;
	function To_Hex8W(v:Character) return Wide_Wide_String;
	function To_Hex8W(v:Integer) return Wide_Wide_String;
function To_HexX(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexX(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexX(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexX(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexX(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexX(s:Unbounded_String) return Unbounded_String;
function To_HexU(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexU(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexU(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexU(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexU(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexU(s:Unbounded_String) return Unbounded_String;
function To_HexV(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexV(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexV(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexV(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexV(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexV(s:Unbounded_String) return Unbounded_String;
function To_HexY(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexY(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexY(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexY(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexY(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexY(s:Unbounded_String) return Unbounded_String;
function Substr(s:Wide_Wide_String;pos:Integer;len:Integer) return Wide_Wide_String;
function Substr(s:Wide_Wide_String;pos:Integer) return Wide_Wide_String;
	function Substr(S:Unbounded_Wide_Wide_String;pos:Integer;len:Integer) return Unbounded_Wide_Wide_String;
	function Substr(S:Unbounded_String;pos:Integer;len:Integer) return Unbounded_String;
	function Substr(s:Unbounded_Wide_Wide_String;pos:Integer) return Unbounded_Wide_Wide_String;
	function Substr(s:Unbounded_String;pos:Integer) return Unbounded_String;
function Is_Valid(s:Wide_Wide_String) return Boolean;
	function Is_Valid(s:Unbounded_Wide_Wide_String) return Boolean;
	function Is_Valid(s:Unbounded_String) return Boolean;
function LeftStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function LeftStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function LeftStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function LeftStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function LeftStrip(source:Unbounded_String) return Unbounded_String;
function RightStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function RightStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function RightStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function RightStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function RightStrip(source:Unbounded_String) return Unbounded_String;
function Right(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
	function Right(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Right(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
function Left(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
	function Left(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Left(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
function Center(S:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
	function Center(S:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Center(S:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
function Strip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function Strip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Strip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function Strip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function Strip(source:Unbounded_String) return Unbounded_String;
function To8(v:Boolean) return String;
function To32(v:Boolean) return Wide_Wide_String;
function To8(v:Integer) return String;
function To32(v:Integer) return Wide_Wide_String;
function Get_GC(c:Wide_Wide_Character) return Wide_Wide_String;
function Get_UC(c:Wide_Wide_Character) return Wide_Wide_Character;
function Get_LC(c:Wide_Wide_Character) return Wide_Wide_Character;
function Get_TC(c:Wide_Wide_Character) return Wide_Wide_Character;
function To_TC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_TC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_TC(instr:Unbounded_String) return Unbounded_String;
function To_LC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_LC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_LC(instr:Unbounded_String) return Unbounded_String;
function To_UC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_UC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_UC(instr:Unbounded_String) return Unbounded_String;
end Y2018.Text.Core.Tool;
