-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
package Y2018.Text.Core.C32 is
	C32_1_LOW: constant Integer := 16#00000000#; 
	C32_1_HIGH: constant Integer := 16#0000007F#;
	C32_2_LOW: constant Integer := 16#00000080#; 
	C32_2_HIGH: constant Integer := 16#000007FF#;
	C32_3_LOW: constant Integer := 16#00000800#; 
	C32_3_HIGH: constant Integer := 16#00000FFF#;
	C32_4_LOW: constant Integer := 16#00001000#; 
	C32_4_HIGH: constant Integer := 16#0000CFFF#;
	C32_5_LOW: constant Integer := 16#0000D000#; 
	C32_5_HIGH: constant Integer := 16#0000D7FF#;
	C32_6_LOW: constant Integer := 16#0000E000#; 
	C32_6_HIGH: constant Integer := 16#0000FFFF#;
	C32_7_LOW: constant Integer := 16#00010000#; 
	C32_7_HIGH: constant Integer := 16#0003FFFF#;
	C32_8_LOW: constant Integer := 16#00040000#; 
	C32_8_HIGH: constant Integer := 16#000FFFFF#;
	C32_9_LOW: constant Integer := 16#00100000#; 
	C32_9_HIGH: constant Integer := 16#0010FFFF#;
end Y2018.Text.Core.C32;
