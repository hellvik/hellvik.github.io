-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## ToilPack.adb ##############################
--
with Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings.Unbounded;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Core.Tool;
with Y2018.Text.Core.UTF;
with Y2018.Text.Jets.PatternPack; use Y2018.Text.Jets.PatternPack; 
with Y2018.Text.Jets.MatchPack; use Y2018.Text.Jets.MatchPack; 
with Y2018.Text.Jets.RegexTool;
with GNAT.Source_Info;
package body Y2018.Text.Regex.ToilPack is
procedure populateToil(
	t : in out Toil_TY; 
	jAC:Y2018.Text.Jets.PatternPack.Pattern_AC;
	m : Y2018.Text.Jets.MatchPack.Match_TY;
	us : Unbounded_Wide_Wide_String;
	ux : Unbounded_Wide_Wide_String;
	nextPos:Integer;
	option: G_Option
	) is
begin
	t.jAC:=jAC;
	t.m:=m;
	t.us:=us;
	t.ux:=ux;
	t.nextPos:=nextPos;
	t.option:=option;
end populateToil;
	
function Match (t :in out Toil_TY) return Y2018.Text.Regex.G_Vector.Vector is
begin
	if has_Toil(t) = FALSE then
		return Y2018.Text.Regex.Empty_G_Vector;
	else
		declare
			cnt:Integer:=Y2018.Text.Jets.MatchPack.count(t.m);
			i:Integer:=0;
			nullString:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
			vcontainer: Y2018.Text.Regex.G_Vector.Vector;
			e:Y2018.Text.Regex.G_Element;
			vom:Y2018.Text.Jets.MatchPack.ValueOfMatch;
		begin
			while i < cnt loop
				if Y2018.Text.Jets.MatchPack.hasMatch(t.m,i) then
					e.exists:=TRUE;
					vom:=Y2018.Text.Jets.MatchPack.getMatch2(t.m,i);
					e.v:=Y2018.Text.Core.Tool.substr(t.us,vom.f,vom.l - vom.f + 1);
				else
					e.exists:=FALSE;
					e.v:=nullString;
				end if;
				G_Vector.Append(vcontainer,e);
				i:=i+1;
			end loop;
			return vcontainer;
		end;
	end if;
end Match;

function has_Toil (t : Toil_TY) return Boolean is
begin
	if t.jac = null then
		return FALSE;
	elsif t.nextPos = 0 then
		return FALSE;
	else
		return TRUE;
	end if;
end has_Toil;
	
procedure next (t : in out Toil_TY) is
	nextPos:Integer;
	j:Y2018.Text.Jets.MatchPack.Match_TY;
begin
	if has_Toil(t) and t.nextPos <= Length(t.ux) then
		if Jets.PatternPack.matches(t.jAC,t.nextPos,nextPos,Ada.Strings.Wide_Wide_Unbounded.To_Wide_Wide_String(t.ux),j) then
			t.m:=j;
			t.nextPos:=nextPos;
		else
			t.jAC := null;
			t.m := j;
			t.us := Null_Unbounded_Wide_Wide_String;
			t.ux := Null_Unbounded_Wide_Wide_String;
			t.nextPos := 0;
			t.option := G_NONE; 
		end if;
	else
		t.jAC := null;
	end if;
end next;

function tail (t : Toil_TY) return Wide_Wide_String is
	empty:Wide_Wide_String(1..0);
	lst:Integer;
begin
	if has_Toil(t) = FALSE then
		return empty;
	end if;
	lst:=Ada.Strings.Wide_Wide_Unbounded.Length(t.ux);
	if lst < t.nextPos then
		return empty;
	end if;
	declare
		g:Wide_Wide_String:=Ada.Strings.Wide_Wide_Unbounded.Slice(t.us,t.nextPos,lst);
		len:Integer:=g'Last(1) - g'First(1) + 1;
		r:Wide_Wide_String(1 .. len);
	begin
		for i in 1 .. len loop
			r(i) := g(g'First + i - 1);
		end loop;
		return r;
	end;
end tail;

procedure Finalize(t: in out Toil_TY) is
begin
	null;
end Finalize;
procedure Initialize(t: in out Toil_TY) is
	m:Y2018.Text.Jets.MatchPack.Match_TY;
begin
	t.jAC:=null;
	t.m:=m;
	t.us:=Null_Unbounded_Wide_Wide_String;
	t.ux:=Null_Unbounded_Wide_Wide_String;
	t.nextPos:=0;
	t.option:=G_NONE;
end Initialize;
end Y2018.Text.Regex.ToilPack;


