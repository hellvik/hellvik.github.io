-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- ############################## MatchPack.ads ##############################
with Ada.Containers;
with Ada.Containers.Ordered_Maps;
with Y2018.Text.Jets.RangeVectorPack;
use Y2018.Text.Jets.RangeVectorPack;
with Y2018.Text.Jets.RegexTool; use Y2018.Text.Jets.RegexTool;
package Y2018.Text.Jets.MatchPack is
	type Match is tagged private;
	type Match_AC is access Match;
-- ############################## MatchPackZei.ads ##############################
	function MatchID2RE_ID_less(Left, Right : MatchID) return Boolean;
	function MatchID2RE_ID_equal(Left, Right : RE_ID) return Boolean;
	package MatchID2RE_ID_TY is new Ada.Containers.Ordered_Maps(
		Key_Type=> MatchID,
		Element_Type=> RE_ID,
		"<"=> MatchID2RE_ID_less,
		"="=> MatchID2RE_ID_equal);

	function RE_ID2MatchID_less(Left, Right : RE_ID) return Boolean;
	function RE_ID2MatchID_equal(Left, Right : MatchID) return Boolean;
	package RE_ID2MatchID_TY is new Ada.Containers.Ordered_Maps(
		Key_Type=> RE_ID,
		Element_Type=> MatchID,
		"<"=> RE_ID2MatchID_less,
		"="=> RE_ID2MatchID_equal);

	type KElem is record
		c:RE_Elem_AC;
		f:Integer;
		l:integer;
	end record;
	type ValueOfMatch is record
		f:Integer;
		l:integer;
	end record;
		
	function RE_ID2KElem_less(Left,Right:RE_ID) return Boolean;
	function RE_ID2KElem_equal(Left,Right:KElem) return Boolean;
	
	package RE_ID2KElem_TY is new Ada.Containers.Ordered_Maps(
		Key_Type=> RE_ID,
		Element_Type=> KElem,
		"<"=> RE_ID2KElem_less,
		"="=> RE_ID2KElem_equal);
	
	function new_Match return Match_AC;
	procedure insert(matchValue:Match_AC;s:Unbounded_Wide_Wide_String;f:Integer;l:Integer;re:RE_Elem_AC);
	function getMatch2(matchValue:Match_AC;mid:MatchID) return ValueOfMatch;
	function hasMatch(matchValue:Match_AC;mid:MatchID) return Boolean;
	function count(matchValue:Match_AC) return Integer;
	procedure delete(matchValue:Match_AC;trackcount:Integer);
	procedure merge(target_matchValue:Match_AC;source_matchValue:Match_AC);
-- ############################## MatchPackMatch.adb ##############################
	private type Match is tagged
	record
		v: RE_ID2KElem_TY.map;
		map:MatchID2RE_ID_TY.map;
	end record;

-- ############################## MatchPackTail.adb ##############################
end Y2018.Text.Jets.MatchPack;
