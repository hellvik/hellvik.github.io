-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200724181916.
-- ############################## Regex.ads ##############################
with Ada.Containers.Vectors;
with Ada.Strings.Wide_Wide_Unbounded;
package Y2018.Text.Regex is
	type G_Option is (G_NONE,G_UPPERCASE);
	type G_Element is
		record
			exists:Boolean;
			v:Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String;
		end record;
	package G_Vector is new Ada.Containers.Vectors(Natural,G_Element);
	Empty_G_Vector : G_Vector.Vector;
-- ############################## RegexTail.adb ##############################
end Y2018.Text.Regex;
