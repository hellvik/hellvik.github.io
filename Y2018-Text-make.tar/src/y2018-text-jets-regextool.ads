-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
-- ############################## RegexTool.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Containers;
with Ada.Containers.Vectors;
with Ada.Containers.Ordered_Maps;
with Y2018.Text.Jets.RangeVectorPack;
package Y2018.Text.Jets.RegexTool is
-- ############################## re.ads ##############################
subtype RE_ID is  Integer range 0 .. Integer'Last;
NO_RE_ID: constant RE_ID := 0;
FIRST_RE_ID: constant RE_ID := 1;
type RE_Elem;
type RE_Elem_AC is access RE_Elem;
type RE_ARR is array(Integer range <>) of RE_Elem_AC;

type RE_Elem (V : REQ_TY) is
	record
		id : RE_ID;
		left : RE_Elem_AC;
		right : RE_Elem_AC;
		case V is
			when REQ_BEGIN =>
				begin_circumflex : Boolean;
				begin_dollar : Boolean;
				begin_up : RE_Elem_AC; -- null if on base line
				begin_down : RE_Elem_AC;
				begin_trackcount: Integer;
			when REQ_CHAR =>
				char_value : Wide_Wide_Character;
				char_negative : Boolean;
				char_min : Integer; -- 0:Integer'Last
				char_max : Integer;
				char_greedy : Boolean;
			when REQ_PERIOD =>
				period_min : Integer; -- 0:Integer'Last
				period_max : Integer;
				period_greedy : Boolean;
			when REQ_CLASS_ELEM => -- Do not exists in RegexPattern
				class_elem_min : Integer; -- 0:Integer'Last
				class_elem_max : Integer;
				class_elem_greedy : Boolean;
				class_elem_pos : RE_Elem_AC;
				class_elem_neg : RE_Elem_AC;
			when REQ_CLASS => -- Exists only in RegexPattern
				class_min : Integer; -- 0:Integer'Last
				class_max : Integer;
				class_greedy : Boolean;
				class_pos : RangeVectorPack.RangeVector;
				class_neg : RangeVectorPack.RangeVector;
			when REQ_CLASS_CHAR => -- Do not exists in RegexPattern 
				class_char_negative : Boolean;
				class_char_value : Wide_Wide_Character; -- no meta characters
			when REQ_CLASS_RANGE => -- Do not exists in RegexPattern
				class_range_negative : Boolean;
				class_range_first : Wide_Wide_Character;
				class_range_last : Wide_Wide_Character;
			when REQ_CLASS_GC => -- Do not exists in RegexPattern
				class_gc_negative : Boolean;
				class_gc_value : Wide_Wide_String(1..2);
			when REQ_CLASS_GCU => -- Do not exists in RegexPattern
				class_gcu_negative : Boolean;
				class_gcu_value : Wide_Wide_Character;
			when REQ_CLASS_OTHER => -- Do not exists in RegexPattern
				class_other_negative : Boolean;
				class_other_value : Wide_Wide_Character;
			when REQ_PALCAP => -- ( )
				palcap_min : Integer; -- 0:Integer'Last
				palcap_max : Integer;
				palcap_greedy : Boolean;
				palcap_up : RE_Elem_AC; -- null if on base line
				palcap_down : RE_Elem_AC;
				palcap_trackcount: Integer;
				palcap_begin: RE_Elem_AC;
			when REQ_PAL => -- (?: )
				pal_dummy: Boolean;
				pal_min : Integer; -- 0:Integer'Last
				pal_max : Integer;
				pal_greedy : Boolean;
				pal_up : RE_Elem_AC; -- null if on base line
				pal_down : RE_Elem_AC;
			when REQ_UPDOWN =>
				updown_up : RE_Elem_AC; -- null if on base line
				updown_down : RE_Elem_AC;
			when REQ_POS =>
				pos_up : RE_Elem_AC; -- null if on base line
				pos_down : RE_Elem_AC;
			when REQ_NEG =>
				neg_up : RE_Elem_AC; -- null if on base line
				neg_down : RE_Elem_AC;
			when REQ_NULL => -- ** Do not exists **
				null_dummy: Boolean;
		end case;
	end record;
-- ############################## ToolCommon.ads ##############################
	subtype MatchID is  Integer range 0 .. Integer'Last;

	NO_MatchID: constant MatchID :=Integer'Last;

	function To_Unbounded_Wide_Wide_String(s : Wide_Wide_String;Low:Integer;High:Integer) return Unbounded_Wide_Wide_String;
	function getMin(this:RE_Elem_AC) return Integer;
	function getMax(this:RE_Elem_AC) return Integer;
	function getGreedy(this:RE_Elem_AC) return Boolean;
	function isInMCHAR(c:Wide_Wide_Character) return Boolean;
-- ############################## metaZwei.ads ##############################
	function ParseStringM(s:Wide_Wide_String) return Integer; -- not needed in Jets. Based on single back-slash 
	function QuoteMetaM(s:Wide_Wide_String) return Wide_Wide_String; -- not needed in Jets.

-- ############################## reFunc.ads ##############################
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY) return RE_ELEM_AC;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC) return RE_ELEM_AC;
function CREATE_RE(id:in out RE_ID;reqv: REQ_TY;vleft:RE_Elem_AC;vup:RE_Elem_AC) return RE_ELEM_AC;
procedure Init_RE(y :in out RE_ELEM_AC);
function New_RangeVector(actual:RE_Elem_AC) return RangeVectorPack.RangeVector;
-- ############################## reList.ads ##############################
-- ############################## RegexToolTail.adb ##############################
end Y2018.Text.Jets.RegexTool;
