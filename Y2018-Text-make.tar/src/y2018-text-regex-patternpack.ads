-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190407173029.
-- ############################## PatternPack.ads ##############################
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Jets.PatternPack; 
with Y2018.Text.Jets.MatchPack;
with Y2018.Text.Regex.MatchPack;
package Y2018.Text.Regex.PatternPack is
	type Pattern is tagged private;
	type Pattern_AC is access Pattern;
	type G_Cursor is private;
	type G_Option is (G_NONE,G_UPPERCASE);

	G_No_Element : constant G_Cursor;
   function has_Element (Position : G_Cursor) return Boolean;	
	function matches (ptc:Pattern_AC;s : Wide_Wide_String) return G_Cursor;
	function next (Position : G_Cursor) return G_Cursor;
	function element (Position : G_Cursor) return Y2018.Text.Regex.MatchPack.Match_AC;
	function source (Position : G_Cursor) return Wide_Wide_String;
	function compile(s : Wide_Wide_String) return Pattern_AC;
	function compile(s : Wide_Wide_String;option :  G_Option) return Pattern_AC;
	function toString(ptc:Pattern_AC) return Wide_Wide_String;
	function QuoteMeta(s:Wide_Wide_String) return Wide_Wide_String;
	function ParseString(s:Wide_Wide_String) return Boolean;

-- ############################## PatternPackPattern.ads ##############################
private
	
	type G_Cursor is record
		ptc : Pattern_AC:=null;
		m : Y2018.Text.Jets.MatchPack.Match_AC:=null;
		us : Unbounded_Wide_Wide_String:=Null_Unbounded_Wide_Wide_String;
		ux : Unbounded_Wide_Wide_String:=Null_Unbounded_Wide_Wide_String;
		nextPos : Integer:=0;
	end record;

	G_No_Element : constant G_Cursor:=(ptc=> null, m=> null, us=> Null_Unbounded_Wide_Wide_String, ux=> Null_Unbounded_Wide_Wide_String, nextPos=>0);

	type Pattern is tagged
	record
		jAC: Y2018.Text.Jets.PatternPack.Pattern_AC;
		option :  G_Option;
		sm:Unbounded_Wide_Wide_String;
	end record;
-- ############################## PatternPackTail.adb ##############################
end Y2018.Text.Regex.PatternPack;
