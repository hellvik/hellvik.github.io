-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## PatternPack.ads ##############################
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Finalization; use Ada.Finalization;
with Y2018.Text.Jets.PatternPack; 
with Y2018.Text.Regex.ToilPack;
with Y2018.Text.Regex;
package Y2018.Text.Regex.PatternPack is
	type Pattern_TY is tagged limited private;
	procedure Toil (t:in out Y2018.Text.Regex.ToilPack.Toil_TY;p:Pattern_TY;s : Wide_Wide_String);
	procedure Pattern(p:in out Y2018.Text.Regex.PatternPack.Pattern_TY;s : Wide_Wide_String);
	procedure Pattern(p:in out Y2018.Text.Regex.PatternPack.Pattern_TY;s : Wide_Wide_String;option :  Y2018.Text.Regex.G_Option);
	function ToString(p:Pattern_TY) return Wide_Wide_String;
	function QuoteMeta(s:Wide_Wide_String) return Wide_Wide_String;
	function ParseString(s:Wide_Wide_String) return Boolean;
	function size(p:Pattern_TY) return Integer;
	function option(p:Pattern_TY) return Y2018.Text.Regex.G_Option;

	procedure Finalize(p: in out Pattern_TY);
	procedure Initialize(p: in out Pattern_TY);

private
	
	type Pattern_TY is new Limited_Controlled with
	record
		jAC: Y2018.Text.Jets.PatternPack.Pattern_AC; -- << OWNER
		option :  Y2018.Text.Regex.G_Option;
		sm:Unbounded_Wide_Wide_String;
	end record;
end Y2018.Text.Regex.PatternPack;
	
