-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## TestR.adb ##############################
with Ada.Strings.Unbounded;	use Ada.Strings.Unbounded;
with Ada.Text_IO; use Ada.Text_IO;
with Ada.Command_Line;
with Ada.Task_Identification; use Ada.Task_Identification;
with GNAT.Time_Stamp;
with Ada.Strings;
with Ada.Strings.Fixed;
with Ada.Directories;
with GNAT.Source_Info;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
-- with DSECT;
package body Y2018.Text.TestR is
-- ############################## core.adb ##############################
-- ******* Internal constants ******* --
Qmark: constant String := "Q>";
Qid: constant String := "q";

procedure write(a:ANKA;s:String);

procedure openDebug(fileOut :out File_type) is
	DebugFileName: String :=Qid + Ada.Task_Identification.Image(Ada.Task_Identification.Current_Task) + ".lst";
begin
	if Ada.Directories.Exists(DebugFileName) then
		begin
			Open (File => fileOut,
					Mode => Append_File,
					Name => DebugFileName);
		exception
			when others =>
				Put_Line (Standard_Error,
							"3Can not append to file named '" + DebugFileName + "'.");
				Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
				raise;
		end;
	else
		begin
			Create (File => fileOut,
					Mode => Out_File,
					Name => DebugFileName);
		exception
			when others =>
				Put_Line (Standard_Error,
							"3Can not create file named '" + DebugFileName + "'.");
				Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
				raise;
		end;
		Put_Line(fileOut,"TIMESTAMP " + GNAT.Time_Stamp.Current_Time);
	end if;
end openDebug;

procedure write(a:ANKA;s:String) is
	TAB: constant String:=(1=>Character'Val(16#9#));
	TABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#));
	TABTABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#),Character'Val(16#9#));
	fileOut : File_type;
begin
	openDebug(fileOut);
	case a is
		when KALLE => Put_Line(fileOut,s);
		when FNATTE => Put_Line(fileOut,TAB + s);
		when KNATTE => Put_Line(fileOut,TABTAB + s);
		when TJATTE => Put_Line(fileOut,TABTABTAB + s);
		when KAJSA => Put_Line(fileOut,"!]" + TAB + s);
		when KNASE => Put_Line(fileOut,".]" + TAB + s);
		when others => null; --Put_Line(fileOut,s);
	end case;
	Close (fileOut);
end write;
procedure write(a:ANKA;sa:Unbounded_Wide_Wide_String_AA) is
	TAB: constant String:=(1=>Character'Val(16#9#));
	TABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#));
	TABTABTAB: constant String:=(Character'Val(16#9#),Character'Val(16#9#),Character'Val(16#9#));
	fileOut : File_type;
begin
	openDebug(fileOut);
	for i in sa'First .. sa'Last loop
		case a is
			when KALLE => Put_Line(fileOut,"" + sa(i));
			when FNATTE => Put_Line(fileOut,TAB + sa(i));
			when KNATTE => Put_Line(fileOut,TABTAB + sa(i));
			when TJATTE => Put_Line(fileOut,TABTABTAB + sa(i));
			when KAJSA => Put_Line(fileOut,"!]" + TAB + sa(i));
			when KNASE => Put_Line(fileOut,".]" + TAB + sa(i));
			when others => null; --Put_Line(fileOut,s);
		end case;
	end loop;
	Close (fileOut);
end write;

function strsubst(s:String;t:String;r:String) return String is
	us:Unbounded_String;
	si:Integer:=s'First(1);
	sii:Integer:=s'First(1) - 1;
	ti:Integer;
begin
	while si <= s'Last(1) loop
		if s(si) = t(t'First(1)) then
			ti:=t'First(1);
			sii:=si;
			while ti <= t'Last(1) and sii <= s'Last(1) loop
				if t(ti) = s(sii) then
					null;
				else
					sii:= s'First(1) - 1;
					exit;
				end if;
				sii:=sii + 1;
				ti:=ti + 1;
			end loop;
		else
			null;
		end if;
		if sii > s'First(1) then
			append(us,r);
			si:=sii;
			sii:=s'First(1) - 1;
		else
			append(us,s(si));
			si:=si + 1;
		end if;
	end loop;
	return To_String(us);
end strsubst;

-- ******* Specification of functions & procedures ******* --
procedure Qappend(a:ANKA;head:String;sa:Unbounded_Wide_Wide_String_AA) is 
begin
	if sa'Length = 0 then
		write(a,head + "[Empty]");
	else
		declare
			r:Unbounded_Wide_Wide_String_AA(sa'First .. sa'Last);
		begin
			for i in sa'First .. sa'Last loop
				r(i):=NUW + head + "[" + Integer'Image(i) + "] " + sa(i);
			end loop;
			write(a,r);
		end;
	end if;
end Qappend;
procedure Qappend(a:ANKA;head:String;s:String;p:Pattern_TY) is 
begin 
	declare
		r:Unbounded_Wide_Wide_String_AA(0 .. (size(p) - 1));
	begin
		if matchTo(s,p,r) then
			Qappend(a,head,r);
		else
			write(a,head + "[No Match]");
		end if;
	end;
end Qappend;
-- ############################## TestTailR.adb ##############################
end Y2018.Text.TestR;
