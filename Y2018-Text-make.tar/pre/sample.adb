-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20190531152414.
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.Tool;
with Y2018.Text.Regex.PatternPack; 
-- with DSECT;
procedure Sample is 
	s:Unbounded_String;
	HULK:constant String:="Hulk";
	r:Tool.M_AAAC;
	p:Y2018.Text.Regex.PatternPack.Pattern_AC:=
		Y2018.Text.Regex.PatternPack.compile(
			"^(.)([\w]+)"W,
			Y2018.Text.Regex.PatternPack.G_NONE
		);
begin
	Put_Line ("--- Begin of Sample ---");
	s:=NUS + HULK + "ior"W;
	Put_Line ("" + "WIDE_WIDE "W + s);
	if Tool.matchTo("What",p,r) then
		for i in r'First .. r'Last loop
			Put_Line (
				">" + Integer'Image(i) +
				"=" + r(i).all + "<"
			);
		end loop;
	end if;
   Put_Line ("*** End of Sample ***");
end Sample;
