with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
--with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
-- with DSECT;
procedure Sample is 
	EXODUS:constant String:="Och detta är namnen på ";
	p:Pattern_TY;
begin
	Pattern(p,"^.*?(I[\w]+).*?([\w]+)"W);
	Put_Line ("--- Begin of Sample ---");
	declare
		r:Unbounded_Wide_Wide_String_AA(0 .. (size(p) - 1));
	begin
		if matchTo(EXODUS + "Israels söner"W,p,r) then
			for i in r'First .. r'Last loop
				Put_Line (">" + Integer'Image(i) + "=" + r(i) + "<");
			end loop;
		end if;
	end;
	Put_Line ("*** End of Sample ***");
end Sample;
