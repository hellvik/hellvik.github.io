-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## Tool.ads ##############################
with Ada.Strings.UTF_Encoding;
with Ada.Strings.UTF_Encoding.Conversions;
with Ada.Strings.UTF_Encoding.Wide_Wide_Strings; --use Ada.Strings.UTF_Encoding.Wide_Wide_Strings;
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;

with Y2018.Text.Core.GC;
with Y2018.Text.Core.ULTcase;
with Y2018.Text.Regex.PatternPack;
with Y2018.Text.Regex.ToilPack;

package Y2018.Text.Wide.Tool is
	
-- ############################## hex.ads ##############################
	function To_Hex8(v:Wide_Wide_Character) return String;
	function To_Hex8(v:Character) return String;
	function To_Hex8(v:Integer) return String;
	function To_Hex8W(v:Wide_Wide_Character) return Wide_Wide_String;
	function To_Hex8W(v:Character) return Wide_Wide_String;
	function To_Hex8W(v:Integer) return Wide_Wide_String;
-- ############################## hexX.ads ##############################
function To_HexX(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexX(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexX(S:String;padding:Wide_Wide_Character) return String;
	function To_HexX(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexX(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexX(s:String) return String;
	function To_HexX(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexX(s:Unbounded_String) return Unbounded_String;
-- ############################## hexU.ads ##############################
function To_HexU(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexU(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexU(S:String;padding:Wide_Wide_Character) return String;
	function To_HexU(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexU(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexU(s:String) return String;
	function To_HexU(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexU(s:Unbounded_String) return Unbounded_String;
-- ############################## hexV.ads ##############################
function To_HexV(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexV(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexV(S:String;padding:Wide_Wide_Character) return String;
	function To_HexV(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexV(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexV(s:String) return String;
	function To_HexV(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexV(s:Unbounded_String) return Unbounded_String;
-- ############################## hexW.ads ##############################
function To_HexY(s:Wide_Wide_String) return Wide_Wide_String;
function To_HexY(s:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
	function To_HexY(S:String;padding:Wide_Wide_Character) return String;
	function To_HexY(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function To_HexY(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function To_HexY(s:String) return String;
	function To_HexY(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_HexY(s:Unbounded_String) return Unbounded_String;
-- ############################## 32.ads ##############################
function Substr(s:Wide_Wide_String;pos:Integer;len:Integer) return Wide_Wide_String;
function Substr(s:Wide_Wide_String;pos:Integer) return Wide_Wide_String;
function Substr(s:String;pos:Integer;len:Integer) return String;
function Substr(s:String;pos:Integer) return String;
	function Substr(S:Unbounded_Wide_Wide_String;pos:Integer;len:Integer) return Unbounded_Wide_Wide_String;
	function Substr(S:Unbounded_String;pos:Integer;len:Integer) return Unbounded_String;
	function Substr(s:Unbounded_Wide_Wide_String;pos:Integer) return Unbounded_Wide_Wide_String;
	function Substr(s:Unbounded_String;pos:Integer) return Unbounded_String;
function ReIndex(s:Wide_Wide_String;rfirst:Integer) return Wide_Wide_String;
function ReIndex(s:String;rfirst:Integer) return String;
function ReIndex(s:Unbounded_Wide_Wide_String;rfirst:Integer) return Unbounded_Wide_Wide_String;
	function ReIndex(s:Unbounded_String;rfirst:Integer) return Unbounded_String;
function Is_Valid(s:Wide_Wide_String) return Boolean;
	function Is_Valid(s:String) return Boolean;
	function Is_Valid(s:Unbounded_Wide_Wide_String) return Boolean;
	function Is_Valid(s:Unbounded_String) return Boolean;
-- ############################## 32comp.ads ##############################
function CmpS(first:Wide_Wide_String;second:Wide_Wide_String) return Integer;
function CmpS(first:String;second:String) return Integer;
-- ############################## 32shift.ads ##############################
function Right(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
function Right(source:String;length:Integer;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function Right(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Right(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
function LeftStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
function LeftStrip(S:String;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function LeftStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function LeftStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function LeftStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function LeftStrip(source:Unbounded_String) return Unbounded_String;
function Strip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
function Strip(S:String;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function Strip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Strip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function Strip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function Strip(source:Unbounded_String) return Unbounded_String;
function Left(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
function Left(source:String;length:Integer;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function Left(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Left(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
function RightStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String;
function RightStrip(S:String;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function RightStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function RightStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String;
	function RightStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function RightStrip(source:Unbounded_String) return Unbounded_String;
function Rev(s:Wide_Wide_String) return Wide_Wide_String;
	function Rev(s:String) return String;
	function Rev(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function Rev(s:Unbounded_String) return Unbounded_String;
function Center(S:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String;
function Center(S:String;length:Integer;padding:Wide_Wide_Character) return String; --**CANNOT COMPILE with core**
	function Center(S:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String;
	function Center(S:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String;
-- ############################## Util.ads ##############################
function To_LC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_LC(instr:String) return String;
	function To_LC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_LC(instr:Unbounded_String) return Unbounded_String;
function To_TC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_TC(instr:String) return String;
	function To_TC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_TC(instr:Unbounded_String) return Unbounded_String;
function To_UC(instr:Wide_Wide_String) return Wide_Wide_String;
	function To_UC(instr:String) return String;
	function To_UC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String;
	function To_UC(instr:Unbounded_String) return Unbounded_String;
-- ############################## match.ads ##############################
function matchTo(s:Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean;
function matchTo(s:Unbounded_Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean;
function matchTo(s:String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean;
function matchTo(s:Unbounded_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean;
function matchTo(s:Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean;
function matchTo(s:Unbounded_Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean;
function matchTo(s:String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean;
function matchTo(s:Unbounded_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean;
-- ############################## Tool_Tail.adb ##############################
end Y2018.Text.Wide.Tool;
