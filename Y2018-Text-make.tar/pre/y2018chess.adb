with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Command_Line;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
with Y2018.Text.Wide.InFileUTF8; 
with Y2018.Text.Core.Tool;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
with GNAT.Source_Info;
-- with DSECT;
procedure Y2018Chess is
	gblk:Y2018.Text.Wide.InFileUTF8.self;
	r:Unbounded_Wide_Wide_String;
	lncnt:Integer:=0;
	blklen:Integer:=50;
	gc:Wide_Wide_String:="  "W;
	i:Integer:=1;
	arg:Unbounded_Wide_Wide_String;
	in_name:Unbounded_String;
	ut_name:Unbounded_String;
	p0:Pattern_TY;
	p1n:Pattern_TY;
	ut : File_Type;
	c:Wide_Wide_Character;
	c_nul:Wide_Wide_Character:='\u2654'W; i_nul:Integer:=0; -- WHITE KING 
	c_b:Wide_Wide_Character:=  '\u2655'W; i_b:Integer:=0; -- WHITE QUEEN
	c_f:Wide_Wide_Character:=  '\u2656'W; i_f:Integer:=0; -- WHITE ROOK
	c_n:Wide_Wide_Character:=  '\u2657'W; i_n:Integer:=0; -- WHITE BISHOP
	c_t:Wide_Wide_Character:=  '\u2658'W; i_t:Integer:=0; -- WHITE KNIGHT
	c_r:Wide_Wide_Character:=  '\u2659'W; i_r:Integer:=0; -- WHITE PAWN
	c_nel:Wide_Wide_Character:='\u265F'W; i_nel:Integer:=0; -- BLACK PAWN
	c_cc:Wide_Wide_Character:= '\u265A'W; i_cc:Integer:=0; -- BLACK KING
	c_cf:Wide_Wide_Character:= '\u265B'W; i_cf:Integer:=0; -- BLACK QUEEN
	c_cs:Wide_Wide_Character:= '\u265C'W; i_cs:Integer:=0; -- BLACK ROOK
	c_cn:Wide_Wide_Character:= '\u265D'W; i_cn:Integer:=0; -- BLACK BISHOP
	c_xx:Wide_Wide_Character:= '\u265E'W; warn:Integer:=0;  -- BLACK KNIGHT
	c_rc:Wide_Wide_Character:= '\uFFFD'W; i_rc:Integer:=0;  -- REPLACEMENT CHARACTER
	rcy:Boolean:=FALSE;
begin
	if Ada.Command_Line.Argument_Count = 0 then
		Put_line("  List any file to an editor friendly list file.");
		Put_line("  All control characters are replaced by CHESS symbols.");
		Put_line("  Line length is fixed to the value of -blk parameter (default 50),");
		Put_line("  'line length' is the number of UTF-8 characters on a single line.");
		Put_line("  All non-UTF8 characters are replaced by BLACK KNIGHT symbol.");
		Put_line("  " + c_nul +"   "+ c_b +"   "+ c_f +"   "+ c_n +"   "+ c_t +"   "+ c_r +"   "+ c_nel +"   "+ c_cc +"   "+ c_cf +"   "+ c_cs +"   "+ c_cn +"   "+ c_xx);
		Put_line("  Syntax:");
		Put_line("    Y2018Chess {<option>}* <input_file> {<output_file>}");
		Put_line("  if no <output_file> then name of <output_file> is chess.lst");
		Put_line("  Options:");
		Put_line("    -blk:<line length> -- length of line in output");
		Put_line("    -g -- use greek characters not chess symbols");
		Put_line("    -r -- replace characters with a code value over 16#FFFF#");
		return;
	end if;
	Pattern(p0,"^(-[\w]+)$"W);
	Pattern(p1n,"^(-[\w]+):([\d]+)$"W);
	while i <= Ada.Command_Line.Argument_Count loop
		arg:=NUW + Ada.Command_Line.Argument(i);
		declare
			p0r:Unbounded_Wide_Wide_String_AA(0 .. (size(p0) - 1));
			p1nr:Unbounded_Wide_Wide_String_AA(0 .. (size(p1n) - 1));
		begin
			if matchTo(arg,p0,p0r) then
				if p0r(0) = NUW + "-g" then
					c_cc:= '\u0393'W; -- GAMMA
					c_cf:= '\u03A6'W; -- PHI
					c_cs:= '\u03A8'W; -- PSI
					c_cn:= '\u03A9'W; -- OMEGA
					c_b:=  '\u03B2'W; -- beta
					c_n:=  '\u03B4'W; -- delta
					c_nul:='\u03B6'W; -- zeta
					c_t:=  '\u03B8'W; -- theta
					c_nel:='\u03BB'W; -- lamda
					c_r:=  '\u03C1'W; -- rho
					c_f:=  '\u03C3'W; -- phi
					c_xx:= '\u03A3'W; -- SIGMA
				elsif p0r(0) = NUW + "-r" then
					rcy:=TRUE;
				else
					raise Program_Error with "E9001 " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Unknown arg :" + arg;
				end if;
			elsif matchTo(arg,p1n,p1nr) then
				if p1nr(1) = NUW + "-blk" then
					blklen:=Integer'Value("" + p1nr(2));
					if blklen < 1 then
						raise Program_Error with "E9002 " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Invalid -blk value";
					end if;
				else
					raise Program_Error with "E9003 " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Unknown arg :" + arg;
				end if;
			elsif Length(in_name) = 0 then
				in_name:=NUS + arg;
			elsif Length(ut_name) = 0 then
				ut_name:=NUS + arg;
			else
				raise Program_Error with "E9004 " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Unknown arg :" + arg;
			end if;
		end;
		i:=i+1;
	end loop;
	if Length(in_name) = 0 then
		raise Program_Error with "E9005 " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": No input file";
	end if;
	if Length(ut_name) = 0 then
		ut_name:=NUS + "chess.lst";
	end if;
	Create (File => ut,Mode => Out_File,Name => "" + ut_name);
	
	Y2018.Text.Wide.InFileUTF8.open(gblk,"" + in_name);
	while not Y2018.Text.Wide.InFileUTF8.eof(gblk) loop
		r:=NUW;
		while not Y2018.Text.Wide.InFileUTF8.eof(gblk) loop
			declare
				vc:Wide_Wide_Character;
				e:RS_TY;
				us:Unbounded_String;
			begin
				e:=Y2018.Text.Wide.InFileUTF8.read(gblk,us);
				declare
					v:Wide_Wide_String:=""W + us;
				begin
					vc:=v(1);
				end;
				c:=vc;
				gc:=Y2018.Text.Core.Tool.GET_GC(vc);
				if rcy then
					if vc > '\uFFFF'W then
						c:=c_rc;
						i_rc:=i_rc + 1;
					end if;
				end if;
				if not (e = RS_NONE) then
					c:=c_xx;
					warn:=warn + 1;
				elsif gc = "Cc"W then
					c:=c_cc;
					i_cc:=i_cc + 1;
				elsif gc = "Cf"W then
					c:=c_cf;
					i_cf:=i_cf + 1;
				elsif gc = "Cs"W then
					c:=c_cs;
					i_cs:=i_cs + 1;
				elsif gc = "Cn"W or gc = "  "W  then
					c:=c_cn;
					i_cn:=i_cn + 1;
				else
					null;
				end if;
				case vc is
					when '\x00'W => -- nul
						c:=c_nul;
						i_nul:=i_nul + 1;
					when '\x08'W => -- \b
						c:=c_b;
						i_b:=i_b + 1;
					when '\x0C'W => -- \f
						c:=c_f;
						i_f:=i_f + 1;
					when '\x0A'W => -- \n
						c:=c_n;
						i_n:=i_n + 1;
					when '\x0D'W =>-- \r
						c:=c_r; 
						i_r:=i_r + 1;
					when '\x09'W => -- \t
						c:=c_t;
						i_t:=i_t + 1;
					when '\x85'W => -- NEL Next line
						c:=c_nel;
						i_nel:=i_nel + 1;
					when others =>
						null;
				end case;
				--
				r:=r + c;
			end;
			if Length(r)>=blklen then
				exit;
			end if;
		end loop;
		Put_line(ut,"" + r);
		lncnt:=lncnt + 1;
	end loop;
	Y2018.Text.Wide.InFileUTF8.close(gblk);
	close(ut);
	Put_line("" + "\tinput "W + in_name);
	Put_line("" + "\toutput "W + ut_name);
	Put_line("" + "\tlines"W + Integer'Image(lncnt));
	Put_line("" + "\tnul null"W + Integer'Image(i_nul) + " " + c_nul);
	Put_line("" + "\t\\b backspace"W + Integer'Image(i_b) + " " + c_b);
	Put_line("" + "\t\\f form_feed"W + Integer'Image(i_f) + " " + c_f);
	Put_line("" + "\t\\n line_feed"W + Integer'Image(i_n) + " " + c_n);
	Put_line("" + "\t\\t horizontal_tabulation"W + Integer'Image(i_t) + " " + c_t);
	Put_line("" + "\t\\r carriage_return"W + Integer'Image(i_r) + " " + c_r);
	Put_line("" + "\tnel next_line"W + Integer'Image(i_nel) + " " + c_nel);
	Put_line("" + "\tCc control"W + Integer'Image(i_cc) + " " + c_cc);
	Put_line("" + "\tCf format"W + Integer'Image(i_cf) + " " + c_cf);
	Put_line("" + "\tCs surrogate"W + Integer'Image(i_cs) + " " + c_cs);
	Put_line("" + "\tCn not_assigned"W + Integer'Image(i_cn) + " " + c_cn);
	if rcy then
		Put_line("" + "\tReplaced "W + Integer'Image(i_rc) + " " + c_rc);
	end if;
	if warn > 0 then
		Put_line(Standard_Error,"" + "\t** WARNING, not an UTF-8 file**"W + Integer'Image(warn) + " " + c_xx);
	end if;
end Y2018Chess;
