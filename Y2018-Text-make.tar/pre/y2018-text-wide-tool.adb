-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## Tool.adb ##############################
with Ada.Strings.UTF_Encoding; --use Ada.Strings.UTF_Encoding;
with Ada.Strings.UTF_Encoding.Conversions;
with Ada.Strings.UTF_Encoding.Wide_Wide_Strings; --use Ada.Strings.UTF_Encoding.Wide_Wide_Strings;
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Strings;
with Interfaces;
with GNAT.Source_Info;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Core.GC; --use Y2018.Text.Core.GC;
with Y2018.Text.Core.C32; use Y2018.Text.Core.C32;
with Y2018.Text.Core.ULTcase; --use Y2018.Text.Core.ULTcase;
with Y2018.Text.Core.Tool;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
with Y2018.Text.Regex.ToilPack; use Y2018.Text.Regex.ToilPack;
with Ada.Text_IO; use  Ada.Text_IO;

package body Y2018.Text.Wide.Tool is
-- ############################## hex.adb ##############################
function To_Hex8(v :Wide_Wide_Character) return String is
begin
	return To_Hex8(Wide_Wide_Character'Pos(v));
end To_Hex8;
function To_Hex8(v :Character) return String is
	s : String(1 .. 8); 
	t : String(1 .. 2);
begin
	s:=To_Hex8(Character'Pos(v));
	if s(7) = '_' then t(1):= '0'; else t(1):=s(7); end if;
	t(2):=s(8);
	return t;
end To_Hex8;
function To_Hex8(v :Integer) return String is
	r : String(1..8):="_______0";
	k : Integer:=8;
	i : Long_Long_Integer;
begin
	if  v>=0 then i:= Long_Long_Integer(v);
	else i:= 16#100000000# + Long_Long_Integer(v); end if;
	while i > 0 loop
		case i mod 16 is
			when 0 => r(k):='0';
			when 1 => r(k):='1';
			when 2 => r(k):='2';
			when 3 => r(k):='3';
			when 4 => r(k):='4';
			when 5 => r(k):='5';
			when 6 => r(k):='6';
			when 7 => r(k):='7';
			when 8 => r(k):='8';
			when 9 => r(k):='9';
			when 10 => r(k):='A';
			when 11 => r(k):='B';
			when 12 => r(k):='C';
			when 13 => r(k):='D';
			when 14 => r(k):='E';
			when others => r(k):='F';
		end case;
		i:=i / 16;
		k:=k - 1;
	end loop;
	return r;
end To_Hex8;
function To_Hex8W(v :Wide_Wide_Character) return Wide_Wide_String is
begin
	return To_Hex8W(Wide_Wide_Character'Pos(v));
end To_Hex8W;

function To_Hex8W(v :Character) return Wide_Wide_String is
	s : Wide_Wide_String(1 .. 8); 
	t : Wide_Wide_String(1 .. 2);
begin
	s:=To_Hex8W(Character'Pos(v));
	if s(7) = Wide_Wide_Character'Val(16#5F#) then
		t(1):=Wide_Wide_Character'Val(16#30#); else t(1):=s(7); 
	end if;
	t(2):=s(8);
	return t;
end To_Hex8W;

function To_Hex8W(v :Integer) return Wide_Wide_String is
	r : Wide_Wide_String(1..8):="_______0"W;
	k : Integer:=8;
	i : Long_Long_Integer;
begin
	if  v>=0 then i:= Long_Long_Integer(v);
	else i:= 16#100000000# + Long_Long_Integer(v); end if;
	while i > 0 loop
		case i mod 16 is
			when 0 => r(k):=Wide_Wide_Character'Val(16#30#);--'0';
			when 1 => r(k):=Wide_Wide_Character'Val(16#31#);--'1';
			when 2 => r(k):=Wide_Wide_Character'Val(16#32#);--'2';
			when 3 => r(k):=Wide_Wide_Character'Val(16#33#);--'3';
			when 4 => r(k):=Wide_Wide_Character'Val(16#34#);--'4';
			when 5 => r(k):=Wide_Wide_Character'Val(16#35#);--'5';
			when 6 => r(k):=Wide_Wide_Character'Val(16#36#);--'6';
			when 7 => r(k):=Wide_Wide_Character'Val(16#37#);--'7';
			when 8 => r(k):=Wide_Wide_Character'Val(16#38#);--'8';
			when 9 => r(k):=Wide_Wide_Character'Val(16#39#);--'9';
			when 10 => r(k):=Wide_Wide_Character'Val(16#41#);--'A';
			when 11 => r(k):=Wide_Wide_Character'Val(16#42#);--'B';
			when 12 => r(k):=Wide_Wide_Character'Val(16#43#);--'C';
			when 13 => r(k):=Wide_Wide_Character'Val(16#44#);--'D';
			when 14 => r(k):=Wide_Wide_Character'Val(16#45#);--'E';
			when others => r(k):=Wide_Wide_Character'Val(16#46#);--'F';
		end case;
		i:=i / 16;
		k:=k - 1;
	end loop;
	return r;
end To_Hex8W;
-- ############################## hexX.adb ##############################
function To_HexX(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 2;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FF# then null; else
raise Program_Error with E_TY'Image(Y2018.Text.E5021) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Out of range"; 
		end if;
		for Q in 1..2 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexX;
function To_HexX(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexX(s,padding);
end To_HexX;
	function To_HexX(S:String;padding:Wide_Wide_Character) return String is
	begin
		return UTF.To8(To_HexX(UTF.To32(S),padding));
	end To_HexX;
	function To_HexX(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexX(To_Wide_Wide_String(S),padding));
	end To_HexX;
	function To_HexX(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexX(UTF.To32(To_String(S)),padding)));
	end To_HexX;
	function To_HexX(s:String) return String is
	begin
		return UTF.To8(To_HexX(UTF.To32(s)));
	end To_HexX;
	function To_HexX(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexX(To_Wide_Wide_String(s)));
	end To_HexX;
	function To_HexX(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexX(UTF.To32(To_String(s)))));
	end To_HexX;
-- ############################## hexU.adb ##############################
function To_HexU(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 4;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FFFF# then null; else
raise Program_Error with E_TY'Image(Y2018.Text.E5019) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Out of range"; 
		end if;
		for Q in 1..4 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexU;
function To_HexU(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexU(s,padding);
end To_HexU;
	function To_HexU(S:String;padding:Wide_Wide_Character) return String is
	begin
		return UTF.To8(To_HexU(UTF.To32(S),padding));
	end To_HexU;
	function To_HexU(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexU(To_Wide_Wide_String(S),padding));
	end To_HexU;
	function To_HexU(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexU(UTF.To32(To_String(S)),padding)));
	end To_HexU;
	function To_HexU(s:String) return String is
	begin
		return UTF.To8(To_HexU(UTF.To32(s)));
	end To_HexU;
	function To_HexU(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexU(To_Wide_Wide_String(s)));
	end To_HexU;
	function To_HexU(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexU(UTF.To32(To_String(s)))));
	end To_HexU;
-- ############################## hexV.adb ##############################
function To_HexV(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 6;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		if	I in 0 .. 16#FFFFFF# then null; else
raise Program_Error with E_TY'Image(Y2018.Text.E5020) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " Out of range"; 
		end if;
		for Q in 1..6 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexV;
function To_HexV(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexV(s,padding);
end To_HexV;
	function To_HexV(S:String;padding:Wide_Wide_Character) return String is
	begin
		return UTF.To8(To_HexV(UTF.To32(S),padding));
	end To_HexV;
	function To_HexV(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexV(To_Wide_Wide_String(S),padding));
	end To_HexV;
	function To_HexV(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexV(UTF.To32(To_String(S)),padding)));
	end To_HexV;
	function To_HexV(s:String) return String is
	begin
		return UTF.To8(To_HexV(UTF.To32(s)));
	end To_HexV;
	function To_HexV(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexV(To_Wide_Wide_String(s)));
	end To_HexV;
	function To_HexV(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexV(UTF.To32(To_String(s)))));
	end To_HexV;
-- ############################## hexW.adb ##############################
function To_HexY(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	C : Wide_Wide_Character;
	I : Integer;
	RLEN : Integer;
	RI : Integer:=1;
	K : Integer;
	R : Wide_Wide_String_AC;
	empty : Wide_Wide_String(1 .. 0);
	V : constant Integer := 8;
begin
	if S'Length = 0 then return empty; end if;
	RLEN:=(V +1) * S'Length - 1;
	R:= new Wide_Wide_String(1 .. RLEN);
	for J in  S'FIRST(1) .. S'LAST(1) loop
		K:=RI;
		I:=Wide_Wide_Character'Pos(s(J));
		for Q in 1..8 loop
			case I mod 16 is
				when 0 => C:=Wide_Wide_Character'Val(16#30#); -- 0
				when 1 => C:=Wide_Wide_Character'Val(16#31#); -- 1
				when 2 => C:=Wide_Wide_Character'Val(16#32#); -- 2
				when 3 => C:=Wide_Wide_Character'Val(16#33#); -- 3
				when 4 => C:=Wide_Wide_Character'Val(16#34#); -- 4
				when 5 => C:=Wide_Wide_Character'Val(16#35#); -- 5
				when 6 => C:=Wide_Wide_Character'Val(16#36#); -- 6
				when 7 => C:=Wide_Wide_Character'Val(16#37#); -- 7
				when 8 => C:=Wide_Wide_Character'Val(16#38#); -- 8
				when 9 => C:=Wide_Wide_Character'Val(16#39#); -- 9
				when 10 => C:=Wide_Wide_Character'Val(16#41#); -- A
				when 11 => C:=Wide_Wide_Character'Val(16#42#); -- B
				when 12 => C:=Wide_Wide_Character'Val(16#43#); -- C
				when 13 => C:=Wide_Wide_Character'Val(16#44#); -- D
				when 14 => C:=Wide_Wide_Character'Val(16#45#); -- E
				when others => C:=Wide_Wide_Character'Val(16#46#); -- F
			end case;
			R(K + V - Q):=C;
			RI:=RI + 1;
			I:= I / 16;
		end loop;
		if J < S'LAST(1) then
			R(RI):=padding;
			RI:=RI+1;
		end if;
	end loop;
	return R.all;
end To_HexY;
function To_HexY(s:Wide_Wide_String) return Wide_Wide_String is
	padding : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#5F#);
begin
	return To_HexY(s,padding);
end To_HexY;
	function To_HexY(S:String;padding:Wide_Wide_Character) return String is
	begin
		return UTF.To8(To_HexY(UTF.To32(S),padding));
	end To_HexY;
	function To_HexY(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexY(To_Wide_Wide_String(S),padding));
	end To_HexY;
	function To_HexY(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexY(UTF.To32(To_String(S)),padding)));
	end To_HexY;
	function To_HexY(s:String) return String is
	begin
		return UTF.To8(To_HexY(UTF.To32(s)));
	end To_HexY;
	function To_HexY(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_HexY(To_Wide_Wide_String(s)));
	end To_HexY;
	function To_HexY(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_HexY(UTF.To32(To_String(s)))));
	end To_HexY;
-- ############################## 32.adb ##############################
function Substr(S:Wide_Wide_String;pos:Integer;len:Integer) return Wide_Wide_String is
	blank : constant Wide_Wide_Character:=Wide_Wide_Character'Val(16#20#);
	QC : Wide_Wide_Character;
	QS : Wide_Wide_String(1..len);
begin
	if len = 0 then return QS; end if;
	for QI in QS'First(1) .. QS'Last(1) loop
		if QI + pos -1 <= S'Last(1) and QI + pos -1 >= S'First(1) then
			QC := S(QI + pos -1);
			QS(QI) := QC;
		else
			QS(QI) := blank;
		end if;
	end loop;
	return QS;
end Substr;
function Substr(s:Wide_Wide_String;pos:Integer) return Wide_Wide_String is
begin
	return Substr(s,pos,s'LAST(1) - pos + 1);
end Substr;
function Substr(S:String;pos:Integer;len:Integer) return String is
	blank : constant Character:=Character'Val(16#20#);
	QC : Character;
	QS : String(1..len);
begin
	if len = 0 then return QS; end if;
	for QI in QS'First(1) .. QS'Last(1) loop
		if QI + pos -1 <= S'Last(1) and QI + pos -1 >= S'First(1) then
			QC := S(QI + pos -1);
			QS(QI) := QC;
		else
			QS(QI) := blank;
		end if;
	end loop;
	return QS;
end Substr;
function Substr(s:String;pos:Integer) return String is
begin
	return Substr(s,pos,s'LAST(1) - pos + 1);
end Substr;
	function Substr(S:Unbounded_Wide_Wide_String;pos:Integer;len:Integer) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Substr(To_Wide_Wide_String(S),pos,len));
	end Substr;
	function Substr(S:Unbounded_String;pos:Integer;len:Integer) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Substr(UTF.To32(To_String(S)),pos,len)));
	end Substr;
	function Substr(s:Unbounded_Wide_Wide_String;pos:Integer) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Substr(To_Wide_Wide_String(s),pos));
	end Substr;
	function Substr(s:Unbounded_String;pos:Integer) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Substr(UTF.To32(To_String(s)),pos)));
	end Substr;
function Is_Valid(s:Wide_Wide_String) return Boolean is
	i : Integer;
begin
	for J in s'FIRST(1) .. s'LAST(1) loop
		i:=Wide_Wide_Character'Pos(s(J));
		if	(i in C32_1_LOW .. C32_1_HIGH) or
			(i in C32_2_LOW .. C32_2_HIGH) or
			(i in C32_3_LOW .. C32_3_HIGH) or
			(i in C32_4_LOW .. C32_4_HIGH) or
			(i in C32_5_LOW .. C32_5_HIGH) or
			(i in C32_6_LOW .. C32_6_HIGH) or
			(i in C32_7_LOW .. C32_7_HIGH) or
			(i in C32_8_LOW .. C32_8_HIGH) or
			(i in C32_9_LOW .. C32_9_HIGH) then
			null;
		else
			return FALSE;
		end if;	
	end loop;
	return TRUE;
end Is_Valid;
	function Is_Valid(s:String) return Boolean is
	begin
		return Is_Valid(UTF.To32(s));
	end Is_Valid;
	function Is_Valid(s:Unbounded_Wide_Wide_String) return Boolean is
	begin
		return Is_Valid(To_Wide_Wide_String(s));
	end Is_Valid;
	function Is_Valid(s:Unbounded_String) return Boolean is
	begin
		return Is_Valid(UTF.To32(To_String(s)));
	end Is_Valid;
function ReIndex(s:String;rfirst:Integer) return String is
begin
	if s'First(1) = rfirst then
		return s;
	end if;
	declare
		rlast: constant Integer:=s'Last(1) - s'First(1) +rfirst;
		r:String(rfirst .. rlast);
		i:Integer:=0;
	begin
		while i < r'Length(1) loop
			r(rfirst + i):=s(s'First(1) + i);
			i:=i+1;
		end loop;
		return r;
	end;
end ReIndex;
function ReIndex(s:Wide_Wide_String;rfirst:Integer) return Wide_Wide_String is
begin
	if s'First(1) = rfirst then
		return s;
	end if;
	declare
		rlast: constant Integer:=s'Last(1) - s'First(1) +rfirst;
		r:Wide_Wide_String(rfirst .. rlast);
		i:Integer:=0;
	begin
		while i < r'Length(1) loop
			r(rfirst + i):=s(s'First(1) + i);
			i:=i+1;
		end loop;
		return r;
	end;
end ReIndex;
function ReIndex(s:Unbounded_Wide_Wide_String;rfirst:Integer) return Unbounded_Wide_Wide_String is
begin
	return To_Unbounded_Wide_Wide_String(ReIndex(To_Wide_Wide_String(s),rfirst));
end ReIndex;
	function ReIndex(s:Unbounded_String;rfirst:Integer) return Unbounded_String is
	begin
		return To_Unbounded_String(ReIndex(To_String(s),rfirst));
	end ReIndex;
-- ############################## 32comp.adb ##############################
function CmpS(first:Wide_Wide_String;second:Wide_Wide_String) return Integer is
	l : Integer;
	f : Integer;
	fm : Wide_Wide_Character;
	sm : Wide_Wide_Character;
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	f:=first'FIRST(1);
	if f > second'FIRST(1) then f:=second'FIRST(1); end if;
	l:=first'LAST(1);
	if l < second'LAST(1) then l:=second'LAST(1); end if;
	for i in f .. l loop
		fm:=blank;
		sm:=blank;
		if (i >= first'FIRST(1)) and (i <= first'LAST(1)) then fm:=first(i); end if;
		if (i >= second'FIRST(1)) and (i <= second'LAST(1)) then sm:=second(i); end if;
		if fm > sm then return 1;
		elsif fm < sm then return -1; 
		end if;
	end loop;
	return 0;
end CmpS;
function CmpS(first:String;second:String) return Integer is
	l : Integer;
	f : Integer;
	fm : Character;
	sm : Character;
	blank : constant Character := Character'Val(16#20#);
begin
	f:=first'FIRST(1);
	if f > second'FIRST(1) then f:=second'FIRST(1); end if;
	l:=first'LAST(1);
	if l < second'LAST(1) then l:=second'LAST(1); end if;
	for i in f .. l loop
		fm:=blank;
		sm:=blank;
		if (i >= first'FIRST(1)) and (i <= first'LAST(1)) then fm:=first(i); end if;
		if (i >= second'FIRST(1)) and (i <= second'LAST(1)) then sm:=second(i); end if;
		if fm > sm then return 1;
		elsif fm < sm then return -1; 
		end if;
	end loop;
	return 0;
end CmpS;
-- ############################## 32shift.adb ##############################
function RightStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'First(1);
	SI:=S'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end RightStrip;
function RightStrip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return RightStrip(source,blank);
end RightStrip;
function RightStrip(S:String;padding:Wide_Wide_Character) return String is
	type Wide_Wide_String_AC is access String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : String(1 .. 0);
	R : Wide_Wide_String_AC;
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5009) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad";
	end if; 
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padStr(1) then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new String(1 .. RLEN);
	RI:=R'First(1);
	SI:=S'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end RightStrip;
function RightStrip(source:String) return String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return RightStrip(source,blank);
end RightStrip;
	function RightStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(RightStrip(To_Wide_Wide_String(S),padding));
	end RightStrip;
	function RightStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(RightStrip(UTF.To32(To_String(S)),padding)));
	end RightStrip;
	function RightStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(RightStrip(To_Wide_Wide_String(source)));
	end RightStrip;
	function RightStrip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(RightStrip(UTF.To32(To_String(source)))));
	end RightStrip;
function Rev(s:Wide_Wide_String) return Wide_Wide_String is
	i:Integer;
	j:Integer;
	t:Wide_Wide_String(s'First .. s'Last);
begin
	i:=s'First;
	j:=s'Last;
	while i<=s'Last loop
		t(j):=s(i);
		i:=i+1;
		j:=j-1;
	end loop;
	return t;
end Rev;
	function Rev(s:String) return String is
	begin
		return UTF.To8(Rev(UTF.To32(s)));
	end Rev;
	function Rev(s:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Rev(To_Wide_Wide_String(s)));
	end Rev;
	function Rev(s:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Rev(UTF.To32(To_String(s)))));
	end Rev;
function Strip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1;
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	SI:=S'First(1);
	while SI <= S'Last(1) loop
		if S(SI) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI + 1;
	end loop;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end Strip;
function Strip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return Strip(source,blank);
end Strip;
function Strip(S:String;padding:Wide_Wide_Character) return String is
	type Wide_Wide_String_AC is access String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : String(1 .. 0);
	R : Wide_Wide_String_AC;
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5010) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad"; 
	end if; 
	RLEN:=S'Length(1);
	SI:=S'Last(1);
	while SI >= S'First(1) loop
		if S(SI) = padStr(1) then RLEN:= RLEN - 1;
		else exit;
		end if;
		SI:=SI - 1;
	end loop;
	if RLEN = 0 then return empty; end if;
	SI:=S'First(1);
	while SI <= S'Last(1) loop
		if S(SI) = padStr(1) then RLEN:= RLEN - 1; 
		else exit;
		end if;
		SI:=SI + 1;
	end loop;
	R:= new String(1 .. RLEN);
	RI:=R'First(1);
	while RI <= R'Last(1) loop
		R(RI):=S(SI);
		RI:=RI+1;
		SI:=SI+1;
	end loop;
	return R.all;
end Strip;
function Strip(source:String) return String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return Strip(source,blank);
end Strip;
	function Strip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Strip(To_Wide_Wide_String(S),padding));
	end Strip;
	function Strip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Strip(UTF.To32(To_String(S)),padding)));
	end Strip;
	function Strip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Strip(To_Wide_Wide_String(source)));
	end Strip;
	function Strip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Strip(UTF.To32(To_String(source)))));
	end Strip;
function Right(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	r : Wide_Wide_String(1 .. length);
	i : Integer;
	j : Integer;
begin
	if length < 0 then
raise Program_Error with E_TY'Image(Y2018.Text.E5001) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " length<0";
	end if; 
	i:=length;
	j:=source'LAST(1);
	while i > 0 loop
		if j > 0 then
			r(i):=source(j);
		else
			r(i):=padding;
		end if;
		i := i - 1;
		j := j - 1;
	end loop;
	return r;
end Right;
function Right(source:String;length:Integer;padding:Wide_Wide_Character) return String is
	r : String(1 .. length);
	i : Integer;
	j : Integer;
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if length < 0 then
raise Program_Error with E_TY'Image(Y2018.Text.E5003) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " length<0"; 
	end if; 
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5004) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad";
	end if; 
	i:=length;
	j:=source'LAST(1);
	while i > 0 loop
		if j > 0 then
			r(i):=source(j);
		else
			r(i):=padStr(1);
		end if;
		i := i - 1;
		j := j - 1;
	end loop;
	return r;
end Right;
	function Right(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Right(To_Wide_Wide_String(source),length,padding));
	end Right;
	function Right(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Right(UTF.To32(To_String(source)),length,padding)));
	end Right;
function Left(source:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	r : Wide_Wide_String(1 .. length);
	i : Integer;
	j : Integer;
begin
	if length < 0 then
raise Program_Error with E_TY'Image(Y2018.Text.E5002) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " length<0"; 
	end if; 
	i:=length;
	j:=source'LAST(1);
	while i <= length loop
		if j <= source'LAST(1) then
			r(i):=source(j);
		else
			r(i):=padding;
		end if;
		i := i + 1;
		j := j + 1;
	end loop;
	return r;
end Left;
function Left(source:String;length:Integer;padding:Wide_Wide_Character) return String is
	r : String(1 .. length);
	i : Integer;
	j : Integer;
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if length < 0 then
raise Program_Error with E_TY'Image(Y2018.Text.E5005) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " length<0"; 
	end if; 
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5006) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad"; 
	end if; 
	i:=length;
	j:=source'LAST(1);
	while i <= length loop
		if j <= source'LAST(1) then
			r(i):=source(j);
		else
			r(i):=padStr(1);
		end if;
		i := i + 1;
		j := j + 1;
	end loop;
	return r;
end Left;
	function Left(source:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Left(To_Wide_Wide_String(source),length,padding));
	end Left;
	function Left(source:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Left(UTF.To32(To_String(source)),length,padding)));
	end Left;
function Center(S:Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Wide_Wide_String is
	R : Wide_Wide_String(1 .. length);
	upR : Integer;
	upS : Integer;
	dwR : Integer;
	dwS : Integer;
	ok : Boolean := TRUE;
	empty : Wide_Wide_String(1 .. 0);
begin
	if length = 0 then return empty; end if;
	upR:= (R'Last(1) - R'First(1) + 1) / 2; dwR:=upR - 1;
	upS:= (S'Last(1) - S'First(1) + 1) / 2; dwS:=upS - 1;
	while ok loop
		ok:= FALSE;
		if upR <= R'Last(1) then
			if upS <= S'Last(1) then
				R(upR):=S(upS);
			else
				R(upR):=padding;
			end if;
			ok:=TRUE;
		end if;
		if dwR >= 1 then
			if dwS >= 1 then
				R(dwR):= S(dwS);
			else
				R(dwR):=padding;
			end if;
			ok:=TRUE;
		end if;	
		upR := upR + 1; dwR := dwR - 1;
		upS := upS + 1; dwS := dwS - 1;
	end loop;
	return R;
end Center;
function Center(S:String;length:Integer;padding:Wide_Wide_Character) return String is
	R : String(1 .. length);
	upR : Integer;
	upS : Integer;
	dwR : Integer;
	dwS : Integer;
	ok : Boolean := TRUE;
	empty : String(1 .. 0);
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5007) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad"; 
	end if; 
	if length = 0 then return empty; end if;
	upR:= (R'Last(1) - R'First(1) + 1) / 2; dwR:=upR - 1;
	upS:= (S'Last(1) - S'First(1) + 1) / 2; dwS:=upS - 1;
	while ok loop
		ok:= FALSE;
		if upR <= R'Last(1) then
			if upS <= S'Last(1) then
				R(upR):=S(upS);
			else
				R(upR):=padStr(1);
			end if;
			ok:=TRUE;
		end if;
		if dwR >= 1 then
			if dwS >= 1 then
				R(dwR):= S(dwS);
			else
				R(dwR):=padStr(1);
			end if;
			ok:=TRUE;
		end if;	
		upR := upR + 1; dwR := dwR - 1;
		upS := upS + 1; dwS := dwS - 1;
	end loop;
	return R;
end Center;
	function Center(S:Unbounded_Wide_Wide_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(Center(To_Wide_Wide_String(S),length,padding));
	end Center;
	function Center(S:Unbounded_String;length:Integer;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(Center(UTF.To32(To_String(S)),length,padding)));
	end Center;
function LeftStrip(S:Wide_Wide_String;padding:Wide_Wide_Character) return Wide_Wide_String is
	type Wide_Wide_String_AC is access Wide_Wide_String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : Wide_Wide_String(1 .. 0);
	R : Wide_Wide_String_AC;
begin
	RLEN:=S'Length(1);
	for J in S'First(1) .. S'Last(1) loop
		if S(J) = padding then RLEN:= RLEN - 1; 
		else exit;
		end if;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new Wide_Wide_String(1 .. RLEN);
	RI:=R'Last(1);
	SI:=S'Last(1);
	while RI >= 1 loop
		R(RI):=S(SI);
		RI:=RI-1;
		SI:=SI-1;
	end loop;
	return R.all;
end LeftStrip;
function LeftStrip(source:Wide_Wide_String) return Wide_Wide_String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return LeftStrip(source,blank);
end LeftStrip;
function LeftStrip(S:String;padding:Wide_Wide_Character) return String is
	type Wide_Wide_String_AC is access String;
	RLEN : Integer;
	RI : Integer;
	SI : Integer;
	empty : String(1 .. 0);
	R : Wide_Wide_String_AC;
	padWstr:Wide_Wide_String:=(1=>padding);
	padStr:String:=UTF.To8(padWstr);
begin
	if padStr'Last > 1 then
raise Program_Error with E_TY'Image(Y2018.Text.E5008) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & " too long pad";
	end if; 
	RLEN:=S'Length(1);
	for J in S'First(1) .. S'Last(1) loop
		if S(J) = padStr(1) then RLEN:= RLEN - 1; 
		else exit;
		end if;
	end loop;
	if RLEN = 0 then return empty; end if;
	R:= new String(1 .. RLEN);
	RI:=R'Last(1);
	SI:=S'Last(1);
	while RI >= 1 loop
		R(RI):=S(SI);
		RI:=RI-1;
		SI:=SI-1;
	end loop;
	return R.all;
end LeftStrip;
function LeftStrip(source:String) return String is
	blank : constant Wide_Wide_Character := Wide_Wide_Character'Val(16#20#);
begin
	return LeftStrip(source,blank);
end LeftStrip;
	function LeftStrip(S:Unbounded_Wide_Wide_String;padding:Wide_Wide_Character) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(LeftStrip(To_Wide_Wide_String(S),padding));
	end LeftStrip;
	function LeftStrip(S:Unbounded_String;padding:Wide_Wide_Character) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(LeftStrip(UTF.To32(To_String(S)),padding)));
	end LeftStrip;
	function LeftStrip(source:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(LeftStrip(To_Wide_Wide_String(source)));
	end LeftStrip;
	function LeftStrip(source:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(LeftStrip(UTF.To32(To_String(source)))));
	end LeftStrip;
-- ############################## Util.adb ##############################
function To_LC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Y2018.Text.Core.Tool.Get_LC(instr(J));
	end loop;
	return utstr;
end To_LC;
	function To_LC(instr:String) return String is
	begin
		return UTF.To8(To_LC(UTF.To32(instr)));
	end To_LC;
	function To_LC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_LC(To_Wide_Wide_String(instr)));
	end To_LC;
	function To_LC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_LC(UTF.To32(To_String(instr)))));
	end To_LC;
function To_TC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Y2018.Text.Core.Tool.Get_TC(instr(J));
	end loop;
	return utstr;
end To_TC;
	function To_TC(instr:String) return String is
	begin
		return UTF.To8(To_TC(UTF.To32(instr)));
	end To_TC;
	function To_TC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_TC(To_Wide_Wide_String(instr)));
	end To_TC;
	function To_TC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_TC(UTF.To32(To_String(instr)))));
	end To_TC;
function To_UC(instr:Wide_Wide_String) return Wide_Wide_String is
	utstr:Wide_Wide_String(1 .. instr'Last(1));
begin
	for J in 1 ..instr'Last(1) loop
		utstr(J):=Y2018.Text.Core.Tool.Get_UC(instr(J));
	end loop;
	return utstr;
end To_UC;
	function To_UC(instr:String) return String is
	begin
		return UTF.To8(To_UC(UTF.To32(instr)));
	end To_UC;
	function To_UC(instr:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String is
	begin
		return To_Unbounded_Wide_Wide_String(To_UC(To_Wide_Wide_String(instr)));
	end To_UC;
	function To_UC(instr:Unbounded_String) return Unbounded_String is
	begin
		return To_Unbounded_String(UTF.To8(To_UC(UTF.To32(To_String(instr)))));
	end To_UC;
-- ############################## match.adb ##############################
function matchTo(s:Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean is
	t:Y2018.Text.Regex.ToilPack.Toil_TY;
begin
	Y2018.Text.Regex.PatternPack.Toil(t,p,s);
	return Y2018.Text.Regex.ToilPack.has_Toil(t);
end matchTo;
function matchTo(s:Unbounded_Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean is
begin
return matchTo(To_Wide_Wide_String(s),p);
end matchTo;
function matchTo(s:String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean is
begin
return matchTo(UTF.To32(s),p);
end matchTo;
function matchTo(s:Unbounded_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY) return Boolean is
begin
return matchTo(UTF.To32(To_String(s)),p);
end matchTo;
-- ******************************************
function matchTo(s:Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean is
	t:Y2018.Text.Regex.ToilPack.Toil_TY;
	v:Y2018.Text.Regex.G_Vector.Vector;
	i:Integer:=m'First(1);
	c:Y2018.Text.Regex.G_Vector.Cursor;
	j:Y2018.Text.Regex.G_Element;
begin
	Y2018.Text.Regex.PatternPack.Toil(t,p,s);
	if Y2018.Text.Regex.ToilPack.has_Toil(t) then
		if m'Length(1) > 0 then
			v:=Y2018.Text.Regex.ToilPack.Match(t);
			for c in Y2018.Text.Regex.G_Vector.Iterate(v) loop
				j:=Y2018.Text.Regex.G_Vector.Element(c);
				if j.exists then
					m(i):=j.v;
					i:=i + 1;
				else
					m(i):=Y2018.Text.Wide.NUW;
					i:=i + 1;
				end if;
				if i > m'Last(1) then
					exit;
				end if;	
			end loop;
			while i <= m'Last(1) loop
				m(i):=Y2018.Text.Wide.NUW;
				i:=i + 1;
			end loop;
			return TRUE;
		else
			return TRUE;
		end if;
	else
		for i in m'First(1) .. m'Last(1) loop
			m(i):=Y2018.Text.Wide.NUW;
		end loop;
		return FALSE;
	end if;
end matchTo;
function matchTo(s:Unbounded_Wide_Wide_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean is
begin
return matchTo(To_Wide_Wide_String(s),p,m);
end matchTo;
function matchTo(s:String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean is
begin
return matchTo(UTF.To32(s),p,m);
end matchTo;	
function matchTo(s:Unbounded_String;p:Y2018.Text.Regex.PatternPack.Pattern_TY;m:out Y2018.Text.Wide.Unbounded_Wide_Wide_String_AA) return Boolean is
begin
return matchTo(UTF.To32(To_String(s)),p,m);
end matchTo;	
-- ############################## Tool_Tail.adb ##############################
end Y2018.Text.Wide.Tool;
