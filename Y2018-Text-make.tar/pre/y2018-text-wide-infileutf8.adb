-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## InFileUTF8.adb ##############################
with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Direct_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with GNAT.Source_Info;
	package body Y2018.Text.Wide.InFileUTF8 is
		function eof(base:Y2018.Text.Wide.InFileUTF8.self) return Boolean is
		begin
			return DirectTY.End_of_File(base.infile);
		end eof;
		procedure open(base:in out Y2018.Text.Wide.InFileUTF8.self;infilename:String;defaultString:String:=replacementCharacter;defaultAction:Boolean:=TRUE) is
		begin
			DirectTY.Open(File => base.infile,Mode => DirectTY.In_File,Name=> infilename);
			base.defstring:=To_Unbounded_String(defaultString);
			base.defaction:=defaultAction;
			base.utf8cnt:=0;
			base.bytecnt:=0;
			base.reason:=RS_OPEN;
		exception
			when others =>
				Ada.Text_IO.Put_Line(Standard_Error,"Problem with file " & infilename);
			raise;
		end open;
		procedure close(base:in out Y2018.Text.Wide.InFileUTF8.self) is
		begin
			DirectTY.close(base.infile);
			base.defstring:=Null_Unbounded_String;
			base.defaction:=TRUE;
			base.utf8cnt:=0;
			base.bytecnt:=0;
			base.reason:=RS_NONE;
		end close;
		function read(base:in out Y2018.Text.Wide.InFileUTF8.self) return String is
			ubyte: Character;
			u:Integer;
			r:Unbounded_String;
		begin
			if DirectTY.End_of_File(base.infile) then
				return ""; 
			end if;
			DirectTY.Read(base.infile,ubyte);
			base.utf8cnt:=base.utf8cnt + 1;
			base.bytecnt:=base.bytecnt + 1;
			u:=Character'Pos(ubyte);
			if u >= 16#0# and u <= 16#7F# then --1[1]
				append(r,ubyte);
			elsif u >= 16#C2# and u <= 16#DF# then --2[2]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5035) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "2[2].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#BF# then
					append(r,ubyte);
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else 
						raise Program_Error with E_TY'Image(Y2018.Text.E5036) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "2[2].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
			elsif u = 16#E0# then --3[3]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					if base.defaction then
						return to_String(base.defstring);
					else 
						raise Program_Error with E_TY'Image(Y2018.Text.E5037) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "3[3].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if; 
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#A0# and u <= 16#BF# then
					base.reason:=RS_ILLEGAL;
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then 
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5038) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "3[3].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else 
							raise Program_Error with E_TY'Image(Y2018.Text.E5039) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "3[3].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else 
						raise Program_Error with E_TY'Image(Y2018.Text.E5040) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "3[3].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
			elsif u >= 16#E1# and u <= 16#EC# then --4[3]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5041) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "4[3].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#BF# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else 
							raise Program_Error with E_TY'Image(Y2018.Text.E5042) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "4[3].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5043) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "4[3].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then 
						return to_String(base.defstring);
					else 
						raise Program_Error with E_TY'Image(Y2018.Text.E5044) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "4[3].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
			elsif u = 16#ED# then --5[3]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5045) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "5[3].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#9F# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5046) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "5[3].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5047) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "5[3].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5048) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "5[3].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
			elsif u >= 16#EE# and u <= 16#EF# then --6[3]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5049) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "6[3].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if; 
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#BF# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5050) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "6[3].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5051) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "6[3].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5052) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "6[3].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt); 
					end if;
				end if;
			elsif u = 16#F0# then --7[4]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5053) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if; 
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#90# and u <= 16#BF# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5054) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
						if DirectTY.End_of_File(base.infile) then
							base.reason:=RS_MISS;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5055) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].4 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if; 
						end if;
						DirectTY.Read(base.infile,ubyte);
						base.bytecnt:=base.bytecnt + 1;
						u:=Character'Pos(ubyte);
						if u >= 16#80# and u <= 16#BF# then
							append(r,ubyte);
						else
							base.reason:=RS_ILLEGAL;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5056) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].4 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if;
						end if;
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5057) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5058) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "7[4].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if;
				end if;
			elsif u >= 16#F1# and u <= 16#F3# then --8[4]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5059) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if; 
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#BF# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5060) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if; 
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
						if DirectTY.End_of_File(base.infile) then
							base.reason:=RS_MISS;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5061) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].4 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if; 
						end if;
						DirectTY.Read(base.infile,ubyte);
						base.bytecnt:=base.bytecnt + 1;
						u:=Character'Pos(ubyte);
						if u >= 16#80# and u <= 16#BF# then
							append(r,ubyte);
						else
							base.reason:=RS_ILLEGAL;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5062) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].4 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if;
						end if;
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5063) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5064) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "8[4].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if;
				end if;
			elsif u = 16#F4# then --9[4]
				append(r,ubyte);
				if DirectTY.End_of_File(base.infile) then
					base.reason:=RS_MISS;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5065) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].2 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if; 
				end if;
				DirectTY.Read(base.infile,ubyte);
				base.bytecnt:=base.bytecnt + 1;
				u:=Character'Pos(ubyte);
				if u >= 16#80# and u <= 16#BF# then
					append(r,ubyte);
					if DirectTY.End_of_File(base.infile) then
						base.reason:=RS_MISS;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5066) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].3 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
					DirectTY.Read(base.infile,ubyte);
					base.bytecnt:=base.bytecnt + 1;
					u:=Character'Pos(ubyte);
					if u >= 16#80# and u <= 16#BF# then
						append(r,ubyte);
						if DirectTY.End_of_File(base.infile) then
							base.reason:=RS_MISS;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5067) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].4 eof"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if; 
						end if;
						DirectTY.Read(base.infile,ubyte);
						base.bytecnt:=base.bytecnt + 1;
						u:=Character'Pos(ubyte);
						if u >= 16#80# and u <= 16#BF# then
							append(r,ubyte);
						else
							base.reason:=RS_ILLEGAL;
							if base.defaction then
								return to_String(base.defstring);
							else
								raise Program_Error with E_TY'Image(Y2018.Text.E5068) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].4 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
							end if;
						end if;
					else
						base.reason:=RS_ILLEGAL;
						if base.defaction then
							return to_String(base.defstring);
						else
							raise Program_Error with E_TY'Image(Y2018.Text.E5068) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].3 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
						end if;
					end if;
				else
					base.reason:=RS_ILLEGAL;
					if base.defaction then
						return to_String(base.defstring);
					else
						raise Program_Error with E_TY'Image(Y2018.Text.E5070) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "9[4].2 illegal"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
					end if;
				end if;
			else
				base.reason:=RS_ILLEGAL;
				if base.defaction then
					return to_String(base.defstring);
				else
					raise Program_Error with E_TY'Image(Y2018.Text.E5071) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": " & "Illegal first byte"& " at byte" &Long_Long_Integer'Image(base.bytecnt);
				end if;
			end if;
			return to_String(r);
		end read;
		function reason(base:in out Y2018.Text.Wide.InFileUTF8.self) return RS_TY is
		begin
			return base.reason;
		end reason;
		function utf8cnt(base:in out Y2018.Text.Wide.InFileUTF8.self) return Long_Long_Integer is
		begin
			return base.utf8cnt;
		end utf8cnt;
		function bytecnt(base:in out Y2018.Text.Wide.InFileUTF8.self) return Long_Long_Integer is
		begin
			return base.bytecnt;
		end bytecnt;
		procedure Finalize(base: in out Y2018.Text.Wide.InFileUTF8.self) is
		begin
			base.defstring:=Null_Unbounded_String;
			base.defaction:=TRUE;
			base.utf8cnt:=0;
			base.bytecnt:=0;
			base.reason:=RS_NONE;
		end Finalize;
		procedure Initialize(base: in out Y2018.Text.Wide.InFileUTF8.self) is
		begin
			base.defstring:=Null_Unbounded_String;
			base.defaction:=TRUE;
			base.utf8cnt:=0;
			base.bytecnt:=0;
			base.reason:=RS_NONE;
		end Initialize;
	end Y2018.Text.Wide.InFileUTF8;
