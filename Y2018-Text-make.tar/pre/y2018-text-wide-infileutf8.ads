-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200718075128.
-- ############################## InFileUTF8.ads ##############################
with Ada.Direct_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
	package Y2018.Text.Wide.InFileUTF8 is
		type self is tagged limited private;
		type RS_TY is (RS_NONE, RS_MISS, RS_ILLEGAL,RS_OPEN);
		replacementCharacter:String:=(Character'Val(16#EF#),Character'Val(16#BF#),Character'Val(16#BD#));
		package DirectTY is new Ada.Direct_IO(Character);
		procedure open(base:in out Y2018.Text.Wide.InFileUTF8.self;infilename:String;defaultString:String:=replacementCharacter;defaultAction:Boolean:=TRUE);
		function read(base:in out Y2018.Text.Wide.InFileUTF8.self) return String;
		procedure close(base:in out Y2018.Text.Wide.InFileUTF8.self);
		function eof(base:Y2018.Text.Wide.InFileUTF8.self) return Boolean;
		function reason(base:in out Y2018.Text.Wide.InFileUTF8.self) return RS_TY;
		function utf8cnt(base:in out Y2018.Text.Wide.InFileUTF8.self) return Long_Long_Integer;
		function bytecnt(base:in out Y2018.Text.Wide.InFileUTF8.self) return Long_Long_Integer;
		procedure Finalize(base: in out Y2018.Text.Wide.InFileUTF8.self);
		procedure Initialize(base: in out Y2018.Text.Wide.InFileUTF8.self);
		private type self is tagged limited
		record
			infile:DirectTY.File_Type;
			defstring:Unbounded_String;
			defaction:Boolean;
			utf8cnt:Long_Long_Integer;
			bytecnt:Long_Long_Integer;
			reason:RS_TY;
		end record;
	end Y2018.Text.Wide.InFileUTF8;
