-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## TestR.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
with Y2018.Text.TestQ; use Y2018.Text.TestQ;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
with Y2018.Text.Wide; use Y2018.Text.Wide;
package Y2018.Text.TestR is
-- ############################## core.ads ##############################
	procedure Qappend(a:ANKA;head:String;s:String;p:Pattern_TY); 
	procedure Qappend(a:ANKA;head:String;s:Wide_Wide_String;p:Pattern_TY);
	procedure Qappend(a:ANKA;head:String;s:Unbounded_String;p:Pattern_TY); 
	procedure Qappend(a:ANKA;head:String;s:Unbounded_Wide_Wide_String;p:Pattern_TY);
	procedure Qappend(a:ANKA;head:String;sa:Unbounded_Wide_Wide_String_AA); 
-- ############################## TestTailR.adb ##############################
end Y2018.Text.TestR;
