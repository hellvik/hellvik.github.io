-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20200724181916.
-- ############################## STR.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
--with Ada.Strings;
--with Y2018.Text.Wide.UTF;

package Y2018.Text.Wide.STR is
	function "+"(left:Wide_Wide_String;right:Wide_Wide_String) return Wide_Wide_String ; -- [00]
	function "+"(left:Wide_Wide_String;right:Wide_Wide_Character) return Wide_Wide_String ; -- [01]
	function "+"(left:Wide_Wide_String;right:Unbounded_Wide_Wide_String) return Wide_Wide_String ; -- [02]
	function "+"(left:Wide_Wide_String;right:Unbounded_String) return Wide_Wide_String ; -- [03]
	function "+"(left:Unbounded_Wide_Wide_String;right:Wide_Wide_String) return Unbounded_Wide_Wide_String ; -- [04]
	function "+"(left:Unbounded_Wide_Wide_String;right:Unbounded_Wide_Wide_String) return Unbounded_Wide_Wide_String ; -- [05]
	function "+"(left:Unbounded_Wide_Wide_String;right:Unbounded_String) return Unbounded_Wide_Wide_String ; -- [06]
	function "+"(left:Unbounded_String;right:Wide_Wide_String) return Unbounded_String ; -- [07]
	function "+"(left:Unbounded_String;right:Unbounded_Wide_Wide_String) return Unbounded_String ; -- [08]
	function "+"(left:Unbounded_String;right:Unbounded_String) return Unbounded_String ; -- [09]
	function "+"(left:Unbounded_Wide_Wide_String;right:Wide_Wide_Character) return Unbounded_Wide_Wide_String ; -- [10]
	function "+"(left:Unbounded_String;right:Wide_Wide_Character) return Unbounded_String ; -- [11]
	function "+"(left:Wide_Wide_Character;right:Wide_Wide_String) return Wide_Wide_String ; -- [12]
	function "+"(left:Wide_Wide_Character;right:Wide_Wide_Character) return Wide_Wide_String ; -- [13]
	function "+"(left:Wide_Wide_Character;right:Unbounded_Wide_Wide_String) return Wide_Wide_String ; -- [14]
	function "+"(left:Wide_Wide_Character;right:Unbounded_String) return Wide_Wide_String ; -- [15]

	function "+"(left:Wide_Wide_String;right:String) return Wide_Wide_String ; -- [16]
	function "+"(left:Wide_Wide_String;right:Character) return Wide_Wide_String ; -- [17]
	function "+"(left:String;right:Wide_Wide_String) return String ; -- [18]
	function "+"(left:String;right:String) return String ; -- [19]
	function "+"(left:String;right:Unbounded_Wide_Wide_String) return String ; -- [20]
	function "+"(left:String;right:Unbounded_String) return String ; -- [21]
	function "+"(left:String;right:Wide_Wide_Character) return String ; -- [22]
	function "+"(left:String;right:Character) return String ; -- [23]
	function "+"(left:Unbounded_Wide_Wide_String;right:String) return Unbounded_Wide_Wide_String ; -- [24]
	function "+"(left:Unbounded_Wide_Wide_String;right:Character) return Unbounded_Wide_Wide_String ; -- [25]
	function "+"(left:Unbounded_String;right:String) return Unbounded_String ; -- [26]
	function "+"(left:Unbounded_String;right:Character) return Unbounded_String ; -- [27]
	function "+"(left:Wide_Wide_Character;right:String) return Wide_Wide_String ; -- [28]
	function "+"(left:Wide_Wide_Character;right:Character) return Wide_Wide_String ; -- [29]
	function "+"(left:Character;right:Wide_Wide_String) return String ; -- [30]
	function "+"(left:Character;right:String) return String ; -- [31]
	function "+"(left:Character;right:Unbounded_Wide_Wide_String) return String ; -- [32]
	function "+"(left:Character;right:Unbounded_String) return String ; -- [33]
	function "+"(left:Character;right:Wide_Wide_Character) return String ; -- [34]
	function "+"(left:Character;right:Character) return String ; -- [35]

end Y2018.Text.Wide.STR;
