with Ada.Text_IO; use  Ada.Text_IO;
with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
with Ada.Command_Line;
with Ada.Directories;
with Y2018.Text.Wide; use Y2018.Text.Wide;
with Y2018.Text.Wide.STR; use Y2018.Text.Wide.STR;
with Y2018.Text.Wide.UTF;
with Y2018.Text.Wide.Tool; use Y2018.Text.Wide.Tool; 
-- with Y2018.Text.Core.Tool;
with Y2018.Text.Regex; use Y2018.Text.Regex;
with Y2018.Text.Regex.PatternPack; use Y2018.Text.Regex.PatternPack;
with GNAT.Source_Info;
with GNAT.Time_Stamp;
-- with DSECT;
procedure Y2018CodeReWrite is
	type ER_TY is (
		ER001,
		ER002,
		ER003,
		ER004,
		ER005,
		ER999);
	
	--
	CONF_name:Unbounded_Wide_Wide_String;
	CONF_FT : File_Type;
	--
	LST_name: Unbounded_Wide_Wide_String;
	LST_FT : File_Type;
	--
	INPUT_name:Unbounded_Wide_Wide_String;
	IN_FT : File_Type;
	--
	OUTPUT_name:Unbounded_Wide_Wide_String;
	UT_FT : File_Type;
	--
	arg:Unbounded_Wide_Wide_String;
	pa:Pattern_TY;
	pb:Pattern_TY;
	q:Pattern_TY;
	i:Integer:=1;
	szp:Integer;
	pa_patternValue:Unbounded_Wide_Wide_String;
	pb_patternValue:Unbounded_Wide_Wide_String;
	q_patternValue:Unbounded_Wide_Wide_String;
	inBlk:Boolean:=FALSE; 
	new_inBlk:Boolean:=FALSE; 
	in_linecount:Integer:=0;
	ut_linecount:Integer:=0;
	listed:Boolean:=TRUE;
	actions_exists:Boolean:=FALSE;
begin
	if Ada.Command_Line.Argument_Count = 0 then
		Put_line("  ./Y2018CodeReWrite {-conf <conf-file>} {-lst <list-file>} <input-file> <output-file>");
		return;
	end if;
	--------
	--    --
	--------
	declare -- ARGUMENT UPDATE
		argConfF:Boolean:=FALSE;
		argLstF:Boolean:=FALSE;
	begin
		Pattern(pa,"^-[\w]+$"W);
		while i <= Ada.Command_Line.Argument_Count loop
			arg:=NUW + Ada.Command_Line.Argument(i);
			declare
				pra:Unbounded_Wide_Wide_String_AA(0 .. (size(pa) - 1));
			begin
				if matchTo(arg,pa,pra) then
					argConfF:=FALSE;
					argLstF:=FALSE;
					if pra(0) = NUW + "-lst" then
						argLstF:=TRUE;
					elsif pra(0) = NUW + "-conf" then
						argConfF:=TRUE;
					else
						raise Program_Error with ER_TY'Image(ER001) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Unknown arg :" + arg;
					end if;
				elsif argConfF then
					CONF_name:=arg;
					argConfF:=FALSE;
				elsif argLstF then
					LST_name:=arg;
					argLstF:=FALSE;
				elsif Length(INPUT_name) = 0 then
					INPUT_name:=arg;
				elsif Length(OUTPUT_name) = 0 then
					OUTPUT_name:=arg;
				else
					raise Program_Error with ER_TY'Image(ER002) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": Unknown arg :" + arg;
				end if;
			end;
			i:=i+1;
		end loop;
	end; -- ARGUMENT UPDATE
	if Length(INPUT_name) = 0 then
		raise Program_Error with ER_TY'Image(ER004) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": no input file";
	elsif Length(OUTPUT_name) = 0 then
		raise Program_Error with ER_TY'Image(ER005) & " " & GNAT.Source_Info.Source_Location & " " & GNAT.Source_Info.Enclosing_Entity & ": no input file";
	end if;
	-----------
	-- FILES --
	-----------
	begin
		Open (File => IN_FT,Mode => In_File,Name => "" + INPUT_name);
	exception
		when others =>
			Ada.Text_IO.Put_Line(Standard_Error,"Can not open the file '" + INPUT_name + "'. Does it exist?");
		raise;
	end;
	if Length(CONF_name) > 0 then
		begin
			Open (File => CONF_FT,Mode => In_File,Name => "" + CONF_name);
		exception
			when others =>
				Ada.Text_IO.Put_Line(Standard_Error,"Can not open the file '" + CONF_name + "'. Does it exist?");
			raise;
		end;
	end if;
	--
	begin
		Create (File => UT_FT,Mode => Out_File,Name => "" + OUTPUT_name);
	exception
		when others =>
			Ada.Text_IO.Put_Line(Standard_Error,"Can not create the file '" + OUTPUT_name + "'");
		raise;
	end;
	if Length(LST_name) > 0 then
		if Ada.Directories.Exists("" + LST_name) then
			begin
				Open (File => LST_FT,Mode => Append_File,Name => "" + LST_name);
			exception
				when others =>
					Ada.Text_IO.Put_Line(Standard_Error,"Can not open the file '" + LST_name + "'");
				raise;
			end;
		else
			begin
				Create (File => LST_FT,Mode => Append_File,Name => "" + LST_name);
			exception
				when others =>
					Ada.Text_IO.Put_Line(Standard_Error,"Can not create the file '" + LST_name + "'");
				raise;
			end;
		end if;
		Put_Line(LST_FT,"---- " + GNAT.Time_Stamp.Current_Time + " ----");
	end if;
	-------
	if Length(CONF_name) > 0 then
		Pattern(pa,"^[\\s]*([\\w]+)[\\s]*=[\\s]*([\\w]+)(.*?)[\\s]*$"W);
		declare
			pra:Unbounded_Wide_Wide_String_AA(0 .. (size(pa) - 1));
			valU:Unbounded_Wide_Wide_String;
		begin
			while not End_of_File(CONF_FT) loop
				declare
					Line : String := Get_Line (CONF_FT);
				begin
					if matchTo(Line,pa,pra) then
						pra(1):=To_UC(pra(1));
						if pra(1) = NUW + "FNK"W then
							valU:=To_UC(pra(2));
							actions_exists:=TRUE;
							if length(pa_patternValue) = 0 then
								pa_patternValue:=pa_patternValue + valU + "[\\s]*\\("W;
								q_patternValue:=q_patternValue + "[\\s]*"W + valU + "[\\s]*\\("W;
							else
								pa_patternValue:=pa_patternValue + "|"W + valU + "[\\s]*\\("W;
								q_patternValue:=q_patternValue + "|[\\s]*"W + valU + "[\\s]*\\("W;
							end if;
							if Length(LST_name) > 0 then
								Put_Line(LST_FT,"conf: " + pra(1) + "=" + valU);
							end if;
						elsif pra(1) = NUW + "RM"W then
							actions_exists:=TRUE;
							valU:=NUW + pra(2) + pra(3);
							if length(pa_patternValue) = 0 then
								pa_patternValue:=pa_patternValue + valU;
								--q_patternValue:=q_patternValue + "[\\s]*"W + valU;
							else
								pa_patternValue:=pa_patternValue + "|"W + valU;
								--q_patternValue:=q_patternValue + "|[\\s]*"W + valU;
							end if;
							if Length(LST_name) > 0 then
								Put_Line(LST_FT,"conf: " + pra(1) + "=" + valU);
							end if;
						end if;
					end if;
				end;
			end loop;
		end;
		close(CONF_FT);
		pa_patternValue:=NUW + "^[\\s]*("W + pa_patternValue + ").*$"W;
	end if;
	if actions_exists then
		q_patternValue:=NUW + "^[\\s]*--("W + "\\(BLK|"W + "\\)BLK|"W + q_patternValue + ").*$"W;
	else
		q_patternValue:=NUW + "^[\\s]*--(\\(BLK|\\)BLK).*$"W;
	end if;
	--------
	--    --
	--------
	szp:=-1;
	if actions_exists then 
		Pattern(pa,""W + pa_patternValue,G_UPPERCASE);
		szp:=size(pa) - 1;
	end if;
	Pattern(q,""W + q_patternValue,G_UPPERCASE);
	declare
		pra:Unbounded_Wide_Wide_String_AA(0 .. szp);
		qr:Unbounded_Wide_Wide_String_AA(0 .. (size(q) - 1));
	begin
		while not End_of_File(IN_FT) loop
			in_linecount:=in_linecount + 1;
			listed:=FALSE;
			declare
				Line : String := Get_Line (IN_FT);
			begin
				if matchTo(Line,q,qr) then
					if inBlk then -- inside --(BLK .. )BLK
						if qr(1) = NUW + ")BLK"W then
							new_inBlk:=FALSE;
						end if;
					else
						if qr(1) = NUW + "(BLK" then
							new_inBlk:=TRUE;inBlk:=TRUE;
						else
							new_inBlk:=FALSE;inBlk:=TRUE;
						end if;
					end if;
				end if;
				if inBlk = FALSE then
					if actions_exists then
						if matchTo(Line,pa,pra) then
							null;
						else
							Put_Line(UT_FT,Line);
							ut_linecount:=ut_linecount + 1;
							listed:=TRUE;
						end if;
					else
						Put_Line(UT_FT,Line);
						ut_linecount:=ut_linecount + 1;
						listed:=TRUE;
					end if;
				end if;
				if listed then
					null;
				elsif Length(LST_name) > 0 then
					Put_Line(LST_FT,Right(LeftStrip(Integer'Image(in_linecount),' 'W),6,'.'W) + "|" + Line);
				end if;
				inBlk:=new_inBlk;
			end;
		end loop;
	end;
	Close (UT_FT);
	Close (IN_FT);
	if Length(LST_name) > 0 then
		PUT_Line(LST_FT,"******");
		Put_Line(LST_FT,"Input_lines" + Integer'Image(in_linecount) + " Output_lines" + Integer'Image(ut_linecount));
		Close(LST_FT);
	end if;
end Y2018CodeReWrite;
