-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20201209122333.
-- ############################## Wide.ads ##############################
with Ada.Strings.Unbounded;      use Ada.Strings.Unbounded;
with Ada.Strings.Wide_Wide_Unbounded; use Ada.Strings.Wide_Wide_Unbounded;
package Y2018.Text.Wide is
	NUS:constant Ada.Strings.Unbounded.Unbounded_String:=Null_Unbounded_String;
	NUW:constant Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String:=Null_Unbounded_Wide_Wide_String;
	type Unbounded_Wide_Wide_String_AA is array (Integer range <>) of Ada.Strings.Wide_Wide_Unbounded.Unbounded_Wide_Wide_String; 
	type RS_TY is (
	  RS_NONE, -- OK
	  RS_MISS, -- Last UTF-8 character in a file is missing bytes
	  RS_ILLEGAL, -- Value in a byte cannot be an UTF-8 character or a part of an UTF-8 character
	  RS_EOF -- End of File reached
	);
-- ############################## WideTail.adb ##############################
end Y2018.Text.Wide;
