-- This file is part of Y2018-Text-project.
-- 
-- Y2018-Text-project is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- any later version.
-- 
-- Y2018-Text-project is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- 
-- You should have received a copy of the GNU General Public License
-- along with Y2018-Text-project.  If not, see <https://www.gnu.org/licenses/>.
-- 
-- Y2018-Text-project, copyright 2019 John-Eric Soderman. Makefile generated 20191103155259.
-- === GENERATED CODE ===
with Y2018.Text.Core;
package Y2018.Text.Wide.Msg is
E60:aliased constant String:="Y2018.Text.Wide.UTF.To32 : byte 2/";
E61:aliased constant String:="Y2018.Text.Wide.UTF.To32 : byte 3/";
E62:aliased constant String:="Y2018.Text.Wide.UTF.To32 : byte 4/";
E63:aliased constant String:="Y2018.Text.Wide.UTF.To32 : Illegal";
E64:aliased constant String:="Y2018.Text.Wide.UTF.To32 : % > 'LAST";
E65:aliased constant String:="Y2018.Text.Wide.UTF.To32 : Illegal";
E66:aliased constant String:="Y2018.Text.Wide.UTF.To8  : Out of range";
E67:aliased constant String:="Y2018.Text.Wide.UTF.To8  : Out of range";
E31:aliased constant String:="Y2018.Text.Wide.Tool.To_HexX  : Out of range";
E32:aliased constant String:="Y2018.Text.Wide.Tool.To_HexU  : Out of range";
E33:aliased constant String:="Y2018.Text.Wide.Tool.To_HexV  : Out of range";
E70:aliased constant String:="Y2018.Text.Wide.Tool.Right  : length<0";
E71:aliased constant String:="Y2018.Text.Wide.Tool.Left  : length<0";
E72:aliased constant String:="Y2018.Text.Wide.Tool.Right  : length<0";
E73:aliased constant String:="Y2018.Text.Wide.Tool.Right  : too long pad";
E74:aliased constant String:="Y2018.Text.Wide.Tool.Left  : length<0";
E75:aliased constant String:="Y2018.Text.Wide.Tool.Left  : too long pad";
E76:aliased constant String:="Y2018.Text.Wide.Tool.Center  : too long pad";
E77:aliased constant String:="Y2018.Text.Wide.Tool.LeftStrip  : too long pad";
E78:aliased constant String:="Y2018.Text.Wide.Tool.RightStrip  : too long pad";
E79:aliased constant String:="Y2018.Text.Wide.Tool.Strip  : too long pad";
E:constant Y2018.Text.Core.StringArray_CAA :=(
1=>E31'Access,
2=>E32'Access,
3=>E33'Access,
4=>E60'Access,
5=>E61'Access,
6=>E62'Access,
7=>E63'Access,
8=>E64'Access,
9=>E65'Access,
10=>E66'Access,
11=>E67'Access,
12=>E70'Access,
13=>E71'Access,
14=>E72'Access,
15=>E73'Access,
16=>E74'Access,
17=>E75'Access,
18=>E76'Access,
19=>E77'Access,
20=>E78'Access,
21=>E79'Access);
K:constant Y2018.Text.Core.IntegerArray :=(
1=>31,
2=>32,
3=>33,
4=>60,
5=>61,
6=>62,
7=>63,
8=>64,
9=>65,
10=>66,
11=>67,
12=>70,
13=>71,
14=>72,
15=>73,
16=>74,
17=>75,
18=>76,
19=>77,
20=>78,
21=>79);
end Y2018.Text.Wide.Msg;
